package com.vrboxos.settings

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

enum class InputMode(val label: String) { AUTO("Automático"), HAND("Mãos"), GAZE("Olhar") }
enum class CameraKind(val label: String) { FRONT("Frontal"), BACK("Traseira"), EXTERNAL("Externa (USB)") }
enum class GestureCommand(val label: String) { NONE("Nenhum"), MENU("Menu"), BACK("Voltar") }
/** AUTO: livre fora do VR, paisagem (nos dois sentidos) dentro do VR. */
enum class OrientationMode(val label: String) {
    AUTO("Automática"), LANDSCAPE("Paisagem"), LANDSCAPE_REVERSE("Paisagem invertida")
}
enum class Quality(val label: String, val renderScale: Float) {
    LOW("Baixa", 0.6f), MEDIUM("Média", 0.8f), HIGH("Alta", 1f)
}

/** Preferências persistidas localmente (SharedPreferences). */
class Settings(private val prefs: SharedPreferences) {
    constructor(ctx: Context) : this(ctx.getSharedPreferences("vrboxos_settings", Context.MODE_PRIVATE))

    var ipdMm by f("ipd_mm", 63f, 50f, 75f)
    var fovDeg by f("fov", 90f, 70f, 110f)
    // Chaves "_v2": novos padrões (menu mais perto e maior) valem mesmo para quem já abriu o app.
    var panelDistance by f("panel_dist_v2", DEFAULT_PANEL_DISTANCE, 0.8f, 4f)
    var panelScale by f("panel_scale_v2", DEFAULT_PANEL_SCALE, 0.6f, 1.8f)
    var lensK1 by f("lens_k1", 0f, -0.3f, 0.5f)
    /** Deslocamento horizontal das duas imagens, em fração da largura de cada olho. */
    var alignX by f("align_x", 0f, -0.2f, 0.2f)
    /** Tamanho da imagem dentro de cada metade (1 = ocupa tudo, sem margens). */
    var viewScale by f("view_scale", 1f, 0.6f, 1f)
    var orientation by e("orientation", OrientationMode.AUTO, OrientationMode.values())
    var headTracking by b("head_on", true)
    var headSensitivity by f("head_sens", 1f, 0.5f, 1.5f)
    var headSmoothing by f("head_smooth", 0.2f, 0f, 1f)
    var inputMode by e("input", InputMode.AUTO, InputMode.values())
    var dwellSec by f("dwell", 1.5f, 0.8f, 3f)
    var pointer by b("pointer", true)
    var handEnabled by b("hand_on", false)
    var camera by e("camera", CameraKind.FRONT, CameraKind.values())
    var gestureSens by f("gest_sens", 1f, 0.6f, 1.4f)
    var fistCommand by e("fist_cmd", GestureCommand.MENU, GestureCommand.values())
    var openCommand by e("open_cmd", GestureCommand.BACK, GestureCommand.values())
    var handFpsCap by i("hand_fps", 20, 10, 30)
    var mirrorHands by b("mirror_hands", false)
    var quality by e("quality", Quality.MEDIUM, Quality.values())
    var vignette by b("vignette", false)
    var soundOn by b("sound", true)
    var environment by i("env", 0, 0, 2)
    var vrMode by b("vr_mode", false)

    companion object {
        /** Menu a 1,25 m: perto o bastante para ler, longe o bastante para o foco/convergência confortáveis. */
        const val DEFAULT_PANEL_DISTANCE = 1.25f
        const val DEFAULT_PANEL_SCALE = 1.3f
    }

    fun resetDefaults() { prefs.edit().clear().apply() }

    private fun f(key: String, def: Float, min: Float, max: Float) = object : ReadWriteProperty<Any?, Float> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = prefs.getFloat(key, def).coerceIn(min, max)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
            prefs.edit().putFloat(key, value.coerceIn(min, max)).apply()
        }
    }

    private fun i(key: String, def: Int, min: Int, max: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = prefs.getInt(key, def).coerceIn(min, max)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            prefs.edit().putInt(key, value.coerceIn(min, max)).apply()
        }
    }

    private fun b(key: String, def: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = prefs.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            prefs.edit().putBoolean(key, value).apply()
        }
    }

    private fun <T : Enum<T>> e(key: String, def: T, values: Array<T>) = object : ReadWriteProperty<Any?, T> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): T {
            val n = prefs.getString(key, def.name)
            return values.firstOrNull { it.name == n } ?: def
        }
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
            prefs.edit().putString(key, value.name).apply()
        }
    }
}
