package com.vrboxos.render

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.SystemClock
import com.vrboxos.Telemetry
import com.vrboxos.hands.CameraState
import com.vrboxos.hands.HandPipeline
import com.vrboxos.hands.HandState
import com.vrboxos.hands.HandTopology
import com.vrboxos.hands.Pose
import com.vrboxos.head.HeadPose
import com.vrboxos.input.HandMapping
import com.vrboxos.input.InputRouter
import com.vrboxos.media.CinemaPlayer
import com.vrboxos.media.VideoFormat
import com.vrboxos.settings.Settings
import com.vrboxos.ui.Panel
import com.vrboxos.ui.Screen
import com.vrboxos.ui.SpatialUi
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Renderizador estereoscópico. No modo VR desenha a cena duas vezes (um viewport por olho) em um
 * FBO e aplica a passada de distorção; no modo plano desenha uma vez direto na tela.
 */
class VrRenderer(
    private val ctx: Context,
    private val ui: SpatialUi,
    private val head: HeadPose,
    private val settings: Settings,
    private val cinema: CinemaPlayer,
    private val router: InputRouter,
    private val pipeline: HandPipeline
) : GLSurfaceView.Renderer {

    @Volatile var vrMode = false
    private var width = 1
    private var height = 1

    private lateinit var quad: QuadRenderer
    private lateinit var oesQuad: QuadRenderer
    private lateinit var color: ColorRenderer
    private lateinit var sphere: SphereRenderer
    private var whiteTex = 0
    // Imagem real da câmera (prévia enviada pelo HandTracker)
    private var camTex = 0
    private var camSeq = -1
    private var camUploaded = false
    private var camAspect = 4f / 3f
    private var camHasFrame = false
    // Página do navegador (bitmap do WebView)
    private var webTex = 0
    private var webSeq = -1
    private var webUploaded = false
    private var distProg = 0
    private var dPos = 0; private var dUv = 0; private var dTex = 0; private var dK1 = 0; private var dU0 = 0
    private val distVerts: FloatBuffer = GlUtil.floatBuffer(
        floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f)
    )

    private var fbo = 0; private var fboTex = 0; private var fboDepth = 0; private var fboW = 0; private var fboH = 0

    private val rot = FloatArray(16); private val view = FloatArray(16); private val proj = FloatArray(16)
    private val vp = FloatArray(16); private val vpHead = FloatArray(16); private val shift = FloatArray(16)
    private val model = FloatArray(16); private val mvp = FloatArray(16)
    private val stereoS = FloatArray(16); private val stereoUv = FloatArray(16)
    private val tint = FloatArray(4)

    private val ovWorld = MeshBuilder(); private val ovHead = MeshBuilder(); private val ovVig = MeshBuilder()
    private val ovGuide = MeshBuilder()
    private val ndcIdentity = FloatArray(16).also { it[0] = 1f; it[5] = 1f; it[10] = 1f; it[15] = 1f }

    private var frames = 0; private var fpsStart = 0L
    private var lastFrame = 0L

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        quad = QuadRenderer(false)
        oesQuad = QuadRenderer(true)
        color = ColorRenderer()
        sphere = SphereRenderer()
        distProg = GlUtil.program(Shaders.DIST_VS, Shaders.DIST_FS)
        dPos = GLES20.glGetAttribLocation(distProg, "aPos"); dUv = GLES20.glGetAttribLocation(distProg, "aUv")
        dTex = GLES20.glGetUniformLocation(distProg, "uTex"); dK1 = GLES20.glGetUniformLocation(distProg, "uK1")
        dU0 = GLES20.glGetUniformLocation(distProg, "uU0")
        val white = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888).also { it.eraseColor(-1) }
        whiteTex = GlUtil.newTexture()
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, white, 0)
        white.recycle()
        camTex = GlUtil.newTexture(); camSeq = -1; camUploaded = false
        webTex = GlUtil.newTexture(); webSeq = -1; webUploaded = false
        fbo = 0; fboTex = 0; fboDepth = 0; fboW = 0; fboH = 0
        ui.onGlCreated()
        cinema.attachGl()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { width = max(w, 2); height = max(h, 2) }

    override fun onDrawFrame(gl: GL10?) {
        val now = SystemClock.elapsedRealtime()
        frames++
        if (fpsStart == 0L) fpsStart = now
        if (now - fpsStart >= 1000) { Telemetry.renderFps = frames * 1000f / (now - fpsStart); frames = 0; fpsStart = now }
        lastFrame = now

        cinema.updateTexture()
        updateCameraTexture(now)
        updateWebTexture()
        val q = head.orientation()
        q.conjugate().toMatrix(rot)
        val vr = vrMode
        val aspect = if (vr) (width / 2f) / height else width.toFloat() / height
        router.update(now, q, vr, aspect, width, height)
        ui.update(now)
        ui.refreshTextures()
        buildOverlays(vr)

        if (vr) {
            val sw = max(2, ((width * settings.quality.renderScale).toInt()) and 1.inv())
            val sh = max(2, (height * settings.quality.renderScale).toInt())
            ensureFbo(sw, sh)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
            for (eye in 0..1) {
                val v = StereoLayout.eyeViewport(sw, sh, eye)
                drawScene(v[0], v[1], v[2], v[3], StereoLayout.eyeShiftMeters(settings.ipdMm, eye), true, eye)
            }
            postProcess()
        } else {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            drawScene(0, 0, width, height, 0f, false, 0)
        }
    }

    // ---------------------------------------------------------------- cena

    private fun drawScene(x: Int, y: Int, w: Int, h: Int, eyeShift: Float, vr: Boolean, eye: Int) {
        GLES20.glViewport(x, y, w, h)
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
        GLES20.glScissor(x, y, w, h)
        val env = ui.environment()
        val flatTheater = ui.flatTheater
        val c = if (flatTheater || (ui.cameraBackground && camHasFrame)) floatArrayOf(0f, 0f, 0f) else env.clear
        GLES20.glClearColor(c[0], c[1], c[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        Matrix.perspectiveM(proj, 0, StereoLayout.verticalFovDeg(settings.fovDeg, w.toFloat() / h), w.toFloat() / h, 0.05f, 60f)
        Matrix.setIdentityM(shift, 0)
        Matrix.translateM(shift, 0, eyeShift, 0f, 0f)
        Matrix.multiplyMM(view, 0, shift, 0, rot, 0)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        Matrix.multiplyMM(vpHead, 0, proj, 0, shift, 0)

        val show360 = ui.screen == Screen.CINEMA && cinema.format.is360 && cinema.hasFrame
        if (show360) {
            // Vídeo 360°: esfera ao redor da cabeça (só rotação; o formato foi escolhido pelo usuário).
            cinema.format.eyeUvMatrix(eye, stereoS)
            Matrix.multiplyMM(stereoUv, 0, cinema.texMatrix, 0, stereoS, 0)
            sphere.draw(cinema.texId, vp, stereoUv)
        } else if (ui.cameraBackground && camHasFrame) {
            // Imagem real da câmera como fundo (presa à cabeça, mono). Não é registrada com o espaço real.
            drawCameraBackground(w.toFloat() / h)
        } else if (!flatTheater) {
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            color.draw(env.triBuf, env.triCount, GLES20.GL_TRIANGLES, vp)
            color.draw(env.lineBuf, env.lineCount, GLES20.GL_LINES, vp)
            color.draw(env.pointBuf, env.pointCount, GLES20.GL_POINTS, vp, env.pointSize)
            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        }

        for (p in ui.drawOrder()) drawPanel(p, eye)

        color.draw(ovWorld.buffer(), ovWorld.count, GLES20.GL_TRIANGLES, vp)
        color.draw(ovHead.buffer(), ovHead.count, GLES20.GL_TRIANGLES, vpHead)
        if (vr && settings.vignette) color.draw(ovVig.buffer(), ovVig.count, GLES20.GL_TRIANGLES, vpHead)
        if (ui.screen == Screen.CALIB) drawGuides(w.toFloat() / h)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
    }

    /** Envia a imagem mais recente da página (WebView) para a GPU, só enquanto o navegador está aberto. */
    private fun updateWebTexture() {
        if (ui.screen != Screen.BROWSER) return
        val br = ui.browser
        val seq = br.frameSeq.get()
        if (seq != webSeq) {
            val b = br.frame.get()
            if (b != null && !b.isRecycled) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, webTex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0)
                webSeq = seq
                webUploaded = true
            }
        }
    }

    /** Envia a prévia nova da câmera para a GPU. Só conta como imagem válida se chegou quadro há pouco. */
    private fun updateCameraTexture(now: Long) {
        val tr = pipeline.tracker
        val seq = tr.previewSeq.get()
        if (seq != camSeq) {
            val b = tr.previewBitmap.get()
            if (b != null && !b.isRecycled) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, camTex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0)
                camAspect = b.width.toFloat() / b.height
                camSeq = seq
                camUploaded = true
            }
        }
        camHasFrame = camUploaded && Telemetry.cameraState == CameraState.ACTIVE && Telemetry.cameraFresh(now)
    }

    /** Câmera ocupando a tela do olho, mantendo a proporção (barras pretas se preciso). */
    private fun drawCameraBackground(viewAspect: Float) {
        val sx: Float; val sy: Float
        if (camAspect > viewAspect) { sx = 1f; sy = viewAspect / camAspect } else { sx = camAspect / viewAspect; sy = 1f }
        Matrix.setIdentityM(model, 0)
        Matrix.scaleM(model, 0, 2f * sx, 2f * sy, 1f)
        tint[0] = 0.85f; tint[1] = 0.85f; tint[2] = 0.85f; tint[3] = 0.85f   // levemente escurecida: painéis legíveis
        quad.draw(camTex, model, tint)
    }

    /** Guias de calibração em coordenadas da tela do olho: borda, cruz central e círculos. */
    private fun drawGuides(aspect: Float) {
        ovGuide.clear()
        val c = floatArrayOf(0.31f, 0.82f, 1f, 0.95f)
        val t = 0.006f
        fun bar(x0: Float, y0: Float, x1: Float, y1: Float) = ovGuide.quad(x0, y0, 0f, x1, y0, 0f, x1, y1, 0f, x0, y1, 0f, c)
        val m = 0.97f
        bar(-m, m - t, m, m); bar(-m, -m, m, -m + t); bar(-m, -m, -m + t, m); bar(m - t, -m, m, m)   // moldura
        bar(-m, -t / 2, m, t / 2); bar(-t / 2, -m, t / 2, m)                                      // cruz
        // Marcadores de orientação: triângulo no topo e quadrado no canto superior ESQUERDO.
        // Se aparecerem embaixo ou à direita, a imagem está girada/espelhada.
        ovGuide.tri(-0.06f / aspect, 0.80f, 0f, 0.06f / aspect, 0.80f, 0f, 0f, 0.93f, 0f, c)
        ovGuide.quad(-0.90f, 0.78f, 0f, -0.75f, 0.78f, 0f, -0.75f, 0.92f, 0f, -0.90f, 0.92f, 0f, c)
        for (r in floatArrayOf(0.35f, 0.7f)) {                                                    // círculos
            val n = 48
            for (i in 0 until n) {
                val a0 = (2 * PI * i / n).toFloat(); val a1 = (2 * PI * (i + 1) / n).toFloat()
                val rr = r + t
                ovGuide.quad(
                    r * cos(a0) / aspect, r * sin(a0), 0f, rr * cos(a0) / aspect, rr * sin(a0), 0f,
                    rr * cos(a1) / aspect, rr * sin(a1), 0f, r * cos(a1) / aspect, r * sin(a1), 0f, c
                )
            }
        }
        color.draw(ovGuide.buffer(), ovGuide.count, GLES20.GL_TRIANGLES, ndcIdentity)
    }

    private fun drawPanel(p: Panel, eye: Int) {
        if (p.alpha < 0.01f || p.tex == 0) return
        val g = ui.geometry(p)
        val a = p.alpha
        // sombra suave
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, g.cx, g.cy - g.h * 0.015f, g.cz - 0.01f)
        Matrix.scaleM(model, 0, g.w * 1.05f, g.h * 1.07f, 1f)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        tint[0] = 0f; tint[1] = 0f; tint[2] = 0f; tint[3] = 0.35f * a
        quad.draw(whiteTex, mvp, tint)

        var w = g.w; var h = g.h
        if (p.isWeb && webUploaded) {
            val ar = com.vrboxos.web.BrowserController.W.toFloat() / com.vrboxos.web.BrowserController.H
            if (w / ar <= h) h = w / ar else w = h * ar
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, g.cx, g.cy, g.cz)
            Matrix.scaleM(model, 0, w, h, 1f)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            tint[0] = a; tint[1] = a; tint[2] = a; tint[3] = a
            quad.draw(webTex, mvp, tint)
            return
        }
        if (p.isCamera && camHasFrame) {
            if (w / camAspect <= h) h = w / camAspect else w = h * camAspect   // sem esticar
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, g.cx, g.cy, g.cz)
            Matrix.scaleM(model, 0, w, h, 1f)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            tint[0] = a; tint[1] = a; tint[2] = a; tint[3] = a
            quad.draw(camTex, mvp, tint)
            return
        }
        if (p.isVideo && cinema.hasFrame) {
            // 360° é desenhado como esfera; aqui só 2D e 3D SBS/TB (cada olho vê a sua metade).
            if (cinema.format.is360) return
            val fmt = cinema.format
            val ar = cinema.videoAspect * fmt.aspectFactor
            if (w / ar <= h) h = w / ar else w = h * ar
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, g.cx, g.cy, g.cz)
            Matrix.scaleM(model, 0, w, h, 1f)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            tint[0] = a; tint[1] = a; tint[2] = a; tint[3] = a
            var uv = cinema.texMatrix
            if (fmt != VideoFormat.FLAT) {
                fmt.eyeUvMatrix(eye, stereoS)
                Matrix.multiplyMM(stereoUv, 0, cinema.texMatrix, 0, stereoS, 0)
                uv = stereoUv
            }
            oesQuad.draw(cinema.texId, mvp, tint, uv)
            return
        }
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, g.cx, g.cy, g.cz)
        Matrix.scaleM(model, 0, w, h, 1f)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        tint[0] = a; tint[1] = a; tint[2] = a; tint[3] = a
        quad.draw(p.tex, mvp, tint)
    }

    // ------------------------------------------------------- sobreposições

    private fun buildOverlays(vr: Boolean) {
        ovWorld.clear(); ovHead.clear(); ovVig.clear()

        // Retículo do olhar / cursor da mão, ancorado no ponto onde o raio atinge o painel.
        if (router.hasPointer && settings.pointer) {
            val p = router.pointerWorld
            val dist = hypot(hypot(p[0], p[1]), p[2])
            val cz = p[2] + 0.02f
            val base = if (router.pressed) floatArrayOf(0.3f, 1f, 0.5f, 0.95f) else floatArrayOf(1f, 1f, 1f, 0.9f)
            disc(ovWorld, p[0], p[1], cz, 0.006f * dist, base)
            ring(ovWorld, p[0], p[1], cz, 0.012f * dist, 0.016f * dist, 0f, 2f * PI.toFloat(), base)
            if (router.dwellProgress > 0f) {
                ring(
                    ovWorld, p[0], p[1], cz, 0.022f * dist, 0.028f * dist,
                    (-PI / 2).toFloat(), (-PI / 2 + 2 * PI * router.dwellProgress).toFloat(),
                    floatArrayOf(0.31f, 0.82f, 1f, 1f)
                )
            }
        }

        // Mãos virtuais (a partir dos 21 pontos reais). Desenhadas presas à cabeça.
        val snap = pipeline.tracker.snapshot.get()
        if (settings.handEnabled && snap != null && SystemClock.elapsedRealtime() - snap.timestampMs < 400) {
            for (h in snap.hands) addHand(ovHead, h, snap.imageAspect)
        }
        // Indicador: verde = mão detectada; âmbar = câmera ativa sem mão; azul = iniciando; vermelho = indisponível.
        if (settings.handEnabled) {
            val fresh = snap != null && SystemClock.elapsedRealtime() - snap.timestampMs < 400
            val n = if (fresh) (snap?.hands?.size ?: 0) else 0
            val dot = when (Telemetry.cameraState) {
                CameraState.ACTIVE ->
                    if (n > 0) floatArrayOf(0.3f, 1f, 0.5f, 0.95f) else floatArrayOf(1f, 0.77f, 0.3f, 0.95f)
                CameraState.INITIALIZING, CameraState.WAITING_PERMISSION -> floatArrayOf(0.31f, 0.82f, 1f, 0.95f)
                else -> floatArrayOf(1f, 0.42f, 0.42f, 0.95f)
            }
            disc(ovHead, 0f, -0.32f, -1f, 0.014f, dot)
        }

        // Vinheta de conforto (anel escuro nas bordas).
        if (vr && settings.vignette) {
            val z = -0.5f; val n = 48
            val clear = floatArrayOf(0f, 0f, 0f, 0f); val dark = floatArrayOf(0f, 0f, 0f, 0.9f)
            for (i in 0 until n) {
                val a0 = (2 * PI * i / n).toFloat(); val a1 = (2 * PI * (i + 1) / n).toFloat()
                fun vtx(a: Float, r: Float, c: FloatArray) = ovVig.v(r * cos(a), r * sin(a), z, c[0], c[1], c[2], c[3])
                vtx(a0, 0.40f, clear); vtx(a0, 0.95f, dark); vtx(a1, 0.40f, clear)
                vtx(a1, 0.40f, clear); vtx(a0, 0.95f, dark); vtx(a1, 0.95f, dark)
            }
        }
    }

    private fun disc(mb: MeshBuilder, cx: Float, cy: Float, cz: Float, r: Float, c: FloatArray) {
        val n = 16
        for (i in 0 until n) {
            val a0 = (2 * PI * i / n).toFloat(); val a1 = (2 * PI * (i + 1) / n).toFloat()
            mb.tri(cx, cy, cz, cx + r * cos(a0), cy + r * sin(a0), cz, cx + r * cos(a1), cy + r * sin(a1), cz, c)
        }
    }

    private fun ring(mb: MeshBuilder, cx: Float, cy: Float, cz: Float, r0: Float, r1: Float, a0: Float, a1: Float, c: FloatArray) {
        val n = max(4, (24 * (a1 - a0) / (2 * PI.toFloat())).toInt())
        for (i in 0 until n) {
            val s = a0 + (a1 - a0) * i / n; val e = a0 + (a1 - a0) * (i + 1) / n
            mb.quad(
                cx + r0 * cos(s), cy + r0 * sin(s), cz, cx + r1 * cos(s), cy + r1 * sin(s), cz,
                cx + r1 * cos(e), cy + r1 * sin(e), cz, cx + r0 * cos(e), cy + r0 * sin(e), cz, c
            )
        }
    }

    /** Mão virtual: palma preenchida, ossos e articulações a partir dos pontos detectados. */
    private fun addHand(mb: MeshBuilder, h: HandState, aspect: Float) {
        val d = min(0.9f * settings.panelDistance, 1.0f)
        val col = when {
            h.pinching -> floatArrayOf(0.3f, 1f, 0.5f, h.fade)
            h.pose == Pose.FIST -> floatArrayOf(1f, 0.65f, 0.2f, h.fade)
            else -> floatArrayOf(0.31f, 0.82f, 1f, h.fade)
        }
        val xs = FloatArray(21); val ys = FloatArray(21); val zs = FloatArray(21)
        val dxy = FloatArray(2)
        for (k in 0 until 21) {
            HandMapping.headSpace(h.lm[k * 3], h.lm[k * 3 + 1], aspect, dxy)
            xs[k] = dxy[0] * d; ys[k] = dxy[1] * d
            // z do MediaPipe é relativo ao pulso e impreciso: usado só como leve profundidade visual.
            zs[k] = -d - h.lm[k * 3 + 2] * 0.4f * d
        }
        val palm = floatArrayOf(col[0], col[1], col[2], 0.25f * h.fade)
        for (tri in arrayOf(intArrayOf(0, 5, 9), intArrayOf(0, 9, 13), intArrayOf(0, 13, 17))) {
            mb.tri(xs[tri[0]], ys[tri[0]], zs[tri[0]], xs[tri[1]], ys[tri[1]], zs[tri[1]], xs[tri[2]], ys[tri[2]], zs[tri[2]], palm)
        }
        val th = 0.010f * d
        for (b in HandTopology.BONES) {
            val dx = xs[b[1]] - xs[b[0]]; val dy = ys[b[1]] - ys[b[0]]
            val len = hypot(dx, dy)
            if (len < 1e-6f) continue
            val nx = -dy / len * th; val ny = dx / len * th
            mb.quad(
                xs[b[0]] + nx, ys[b[0]] + ny, zs[b[0]], xs[b[0]] - nx, ys[b[0]] - ny, zs[b[0]],
                xs[b[1]] - nx, ys[b[1]] - ny, zs[b[1]], xs[b[1]] + nx, ys[b[1]] + ny, zs[b[1]], col
            )
        }
        for (k in 0 until 21) {
            val r = if (k == 4 || k == 8 || k == 12 || k == 16 || k == 20) 0.016f * d else 0.011f * d
            disc(mb, xs[k], ys[k], zs[k], r, col)
        }
    }

    // ------------------------------------------------------ FBO e distorção

    private fun ensureFbo(w: Int, h: Int) {
        if (fbo != 0 && fboW == w && fboH == h) return
        if (fbo != 0) {
            GLES20.glDeleteFramebuffers(1, intArrayOf(fbo), 0)
            GLES20.glDeleteTextures(1, intArrayOf(fboTex), 0)
            GLES20.glDeleteRenderbuffers(1, intArrayOf(fboDepth), 0)
        }
        fboW = w; fboH = h
        fboTex = GlUtil.newTexture()
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        val rb = IntArray(1); GLES20.glGenRenderbuffers(1, rb, 0); fboDepth = rb[0]
        GLES20.glBindRenderbuffer(GLES20.GL_RENDERBUFFER, fboDepth)
        GLES20.glRenderbufferStorage(GLES20.GL_RENDERBUFFER, GLES20.GL_DEPTH_COMPONENT16, w, h)
        val fb = IntArray(1); GLES20.glGenFramebuffers(1, fb, 0); fbo = fb[0]
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, fboTex, 0)
        GLES20.glFramebufferRenderbuffer(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT, GLES20.GL_RENDERBUFFER, fboDepth)
    }

    private fun postProcess() {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glViewport(0, 0, width, height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(distProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, fboTex)
        GLES20.glUniform1i(dTex, 0)
        GLES20.glUniform1f(dK1, settings.lensK1)
        distVerts.position(0)
        GLES20.glVertexAttribPointer(dPos, 2, GLES20.GL_FLOAT, false, 16, distVerts)
        GLES20.glEnableVertexAttribArray(dPos)
        distVerts.position(2)
        GLES20.glVertexAttribPointer(dUv, 2, GLES20.GL_FLOAT, false, 16, distVerts)
        GLES20.glEnableVertexAttribArray(dUv)
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
        for (eye in 0..1) {
            val area = StereoLayout.eyeViewport(width, height, eye)          // nunca invade o outro olho
            val cal = StereoLayout.calibratedViewport(width, height, eye, settings.alignX, settings.viewScale)
            GLES20.glScissor(area[0], area[1], area[2], area[3])
            GLES20.glViewport(cal[0], cal[1], cal[2], cal[3])
            GLES20.glUniform1f(dU0, if (eye == 0) 0f else 0.5f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
    }
}
