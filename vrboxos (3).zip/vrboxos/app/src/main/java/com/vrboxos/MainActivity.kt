package com.vrboxos

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.text.InputType
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.vrboxos.hands.CameraState
import com.vrboxos.hands.CameraXSource
import com.vrboxos.hands.HandPipeline
import com.vrboxos.head.HeadPose
import com.vrboxos.head.HeadTracker
import com.vrboxos.input.InputRouter
import com.vrboxos.media.CinemaPlayer
import com.vrboxos.render.VrRenderer
import com.vrboxos.settings.OrientationMode
import com.vrboxos.settings.Settings
import com.vrboxos.ui.SpatialUi
import com.vrboxos.web.BrowserController

class MainActivity : ComponentActivity(), AppController {
    private lateinit var settings: Settings
    private val head = HeadPose()
    private lateinit var headTracker: HeadTracker
    private lateinit var cinema: CinemaPlayer
    private lateinit var pipeline: HandPipeline
    private lateinit var ui: SpatialUi
    private lateinit var router: InputRouter
    private lateinit var renderer: VrRenderer
    private lateinit var glView: GLSurfaceView
    private lateinit var feedback: Feedback
    private lateinit var root: FrameLayout
    private lateinit var browser: BrowserController
    private var lastBack = 0L

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) enableHand() else onCameraDenied()
    }

    /** Explica por que a câmera é necessária e permite tentar de novo (ou abrir as configurações). */
    private fun onCameraDenied() {
        settings.handEnabled = false
        Telemetry.cameraState = CameraState.UNAVAILABLE
        Telemetry.cameraError = "permissão de câmera negada"
        ui.notify("Permissão de câmera negada: usando sensores e olhar.")
        val permanent = !shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
        AlertDialog.Builder(this)
            .setTitle("Câmera não autorizada")
            .setMessage(
                "A câmera só é usada para detectar suas mãos. Sem ela o app continua com sensores e olhar." +
                    if (permanent) " Para autorizar, abra as configurações do app." else " Você pode tentar de novo."
            )
            .setPositiveButton(if (permanent) "Abrir configurações" else "Tentar de novo") { _, _ ->
                if (permanent) startActivity(
                    Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                ) else permLauncher.launch(Manifest.permission.CAMERA)
            }
            .setNegativeButton("Agora não", null)
            .show()
    }

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            cinema.load(uri)
            ui.notify("Vídeo carregado")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        settings = Settings(this)
        feedback = Feedback(this, settings)
        cinema = CinemaPlayer(applicationContext)
        pipeline = HandPipeline(this, settings) { msg -> if (::ui.isInitialized) ui.notify(msg) }
        root = FrameLayout(this)
        browser = BrowserController(this, { root }) { msg -> if (::ui.isInitialized) ui.notify(msg) }
        ui = SpatialUi(applicationContext, settings, head, this, pipeline, cinema, browser)
        router = InputRouter(ui, settings, feedback, pipeline, this)
        ui.router = router
        headTracker = HeadTracker(this, head) { displayRotation() }
        renderer = VrRenderer(applicationContext, ui, head, settings, cinema, router, pipeline)
        renderer.vrMode = settings.vrMode

        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnTouchListener { _, e ->
                if (!renderer.vrMode) {   // modo plano (configuração fora do headset): toque normal
                    val x = e.x; val y = e.y; val a = e.actionMasked
                    queueEvent { router.touch(x, y, a) }
                } else if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    // No VR, um toque (ex.: botão condutivo do headset) clica onde o olhar aponta.
                    queueEvent { router.onKey(KeyEvent.KEYCODE_BUTTON_A) }
                }
                true
            }
        }
        // O WebView do navegador é adicionado ANTES da superfície GL (fica atrás dela, só renderiza).
        root.addView(glView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        hideSystemBars()
        VrLog.i("app", "criada: ${Build.MANUFACTURER} ${Build.MODEL} Android ${Build.VERSION.SDK_INT}; display=${displayRotation() * 90}°; modo VR=${settings.vrMode}; orientação=${settings.orientation}")
        applyOrientation()

        onBackPressedDispatcher.addCallback(this) {
            glView.queueEvent {
                if (!ui.back()) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastBack < 2000) runOnUiThread { finish() }
                    else { lastBack = now; ui.notify("Aperte voltar de novo para sair") }
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        VrLog.i("app", "onResume: display=${displayRotation() * 90}°")
        browser.onResume()
        applyHeadTracking()
        updateDisplayRotation()
        CameraXSource.probe(this)
        if (settings.handEnabled) {
            if (hasCameraPermission()) pipeline.start() else settings.handEnabled = false
        }
    }

    override fun onPause() {
        VrLog.i("app", "onPause")
        browser.onPause()
        pipeline.stop()
        headTracker.stop()
        cinema.pause()
        glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        browser.destroy()
        pipeline.release()
        cinema.release()
        feedback.release()
        super.onDestroy()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        // Teclas de mídia de controles Bluetooth: reprodução do cinema sem tocar na tela.
        when (code) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE,
            KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    when (code) {
                        KeyEvent.KEYCODE_MEDIA_PLAY -> if (!cinema.isPlaying) cinema.togglePlay()
                        KeyEvent.KEYCODE_MEDIA_PAUSE -> if (cinema.isPlaying) cinema.togglePlay()
                        KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> cinema.seekBy(10_000)
                        KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_MEDIA_REWIND -> cinema.seekBy(-10_000)
                        else -> cinema.togglePlay()
                    }
                }
                return true
            }
        }
        val handled = when (code) {
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_MENU -> true
            else -> false
        }
        if (handled) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) glView.queueEvent { router.onKey(code) }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun enableHand() {
        settings.handEnabled = true
        pipeline.start()
        ui.notify("Hand tracking iniciado (${settings.camera.label})")
    }

    // ---------------------------------------------------------- AppController

    /** Teclado do Android (só no modo plano: no VR ele cobriria/quebraria a tela dividida). */
    override fun promptText(title: String, initial: String, onResult: (String) -> Unit) {
        runOnUiThread {
            val input = EditText(this).apply {
                setText(initial); setSelectAllOnFocus(true); setSingleLine()
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                imeOptions = EditorInfo.IME_ACTION_GO
            }
            val dlg = AlertDialog.Builder(this).setTitle(title).setView(input)
                .setPositiveButton("Ir") { _, _ -> onResult(input.text.toString()) }
                .setNegativeButton("Cancelar", null).create()
            input.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) { onResult(input.text.toString()); dlg.dismiss(); true } else false
            }
            dlg.show()
            input.requestFocus()
            dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
    }

    override fun shareLog() {
        runOnUiThread {
            val header = "VR BOX OS - ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.SDK_INT}\n" +
                "display=${displayRotation() * 90}° vr=${renderer.vrMode} orientação=${settings.orientation} " +
                "câmera=${Telemetry.cameraState.label} sensores: ${Telemetry.sensorsText}\n\n"
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Log do VR BOX OS")
                putExtra(Intent.EXTRA_TEXT, header + VrLog.dump())
            }
            startActivity(Intent.createChooser(i, "Compartilhar log"))
        }
    }

    override fun pickVideo() { runOnUiThread { pickLauncher.launch(arrayOf("video/*")) } }

    override fun setHandTracking(enable: Boolean) = runOnUiThread {
        when {
            !enable -> {
                settings.handEnabled = false
                pipeline.stop()
                ui.notify("Hand tracking desligado")
            }
            hasCameraPermission() -> enableHand()
            else -> {
                Telemetry.cameraState = CameraState.WAITING_PERMISSION
                Telemetry.cameraError = null
                AlertDialog.Builder(this)
                .setTitle("Permissão da câmera")
                .setMessage(
                    "O VR BOX OS usa a câmera somente para detectar suas mãos neste aparelho. " +
                        "As imagens são processadas em memória e não são gravadas nem enviadas. " +
                        "Conceda a permissão com o aparelho fora do headset."
                )
                .setPositiveButton("Continuar") { _, _ -> permLauncher.launch(Manifest.permission.CAMERA) }
                .setNegativeButton("Agora não") { _, _ -> Telemetry.cameraState = CameraState.OFF }
                .setOnCancelListener { Telemetry.cameraState = CameraState.OFF }
                .show().let { }
            }
        }
    }

    override fun restartHandSource() { runOnUiThread { if (settings.handEnabled && hasCameraPermission()) pipeline.restart() } }

    override fun applyOrientation() {
        runOnUiThread {
            VrLog.i("orient", "aplicando orientação: modo=${settings.orientation} vr=${renderer.vrMode} (display agora ${displayRotation() * 90}°)")
            requestedOrientation = when (settings.orientation) {
                OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                OrientationMode.LANDSCAPE_REVERSE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                // Automática: livre fora do VR; paisagem nos dois sentidos dentro do VR.
                OrientationMode.AUTO ->
                    if (renderer.vrMode) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            }
        }
    }

    /** Registra os sensores só se o rastreio da cabeça está ligado; 200 Hz no VR, 60 Hz no modo plano. */
    override fun applyHeadTracking() {
        runOnUiThread {
            if (settings.headTracking) {
                if (!headTracker.start(renderer.vrMode)) ui.notify("Sem sensores de movimento: a visão não acompanha a cabeça.")
            } else {
                headTracker.stop()
                Telemetry.headStatus = "Desligado"
            }
        }
    }

    private fun updateDisplayRotation() { Telemetry.displayRotationDeg = displayRotation() * 90 }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDisplayRotation()   // paisagem <-> paisagem invertida: a leitura do sensor usa isto a cada evento
        VrLog.i("orient", "configuração mudou: display=${displayRotation() * 90}° orientation=${newConfig.orientation} (1=retrato, 2=paisagem) vr=${renderer.vrMode}")
    }

    override fun setVrMode(vr: Boolean) {
        settings.vrMode = vr
        renderer.vrMode = vr
        applyOrientation()
        applyHeadTracking()
        ui.notify(if (vr) "Modo VR: coloque o aparelho no headset" else "Modo plano (configuração)")
    }

    override fun isVrMode() = renderer.vrMode
    override fun recenter() { head.recenter() }
    override fun exitApp() { runOnUiThread { finish() } }
}
