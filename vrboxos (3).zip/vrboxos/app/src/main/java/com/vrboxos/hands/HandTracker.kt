package com.vrboxos.hands

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.vrboxos.Telemetry
import com.vrboxos.VrLog
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Executa o MediaPipe Hand Landmarker (21 pontos por mão, até 2 mãos) e alimenta o GestureEngine.
 * Decisão: usamos Hand Landmarker + classificador geométrico próprio (GestureEngine), porque o
 * Gesture Recognizer pronto não oferece pinça nem "agarrar" e não expõe histerese/limiares.
 */
class HandTracker(private val context: Context, private val engine: GestureEngine) {
    val snapshot = AtomicReference<HandSnapshot?>(null)
    @Volatile var error: String? = null
        private set
    @Volatile var wantThumbnail = false
    /** Quando true, gera a prévia (imagem real + pontos das mãos) usada na tela/fundo de câmera. */
    @Volatile var wantPreview = false
    val previewBitmap = AtomicReference<Bitmap?>(null)
    val previewSeq = AtomicInteger(0)
    private var lastPreviewMs = 0L
    private val pPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val lPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3f; color = 0xFF4FD1FF.toInt() }
    private val dPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    @Volatile var thumbnail: Bitmap? = null
        private set

    private val lock = Any()
    private var landmarker: HandLandmarker? = null
    private var lastTs = 0L
    private var frames = 0
    private var fpsStart = 0L
    private var latencyEma = 0f
    private var lumaCount = 0
    private var inferFails = 0
    private var darkStreak = 0

    /** Carrega o modelo (assets/hand_landmarker.task). Retorna false e preenche [error] se falhar. */
    fun init(): Boolean = synchronized(lock) {
        if (landmarker != null) return true
        try {
            val base = BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build()
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = HandLandmarker.createFromOptions(context, opts)
            error = null
            true
        } catch (e: Exception) {
            error = "Modelo não carregou ($MODEL_ASSET): ${e.message}"
            VrLog.e("hands", "init do MediaPipe falhou", e)
            false
        }
    }

    /**
     * Chamado na thread de análise com um bitmap vertical. A CÂMERA conta como ativa assim que chegam
     * quadros válidos, mesmo se o modelo de mãos falhar: nesse caso só o reconhecimento fica indisponível.
     */
    fun onFrame(bitmap: Bitmap, nowMs: Long, mirrorHands: Boolean) {
        synchronized(lock) {
            val ts = if (nowMs <= lastTs) lastTs + 1 else nowMs
            lastTs = ts
            val aspect = bitmap.width.toFloat() / bitmap.height.toFloat()
            val raw = ArrayList<RawHand>(2)
            val l = landmarker
            if (l != null) {
                val t0 = SystemClock.elapsedRealtime()
                try {
                    val res = l.detectForVideo(BitmapImageBuilder(bitmap).build(), ts)
                    val lms = res.landmarks()
                    val hands = res.handedness()
                    for (i in lms.indices) {
                        val a = FloatArray(63)
                        for (k in 0 until 21) {
                            val p = lms[i][k]
                            a[k * 3] = p.x(); a[k * 3 + 1] = p.y(); a[k * 3 + 2] = p.z()
                        }
                        val cat = hands.getOrNull(i)?.firstOrNull()
                        raw.add(RawHand(a, cat?.categoryName() ?: "?", cat?.score() ?: 0.5f))
                    }
                    val lat = (SystemClock.elapsedRealtime() - t0).toFloat()
                    latencyEma = if (latencyEma == 0f) lat else latencyEma * 0.9f + lat * 0.1f
                    snapshot.set(engine.process(ts, raw, aspect, mirrorHands, latencyEma))
                    Telemetry.handLatencyMs = latencyEma
                    Telemetry.handStatus = "Rodando"
                    Telemetry.handsError = null
                } catch (e: Exception) {
                    raw.clear()
                    error = "Inferência falhou: ${e.message}"
                    Telemetry.handsError = "inferência falhou"
                    Telemetry.handStatus = "Erro: ${e.message}"
                    if (++inferFails <= 3) VrLog.e("hands", "detectForVideo falhou", e)
                }
            } else {
                Telemetry.handStatus = "Mãos indisponíveis (sem modelo)"
            }

            // Um quadro recebido = imagem válida. Só então a câmera passa a "Ativa".
            Telemetry.framesReceived++
            Telemetry.lastFrameMs = SystemClock.elapsedRealtime()
            if (Telemetry.cameraState == CameraState.INITIALIZING && Telemetry.framesReceived >= 3) {
                Telemetry.cameraState = CameraState.ACTIVE
                Telemetry.cameraError = null
                VrLog.i("camera", "ATIVA: ${Telemetry.framesReceived} quadros ${bitmap.width}x${bitmap.height}")
            }
            if (wantPreview && ts - lastPreviewMs >= 66) { lastPreviewMs = ts; publishPreview(bitmap, raw, aspect) }

            frames++
            if (fpsStart == 0L) fpsStart = ts
            if (ts - fpsStart >= 1000) {
                Telemetry.handFps = frames * 1000f / (ts - fpsStart)
                frames = 0; fpsStart = ts
            }
            // Câmera bloqueada? Mede o brilho médio de uma miniatura 8x8 a cada 8 quadros.
            if (++lumaCount % 8 == 0) {
                val tiny = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
                var sum = 0f
                for (yy in 0 until 8) for (xx in 0 until 8) {
                    val px = tiny.getPixel(xx, yy)
                    sum += 0.299f * ((px shr 16) and 0xFF) + 0.587f * ((px shr 8) and 0xFF) + 0.114f * (px and 0xFF)
                }
                if (tiny !== bitmap) tiny.recycle()
                if (sum / 64f < 12f) { darkStreak++; if (darkStreak >= 3) Telemetry.cameraObstructed = true }
                else { darkStreak = 0; Telemetry.cameraObstructed = false }
            }
            if (wantThumbnail && frames % 3 == 0) {
                thumbnail = Bitmap.createScaledBitmap(bitmap, 160, (160f / aspect).toInt().coerceAtLeast(1), true)
            }
        }
    }

    /** Prévia já na vertical e espelhada como a imagem processada, com os 21 pontos alinhados. */
    private fun publishPreview(src: Bitmap, raw: List<RawHand>, aspect: Float) {
        val w = 320
        val h = (w / aspect).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawBitmap(src, null, Rect(0, 0, w, h), pPaint)
        for (hand in raw) {
            val lm = hand.lm
            for (b in HandTopology.BONES) {
                c.drawLine(lm[b[0] * 3] * w, lm[b[0] * 3 + 1] * h, lm[b[1] * 3] * w, lm[b[1] * 3 + 1] * h, lPaint)
            }
            for (k in 0 until 21) c.drawCircle(lm[k * 3] * w, lm[k * 3 + 1] * h, 3.5f, dPaint)
        }
        previewBitmap.set(bmp)
        previewSeq.incrementAndGet()
    }

    /** Sem fonte de vídeo ativa: o motor precisa saber para expirar as mãos. */
    fun tickNoFrame(nowMs: Long) {
        synchronized(lock) {
            val s = engine.process(nowMs, emptyList(), snapshot.get()?.imageAspect ?: 1.33f, false, 0f)
            snapshot.set(s)
        }
    }

    /** Zera gestos e snapshot (a engine só pode ser tocada sob o mesmo lock da inferência). */
    fun reset() = synchronized(lock) {
        engine.reset()
        snapshot.set(null)
        darkStreak = 0
        previewBitmap.set(null)
        Telemetry.cameraObstructed = false
    }

    fun close() = synchronized(lock) {
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        snapshot.set(null)
    }

    companion object { const val MODEL_ASSET = "hand_landmarker.task" }
}
