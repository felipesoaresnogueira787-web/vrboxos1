package com.vrboxos.hands

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.CameraState as XCameraState
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.vrboxos.Telemetry
import com.vrboxos.VrLog
import com.vrboxos.settings.CameraKind
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Câmera via CameraX. FRONT/BACK são as câmeras do celular. EXTERNAL só funciona se o Android expõe a
 * câmera USB pela API Camera2 (LENS_FACING_EXTERNAL) — nem todo aparelho faz isso.
 * Se a câmera pedida não existe, tenta as outras e avisa qual foi usada.
 */
class CameraXSource(
    private val activity: ComponentActivity,
    private val kind: CameraKind,
    private val fpsCap: () -> Int
) : VideoSource {
    @Volatile private var usedKind = kind
    override val name get() = "CameraX/${usedKind.label}"
    override val mirrored get() = usedKind == CameraKind.FRONT

    /** Avisos para o usuário (ex.: "câmera X indisponível, usando Y"). */
    var onNotice: ((String) -> Unit)? = null

    private var provider: ProcessCameraProvider? = null
    private var executor: ExecutorService? = null
    @Volatile private var lastTs = 0L
    @Volatile private var stopped = false
    private var displayListener: DisplayManager.DisplayListener? = null
    private var lastRot = -1
    private var failStreak = 0

    @Suppress("DEPRECATION")
    private fun currentRotation() = activity.windowManager.defaultDisplay.rotation

    private fun facing(k: CameraKind) = when (k) {
        CameraKind.FRONT -> CameraSelector.LENS_FACING_FRONT
        CameraKind.BACK -> CameraSelector.LENS_FACING_BACK
        CameraKind.EXTERNAL -> CameraSelector.LENS_FACING_EXTERNAL
    }

    private fun selector(k: CameraKind) = CameraSelector.Builder().requireLensFacing(facing(k)).build()

    private fun has(p: ProcessCameraProvider, k: CameraKind) =
        try { p.hasCamera(selector(k)) } catch (e: Exception) { VrLog.w("camera", "hasCamera(${k.label}) falhou", e); false }

    private fun errorName(code: Int) = when (code) {
        1 -> "limite de câmeras abertas atingido"
        2 -> "câmera em uso por outro app"
        3 -> "erro recuperável"
        4 -> "configuração de stream não suportada"
        5 -> "câmera desativada por política do aparelho"
        6 -> "erro fatal da câmera"
        7 -> "bloqueada pelo modo Não Perturbe"
        else -> "código $code"
    }

    override fun start(onFrame: (Bitmap, Long) -> Unit, onError: (String) -> Unit) {
        stopped = false
        failStreak = 0
        val exec = Executors.newSingleThreadExecutor().also { executor = it }
        VrLog.i("camera", "abrindo ${kind.label}; display=${currentRotation() * 90}°")
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val order = listOf(kind) + CameraKind.values().filter { it != kind }
                val chosen = order.firstOrNull { has(p, it) }
                if (chosen == null) {
                    onError("Este aparelho não expõe nenhuma câmera (frontal, traseira ou externa)")
                    return@addListener
                }
                if (chosen != kind) {
                    VrLog.w("camera", "${kind.label} indisponível; usando ${chosen.label}")
                    onNotice?.invoke("Câmera ${kind.label} indisponível; usando ${chosen.label}")
                }
                usedKind = chosen
                @Suppress("DEPRECATION")
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST) // descarta quadros velhos
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy ->
                    try {
                        if (!stopped) handle(proxy, onFrame)
                        failStreak = 0
                    } catch (t: Throwable) {
                        VrLog.e("camera", "falha ao processar quadro", t)
                        if (++failStreak >= 5) onError("falha repetida ao processar quadros: ${t.message}")
                    } finally {
                        proxy.close()
                    }
                }
                p.unbindAll()
                val cam = p.bindToLifecycle(activity, selector(chosen), analysis)
                // O CameraX só ajusta a rotação da imagem para a rotação do display informada.
                analysis.targetRotation = currentRotation()
                val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                val l = object : DisplayManager.DisplayListener {
                    override fun onDisplayAdded(displayId: Int) {}
                    override fun onDisplayRemoved(displayId: Int) {}
                    override fun onDisplayChanged(displayId: Int) {
                        val r = currentRotation()
                        if (analysis.targetRotation != r) {
                            VrLog.i("camera", "display mudou: targetRotation ${analysis.targetRotation} -> $r")
                            analysis.targetRotation = r
                        }
                    }
                }
                dm.registerDisplayListener(l, Handler(Looper.getMainLooper()))
                displayListener = l
                VrLog.i("camera", "vinculada: ${chosen.label}, espelhada=$mirrored")
                cam.cameraInfo.cameraState.observe(activity) { st ->
                    val err = st.error
                    VrLog.i("camera", "estado do CameraX: ${st.type}" + (err?.let { " erro=${it.code} (${errorName(it.code)}) tipo=${it.type}" } ?: ""))
                    if (err != null) {
                        // Erros recuperáveis (ex.: câmera em uso) o CameraX tenta de novo sozinho: não derrubar.
                        if (err.type == XCameraState.ERROR_TYPE_CRITICAL) onError("Erro crítico da câmera: ${errorName(err.code)}")
                        else onNotice?.invoke("Câmera: ${errorName(err.code)} (tentando de novo)")
                    }
                }
            } catch (e: Exception) {
                VrLog.e("camera", "falha ao abrir a câmera", e)
                onError("${e.javaClass.simpleName}: ${e.message ?: "erro ao abrir a câmera"}")
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    private fun handle(proxy: ImageProxy, onFrame: (Bitmap, Long) -> Unit) {
        val now = SystemClock.elapsedRealtime()
        val minInterval = 1000L / fpsCap().coerceAtLeast(1)
        if (now - lastTs < minInterval) return
        lastTs = now
        val rot = proxy.imageInfo.rotationDegrees
        if (rot != lastRot) {
            // Registra QUALQUER mudança de rotação aplicada à imagem: mostra quem a alterou e quando.
            VrLog.i("camera", "quadro ${proxy.width}x${proxy.height} rotationDegrees $lastRot -> $rot (display=${currentRotation() * 90}°, espelhado=$mirrored)")
            lastRot = rot
        }
        val src = proxy.toBitmap()
        val m = Matrix()
        m.postRotate(rot.toFloat())
        if (mirrored) m.postScale(-1f, 1f)
        val upright = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (upright !== src) src.recycle()
        onFrame(upright, now)
    }

    override fun stop() {
        stopped = true
        displayListener?.let {
            try { (activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(it) } catch (_: Exception) {}
        }
        displayListener = null
        try { provider?.unbindAll() } catch (_: Exception) {}
        executor?.shutdown()
        executor = null
        VrLog.i("camera", "fechada")
    }

    companion object {
        /** Descobre quais fontes o aparelho oferece (para a tela de diagnóstico). */
        fun probe(activity: ComponentActivity) {
            val future = ProcessCameraProvider.getInstance(activity)
            future.addListener({
                try {
                    val p = future.get()
                    fun has(k: Int) = try {
                        p.hasCamera(CameraSelector.Builder().requireLensFacing(k).build())
                    } catch (_: Exception) { false }
                    fun s(b: Boolean) = if (b) "sim" else "não"
                    Telemetry.sourcesText = "Frontal ${s(has(CameraSelector.LENS_FACING_FRONT))} / " +
                        "Traseira ${s(has(CameraSelector.LENS_FACING_BACK))} / " +
                        "Externa ${s(has(CameraSelector.LENS_FACING_EXTERNAL))}"
                } catch (e: Exception) {
                    Telemetry.sourcesText = "indisponível"
                    VrLog.w("camera", "probe falhou", e)
                }
            }, ContextCompat.getMainExecutor(activity))
        }
    }
}
