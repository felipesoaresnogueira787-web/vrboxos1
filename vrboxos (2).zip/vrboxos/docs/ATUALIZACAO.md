# Atualização: modo VR lado a lado, calibração, orientação, câmera e mídia

> **O ZIP citado no pedido não chegou** (pasta de uploads vazia). Esta atualização foi feita sobre o
> projeto VR BOX OS desta conversa. Nenhum arquivo foi recriado; as telas e funções existentes foram mantidas.

## Arquivos novos
`media/VideoFormat.kt`, `render/SphereMesh.kt`, `app/src/test/.../StereoCalibrationTest.kt`, `docs/ATUALIZACAO.md`.

## Arquivos alterados
`settings/Settings.kt` (alinhamento, escala, orientação) · `render/StereoLayout.kt` (viewport calibrado, FOV) ·
`render/VrRenderer.kt` (calibração no pós-processamento, esfera 360, guias, FOV) · `render/Renderers.kt`
(SphereRenderer) · `media/CinemaPlayer.kt` (formato, mudo, foco de áudio) · `ui/SpatialUi.kt` (tela de calibração,
Entrar/Sair VR, novas linhas de configuração, controles do cinema, avisos) · `input/InputRouter.kt` (FOV do toque) ·
`hands/CameraXSource.kt` (rotação acompanha o display) · `hands/HandTracker.kt` (câmera escura) ·
`hands/HandPipeline.kt`, `Telemetry.kt`, `AppController.kt`, `MainActivity.kt` (permissão, orientação, toque no VR) ·
`README.md`, `docs/STATUS.md`.

## Correções
* Rotação da câmera não acompanhava o display (imagem de cabeça para baixo ao virar o celular): agora o
  `ImageAnalysis.targetRotation` é atualizado por `DisplayListener`. **Não há "inversão da interface inteira".**
* Orientação: agora há modos automático/paisagem/invertida e `requestedOrientation` é reaplicado ao entrar/sair do VR.
* Em telas em pé o campo de visão horizontal era cortado: o FOV vertical é recalculado pela proporção.

## O que foi testado
Somente em Python (replicando as mesmas fórmulas) e por análise estática: viewport calibrado, FOV, UV por olho,
malha da esfera, balanceamento e referências. Testes JVM novos estão escritos e **não foram executados**.
Nada foi compilado nem rodado em celular/headset.

## Depende de celular + headset reais
Alinhamento correto nas lentes, sinal/valor da distorção, orientação em cada sentido, áudio/sincronia,
câmera externa USB, desempenho térmico, qualidade do reconhecimento de mãos.


---

# Segunda atualização: câmera integrada ao ambiente, estados reais, sensores e diagnóstico

> **O ZIP citado no pedido continua sem chegar** (uploads vazios nas duas vezes). O trabalho segue sobre o
> VR BOX OS desta conversa; nada foi recriado.

## Arquivos novos
`hands/CameraState.kt`, `app/src/test/.../HeadTrackingTest.kt`.

## Arquivos alterados
`hands/HandPipeline.kt` (estados, watchdog, partida idempotente, `restart()`) · `hands/HandTracker.kt`
(quadros válidos, prévia com pontos) · `head/HeadTracker.kt` e `head/Quat.kt` (giroscópio, taxa, sensores) ·
`render/VrRenderer.kt` (textura da câmera, painel e fundo, indicador, marcadores de orientação) ·
`ui/SpatialUi.kt`, `ui/Panel.kt` (tela Câmera, status, configurações, diagnóstico) · `MainActivity.kt`,
`AppController.kt`, `Telemetry.kt` (permissão, sensores sob demanda, teclas de mídia) · `README.md`, `docs/STATUS.md`.

## Sobre a imagem "de cabeça para baixo"
Não consegui reproduzir (não há aparelho). Foi verificado, por conta e análise estática: (1) a cadeia
sensor -> tela -> mundo GL dá identidade para um celular em paisagem, de pé, olhando ao Norte, nos dois
sentidos de paisagem; (2) o caminho de textura dos painéis e do pós-processamento não inverte o eixo vertical;
(3) a rotação do `ImageAnalysis` da câmera não acompanhava o display (corrigido na atualização anterior).
Se ainda ocorrer, o Diagnóstico agora mostra a rotação do display, a inclinação e o giro (roll) lidos do sensor
e a Calibração mostra marcadores de "topo": com esses números dá para apontar a causa real sem chute.
Não foi aplicada nenhuma rotação fixa de 180°.

## O que foi testado
Somente análise estática e replicação em Python das contas (giroscópio, viewport, UV, esfera). Testes JVM
escritos e **não executados**. **Nada foi compilado nem rodado em celular ou headset.**

## Depende de celular + headset reais
Orientação nos dois sentidos de paisagem; estados da câmera na prática; imagem real chegando; qualidade do
reconhecimento de mãos; se a câmera enxerga as mãos com o aparelho no headset; câmera externa USB; deriva do
giroscópio puro; áudio e sincronia; temperatura e bateria.
