package com.vrboxos

import com.vrboxos.hands.CameraState
import com.vrboxos.head.HeadMath
import com.vrboxos.head.Quat
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI

class HeadTrackingTest {
    private fun fwd(q: Quat) = q.rotate(floatArrayOf(0f, 0f, -1f))
    private val quarter = (PI / 2).toFloat()

    @Test fun gyroYawTurnsTheViewLeft() {
        var q = Quat.IDENTITY
        repeat(10) { q = HeadMath.integrateGyro(q, 0f, quarter, 0f, 0.1f, 0) }   // 90°/s por 1 s
        val f = fwd(q)
        assertEquals(-1f, f[0], 1e-3f); assertEquals(0f, f[1], 1e-3f); assertEquals(0f, f[2], 1e-3f)
    }

    @Test fun gyroAtRestKeepsOrientation() {
        val q = Quat.fromAxisAngle(0f, 1f, 0f, 0.5f)
        assertEquals(q, HeadMath.integrateGyro(q, 0f, 0f, 0f, 0.01f, 0))
        assertEquals(q, HeadMath.integrateGyro(q, 1f, 1f, 1f, 0f, 0))     // dt=0: nada muda
    }

    @Test fun gyroAxesFollowTheDisplayRotation() {
        // Em ROTATION_90 o eixo X do aparelho corresponde a "-Y da tela": girar em torno dele vira a visão para a direita.
        var q = Quat.IDENTITY
        repeat(10) { q = HeadMath.integrateGyro(q, quarter, 0f, 0f, 0.1f, 1) }
        val f = fwd(q)
        assertEquals(1f, f[0], 1e-3f); assertEquals(0f, f[2], 1e-3f)
    }

    @Test fun gyroKeepsAUnitQuaternion() {
        var q = Quat.IDENTITY
        repeat(2000) { q = HeadMath.integrateGyro(q, 0.3f, -0.2f, 0.5f, 0.005f, 3) }
        assertEquals(1f, q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z, 1e-3f)
    }

    @Test fun cameraIsOnlyFreshWithRecentFrames() {
        Telemetry.lastFrameMs = 0L
        assertFalse(Telemetry.cameraFresh(1000))            // nunca chegou quadro
        Telemetry.lastFrameMs = 900L
        assertTrue(Telemetry.cameraFresh(1000))
        assertFalse(Telemetry.cameraFresh(3000))            // parou de chegar
        Telemetry.lastFrameMs = 0L
    }

    @Test fun cameraStatesAreTheFiveRequested() {
        val labels = CameraState.values().map { it.label }
        assertEquals(5, labels.size); assertEquals(5, labels.toSet().size)
        assertEquals(CameraState.OFF, CameraState.values().first())
        assertTrue("Ativa" in labels && "Inicializando" in labels && "Aguardando permissão" in labels)
    }
}
