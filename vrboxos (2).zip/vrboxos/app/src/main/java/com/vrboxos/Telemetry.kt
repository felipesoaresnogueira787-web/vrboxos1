package com.vrboxos

/** Métricas compartilhadas entre threads (somente leitura na UI). */
object Telemetry {
    @Volatile var cameraState = com.vrboxos.hands.CameraState.OFF
    @Volatile var cameraError: String? = null
    @Volatile var framesReceived = 0
    @Volatile var lastFrameMs = 0L
    @Volatile var sensorsText = "?"
    @Volatile var displayRotationDeg = 0
    @Volatile var headPitchDeg = 0f
    @Volatile var headRollDeg = 0f
    /** Chegou quadro da câmera há pouco tempo? (evita mostrar "ativa" sem imagens) */
    fun cameraFresh(now: Long) = lastFrameMs != 0L && now - lastFrameMs < 1500
    @Volatile var renderFps = 0f
    @Volatile var handFps = 0f
    @Volatile var handLatencyMs = 0f
    @Volatile var handStatus = "Desligado"
    @Volatile var sourceName = "-"
    @Volatile var sourcesText = "?"
    @Volatile var headStatus = "Iniciando"
    @Volatile var headRateHz = 0f
    @Volatile var batteryPct = -1
    @Volatile var batteryTempC = Float.NaN
    @Volatile var charging = false
    @Volatile var net = "?"
    @Volatile var thermal = 0
    @Volatile var thermalThrottle = false
    @Volatile var inputMethod = "Olhar"
    /** true se a imagem da câmera ficou escura por alguns segundos (possível bloqueio pelo headset). */
    @Volatile var cameraObstructed = false
}
