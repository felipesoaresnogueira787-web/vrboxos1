package com.vrboxos

/** Ações que a interface espacial pede ao Activity. */
interface AppController {
    fun pickVideo()
    fun setHandTracking(enable: Boolean)
    fun restartHandSource()
    fun setVrMode(vr: Boolean)
    fun isVrMode(): Boolean
    fun recenter()
    /** Aplica a orientação escolhida (automática/paisagem/invertida) à Activity. */
    fun applyOrientation()
    /** Liga/desliga o registro dos sensores conforme a configuração e o modo (VR ou plano). */
    fun applyHeadTracking()
    fun exitApp()
}
