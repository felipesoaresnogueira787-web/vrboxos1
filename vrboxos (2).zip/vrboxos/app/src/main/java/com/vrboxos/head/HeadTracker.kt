package com.vrboxos.head

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import com.vrboxos.Telemetry
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Orientação da cabeça pelos sensores do aparelho (somente rotação, 3DoF; NÃO mede posição).
 * Preferência: vetor de rotação de jogo (giroscópio + acelerômetro já fundidos pelo Android);
 * depois vetor de rotação com magnetômetro; por último, integração do giroscópio (com deriva).
 */
class HeadTracker(
    ctx: Context,
    private val pose: HeadPose,
    private val displayRotation: () -> Int
) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var thread: HandlerThread? = null
    private var smoothed: Quat? = null
    private var lastNs = 0L
    private var countStart = 0L
    private var count = 0
    private var gyroMode = false

    @Volatile var available = false
        private set

    private fun yn(s: Sensor?) = if (s != null) "sim" else "não"

    /** [highRate]: 200 Hz no VR; 60 Hz no modo plano (economiza bateria). Seguro chamar de novo. */
    fun start(highRate: Boolean = true): Boolean {
        stop()
        val rv = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        Telemetry.sensorsText = "Giroscópio ${yn(gyro)}, acelerômetro ${yn(acc)}, vetor de rotação ${yn(rv)}"
        val chosen = rv ?: gyro
        if (chosen == null) {
            available = false
            Telemetry.headStatus = "Sem giroscópio nem vetor de rotação: a visão não acompanha a cabeça"
            return false
        }
        gyroMode = rv == null
        val t = HandlerThread("vrboxos-head").also { it.start() }
        thread = t
        // 5000 µs = 200 Hz (acima disso o Android 12+ exige permissão especial).
        val period = if (highRate) 5000 else 16667
        val ok = sm.registerListener(this, chosen, period, Handler(t.looper))
        available = ok
        Telemetry.headStatus = when {
            !ok -> "Falha ao registrar o sensor"
            gyroMode -> "Giroscópio puro (sem correção de deriva)"
            else -> "OK (${chosen.name})"
        }
        return ok
    }

    fun stop() {
        sm.unregisterListener(this)
        thread?.quitSafely()
        thread = null
        smoothed = null
        lastNs = 0L
        available = false
        Telemetry.headRateHz = 0f
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (gyroMode) onGyro(e) else onRotationVector(e)
        countRate(e.timestamp)
    }

    private fun onGyro(e: SensorEvent) {
        val dt = if (lastNs == 0L) 0f else (e.timestamp - lastNs) / 1_000_000_000f
        lastNs = e.timestamp
        if (dt <= 0f || dt > 0.1f) return          // ignora o primeiro evento e grandes pausas
        pose.raw = HeadMath.integrateGyro(pose.raw, e.values[0], e.values[1], e.values[2], dt, displayRotation())
    }

    private fun onRotationVector(e: SensorEvent) {
        val v = e.values
        val x = v[0]; val y = v[1]; val z = v[2]
        val w = if (v.size > 3) v[3] else sqrt(max(0f, 1f - x * x - y * y - z * z))
        val qh = HeadMath.sensorToHead(Quat(w, x, y, z).normalized(), displayRotation())
        val prev = smoothed
        val dtMs = if (lastNs == 0L) 0f else (e.timestamp - lastNs) / 1_000_000f
        lastNs = e.timestamp
        val tau = pose.smoothingTauMs
        val q = if (prev == null || tau <= 0f || dtMs <= 0f) qh
        else Quat.nlerp(prev, qh, 1f - exp(-dtMs / tau))
        smoothed = q
        pose.raw = q
    }

    private fun countRate(ts: Long) {
        count++
        if (countStart == 0L) countStart = ts
        if (ts - countStart >= 1_000_000_000L) {
            Telemetry.headRateHz = count * 1e9f / (ts - countStart)
            count = 0; countStart = ts
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
