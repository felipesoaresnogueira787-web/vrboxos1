package com.vrboxos.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import com.vrboxos.AppController
import com.vrboxos.Telemetry
import com.vrboxos.hands.CameraState
import com.vrboxos.settings.CameraKind
import com.vrboxos.hands.HandPipeline
import com.vrboxos.hands.HandTopology
import com.vrboxos.head.HeadPose
import com.vrboxos.head.Quat
import com.vrboxos.input.InputRouter
import com.vrboxos.VrLog
import com.vrboxos.ar.ArTracker
import com.vrboxos.media.CinemaPlayer
import com.vrboxos.web.BrowserController
import com.vrboxos.media.VideoFormat
import com.vrboxos.render.EnvMesh
import com.vrboxos.render.Environments
import com.vrboxos.render.GlUtil
import com.vrboxos.settings.Settings
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.min

enum class Screen { HOME, CINEMA, SETTINGS, DIAG, TUTORIAL, ENV, CALIB, CAMERA, BROWSER, LOG, PERF }

/** Interface espacial: painéis, telas, hit-test e estado de navegação. Roda na thread GL. */
class SpatialUi(
    private val ctx: Context,
    private val settings: Settings,
    private val head: HeadPose,
    private val controller: AppController,
    private val pipeline: HandPipeline,
    private val cinema: CinemaPlayer,
    val browser: BrowserController,
    private val ar: ArTracker
) {
    var router: InputRouter? = null

    var screen = Screen.HOME
        private set
    var flatTheater = false
        private set
    /** Imagem real da câmera como fundo da cena (em vez do ambiente 3D). */
    private var manualBg = false
    /** Fundo = imagem real da câmera: escolhido à mão (Câmera) ou pelo ambiente "Minha Casa". */
    val cameraBackground: Boolean get() = manualBg || settings.environment == Environments.HOME_INDEX
    private var homeAutoStarted = false
    private var autoStartedCamera = false

    private val status = Panel("status", 0f, 0.82f, 1.1f, 0.09f, 1100, 90)
    private val main = Panel("main", 0f, 0.10f, 2.0f, 1.125f, 1280, 720, headerPx = 80f)
    private val dock = Panel("dock", 0f, -0.78f, 1.3f, 0.177f, 1100, 150)
    private val video = Panel("video", 0f, 0.25f, 3.2f, 1.8f, 1280, 720).also { it.isVideo = true; it.layoutFactor = 0.75f }
    private val controls = Panel("controls", 0f, -0.95f, 2.2f, 0.367f, 1200, 200).also { it.layoutFactor = 0.75f }
    private val camView = Panel("camview", 0f, 0.28f, 1.8f, 1.35f, 640, 480).also { it.isCamera = true }
    private val camBar = Panel("cambar", 0f, -0.95f, 2.2f, 0.367f, 1200, 200)
    private val webView = Panel("webview", 0f, -0.05f, 2.4f, 1.35f, 1280, 720).also { it.isWeb = true; it.layoutFactor = 0.8f }
    private val webBar = Panel("webbar", 0f, 0.84f, 2.4f, 0.375f, 1280, 200).also { it.layoutFactor = 0.8f }
    private val kbd = Panel("kbd", 0f, -1.3f, 2.4f, 0.806f, 1280, 430).also { it.layoutFactor = 0.8f }
    private val all = listOf(video, camView, main, webView, controls, camBar, webBar, kbd, dock, status)          // ordem de desenho
    private val hitOrder = listOf(status, dock, kbd, webBar, camBar, controls, main, webView, camView, video)     // da frente para trás

    private var hoverPanel: Panel? = null
    private var hoverButton: String? = null
    private val notes = ArrayDeque<Pair<String, String>>()
    private val pending = ConcurrentLinkedQueue<String>()
    private val envCache = arrayOfNulls<EnvMesh>(4)
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEE, d MMM", Locale("pt", "BR"))

    private var lastUpdate = 0L
    private var lastSecond = 0L
    private var lastFast = 0L
    private var settingsPage = 0
    private var tutorialPage = 0
    private var confirmResetUntil = 0L
    private var lastObstructed = false
    private var lastOrientLog = 0L
    // A tela virtual: uma pose compartilhada no MUNDO (não presa ao cubo nem à cabeça)
    private val ws = PanelGroup()
    private var lastDist = settings.panelDistance
    private var draggingWs = false
    // navegador
    private var browserInput = ""
    private var editing = false
    private var kbdVisible = false
    private var showHistory = false

    private class Tile(val id: String, val title: String, val sub: String, val available: Boolean, val action: () -> Unit)
    private class Row(val label: String, val value: () -> String, val dec: () -> Unit, val inc: () -> Unit)

    private val tiles = listOf(
        Tile("cinema", "Cinema VR", "Vídeos locais", true) { goTo(Screen.CINEMA) },
        Tile("env", "Ambientes", "3 ambientes 3D", true) { goTo(Screen.ENV) },
        Tile("settings", "Configurações", "Ajustes do sistema", true) { goTo(Screen.SETTINGS) },
        Tile("diag", "Diagnóstico", "Sensores e mãos", true) { goTo(Screen.DIAG) },
        Tile("tutorial", "Tutorial", "Gestos e navegação", true) { goTo(Screen.TUTORIAL) },
        Tile("calib", "Calibração", "Lentes do VR Box", true) { goTo(Screen.CALIB) },
        Tile("browser", "Navegador", "Web (HTTPS)", true) { goTo(Screen.BROWSER) },
        Tile("gallery", "Galeria", "Não implementado", false) {},
        Tile("stereo", "Imagens estéreo", "Não implementado", false) {}
    )

    private inline fun <reified T : Enum<T>> cyc(v: T, d: Int): T {
        val a = enumValues<T>()
        return a[(v.ordinal + d + a.size) % a.size]
    }

    private fun setEnv(n: Int) = selectEnvironment((n + Environments.NAMES.size) % Environments.NAMES.size)

    private val rows: List<Row> = listOf(
        Row("Ambiente", { Environments.NAMES[settings.environment] }, { setEnv(settings.environment - 1) }, { setEnv(settings.environment + 1) }),
        Row("IPD visual (calibração)", { "%.0f mm".format(settings.ipdMm) }, { settings.ipdMm -= 1f }, { settings.ipdMm += 1f }),
        Row("Campo de visão", { "%.0f°".format(settings.fovDeg) }, { settings.fovDeg -= 2f }, { settings.fovDeg += 2f }),
        Row("Distância dos painéis", { "%.2f m".format(settings.panelDistance) }, { settings.panelDistance -= 0.25f }, { settings.panelDistance += 0.25f }),
        Row("Escala dos painéis", { "%.1fx".format(settings.panelScale) }, { settings.panelScale -= 0.1f }, { settings.panelScale += 0.1f }),
        Row("Distorção da lente (k1)", { "%.2f".format(settings.lensK1) }, { settings.lensK1 -= 0.05f }, { settings.lensK1 += 0.05f }),

        Row("Rastreio da cabeça", { if (settings.headTracking) "Ligado" else "Desligado" },
            { settings.headTracking = !settings.headTracking; controller.applyHeadTracking() },
            { settings.headTracking = !settings.headTracking; controller.applyHeadTracking() }),
        Row("Sensibilidade da cabeça", { "%.1fx".format(settings.headSensitivity) }, { settings.headSensitivity -= 0.1f }, { settings.headSensitivity += 0.1f }),
        Row("Suavização da cabeça", { "%.0f ms".format(settings.headSmoothing * 100f) }, { settings.headSmoothing -= 0.1f }, { settings.headSmoothing += 0.1f }),
        Row("Método de entrada", { settings.inputMode.label }, { settings.inputMode = cyc(settings.inputMode, -1) }, { settings.inputMode = cyc(settings.inputMode, 1) }),
        Row("Tempo de seleção (olhar)", { "%.2f s".format(settings.dwellSec) }, { settings.dwellSec -= 0.25f }, { settings.dwellSec += 0.25f }),
        Row("Ponteiro visível", { if (settings.pointer) "Sim" else "Não" }, { settings.pointer = !settings.pointer }, { settings.pointer = !settings.pointer }),

        Row("Hand tracking", { if (settings.handEnabled) "Ligado" else "Desligado" },
            { controller.setHandTracking(!settings.handEnabled) }, { controller.setHandTracking(!settings.handEnabled) }),
        Row("Fonte de câmera", { settings.camera.label },
            { settings.camera = cyc(settings.camera, -1); if (settings.handEnabled) controller.restartHandSource() },
            { settings.camera = cyc(settings.camera, 1); if (settings.handEnabled) controller.restartHandSource() }),
        Row("Sensibilidade dos gestos", { "%.1fx".format(settings.gestureSens) }, { settings.gestureSens -= 0.1f }, { settings.gestureSens += 0.1f }),
        Row("Punho segurado (1 s)", { settings.fistCommand.label }, { settings.fistCommand = cyc(settings.fistCommand, -1) }, { settings.fistCommand = cyc(settings.fistCommand, 1) }),
        Row("Palma segurada (1,2 s)", { settings.openCommand.label }, { settings.openCommand = cyc(settings.openCommand, -1) }, { settings.openCommand = cyc(settings.openCommand, 1) }),
        Row("Taxa máx. do rastreio", { "${settings.handFpsCap} fps" }, { settings.handFpsCap -= 5 }, { settings.handFpsCap += 5 }),

        Row("Espelhar mãos", { if (settings.mirrorHands) "Sim" else "Não" }, { settings.mirrorHands = !settings.mirrorHands }, { settings.mirrorHands = !settings.mirrorHands }),
        Row("Qualidade gráfica", { settings.quality.label }, { settings.quality = cyc(settings.quality, -1) }, { settings.quality = cyc(settings.quality, 1) }),
        Row("Vinheta de conforto", { if (settings.vignette) "Ligada" else "Desligada" }, { settings.vignette = !settings.vignette }, { settings.vignette = !settings.vignette }),
        Row("Sons de clique", { if (settings.soundOn) "Ligados" else "Desligados" }, { settings.soundOn = !settings.soundOn }, { settings.soundOn = !settings.soundOn }),

        Row("Alinhamento horizontal", { "%+.0f%%".format(settings.alignX * 100f) }, { settings.alignX -= 0.01f }, { settings.alignX += 0.01f }),
        Row("Escala da imagem (VR)", { "%.0f%%".format(settings.viewScale * 100f) }, { settings.viewScale -= 0.05f }, { settings.viewScale += 0.05f }),
        Row("Orientação", { settings.orientation.label },
            { settings.orientation = cyc(settings.orientation, -1); controller.applyOrientation() },
            { settings.orientation = cyc(settings.orientation, 1); controller.applyOrientation() }),
        Row("Modo de rastreio", { if (settings.handEnabled) "Câmera (mãos 2D)" else "Sensores (giroscópio)" },
            { controller.setHandTracking(!settings.handEnabled) }, { controller.setHandTracking(!settings.handEnabled) }),
        Row("Formato do vídeo", { cinema.format.label }, { cinema.format = cinema.format.prev() }, { cinema.format = cinema.format.next() }),
        Row("Modo VR", { if (controller.isVrMode()) "Ligado" else "Desligado" },
            { controller.setVrMode(!controller.isVrMode()) }, { controller.setVrMode(!controller.isVrMode()) }),
        Row("Fundo da cena", { if (cameraBackground) "Câmera" else "Ambiente 3D" },
            { toggleCameraBackground() }, { toggleCameraBackground() }),
        Row("GPU nas mãos (experimental)", { if (settings.useGpu) "Ligada" else "Desligada (CPU)" },
            { settings.useGpu = !settings.useGpu; if (settings.handEnabled) controller.restartHandSource() },
            { settings.useGpu = !settings.useGpu; if (settings.handEnabled) controller.restartHandSource() }),
        Row("Rastreamento espacial (ARCore)",
            { when { !settings.spatial -> "Desligado (só rotação)"; Telemetry.arTracking -> "Ligado: rastreando"; else -> "Ligado: ${Telemetry.arStatus}" } },
            { controller.setSpatialTracking(!settings.spatial) }, { controller.setSpatialTracking(!settings.spatial) }),
        Row("Rotação da imagem (espacial)", { "${settings.arRotOffset * 90}° extra" },
            { settings.arRotOffset = (settings.arRotOffset + 3) % 4 }, { settings.arRotOffset = (settings.arRotOffset + 1) % 4 }),
        Row("Tempo de seleção (dedo)", { "%.1f s".format(settings.handDwellSec) }, { settings.handDwellSec -= 0.5f }, { settings.handDwellSec += 0.5f }),
        Row("Zoom da câmera (Minha Casa)", { "%.2fx".format(settings.passthroughZoom) }, { settings.passthroughZoom -= 0.05f }, { settings.passthroughZoom += 0.05f })
    )
    private val rowsPerPage = 6
    private val pageCount get() = (rows.size + rowsPerPage - 1) / rowsPerPage

    init {
        status.drawFn = ::drawStatus
        dock.drawFn = ::drawDock
        controls.drawFn = ::drawControls
        video.drawFn = ::drawVideoPlaceholder
        camView.drawFn = ::drawCamPlaceholder
        camBar.drawFn = ::drawCamBar
        // Painéis do mesmo grupo se movem juntos quando um é agarrado (o menu inteiro, a câmera, o navegador...).
        status.group = 1; main.group = 1; dock.group = 1
        camView.group = 2; camBar.group = 2
        webView.group = 3; webBar.group = 3; kbd.group = 3
        video.group = 4; controls.group = 4
        // Todos os painéis pertencem à MESMA tela: mover um move a tela inteira (menu, câmera, navegador, cinema).
        for (q in all) q.group = 1
        ws.setTarget(floatArrayOf(0f, 0f, -settings.panelDistance), Quat.IDENTITY); ws.snap()
        webView.drawFn = ::drawWebPlaceholder
        webBar.drawFn = ::drawWebBar
        kbd.drawFn = ::drawKbd
        main.drawFn = { c, p ->
            when (screen) {
                Screen.HOME -> drawHome(c, p)
                Screen.SETTINGS -> drawSettings(c, p)
                Screen.DIAG -> drawDiag(c, p)
                Screen.TUTORIAL -> drawTutorial(c, p)
                Screen.ENV -> drawEnv(c, p)
                Screen.CALIB -> drawCalib(c, p)
                Screen.CAMERA, Screen.BROWSER -> {}
                Screen.LOG -> drawLog(c, p)
                Screen.PERF -> drawPerf(c, p)
                Screen.CINEMA -> {}
            }
        }
        screen = Screen.HOME
        applyVisibility()
        notify("VR BOX OS iniciado")
    }

    // ------------------------------------------------------------ API

    fun notify(msg: String) { pending.add(msg) }
    fun environment(): EnvMesh = envCache[settings.environment] ?: Environments.build(settings.environment).also { envCache[settings.environment] = it }
    fun drawOrder(): List<Panel> = all
    fun focusPanel(): Panel = if (screen == Screen.CINEMA) video else main
    fun cameraPanel(): Panel = camView

    /** Botão atual de um painel (os objetos são recriados a cada redesenho; por isso a busca é por id). */
    fun findButton(panelId: String, btnId: String): Button? =
        all.firstOrNull { it.id == panelId }?.buttons?.firstOrNull { it.id == btnId }

    /** Traz o menu (e os demais painéis) de volta à posição padrão, de frente para o usuário. */
    fun resetPlacements() { for (q in all) q.resetPlacement(); placeInFront() }

    /** Escolhe o ambiente. "Minha Casa" liga a câmera (traseira) para o passthrough ao vivo. */
    fun selectEnvironment(i: Int) {
        val prev = settings.environment
        settings.environment = i.coerceIn(0, Environments.NAMES.size - 1)
        notify("Ambiente: ${Environments.NAMES[settings.environment]}")
        if (settings.environment == Environments.HOME_INDEX) startPassthrough()
        else if (prev == Environments.HOME_INDEX && autoStartedCamera) {
            controller.setHandTracking(false)   // só desliga a câmera se foi o próprio "Minha Casa" que a ligou
            autoStartedCamera = false
        }
        main.dirty = true
    }

    private fun startPassthrough() {
        if (settings.camera == CameraKind.FRONT) {
            settings.camera = CameraKind.BACK
            notify("Minha Casa usa a câmera traseira (a frontal olha para você).")
            if (settings.handEnabled) controller.restartHandSource()
        }
        if (!settings.handEnabled) { autoStartedCamera = true; controller.setHandTracking(true) }
    }

    /** Ao abrir o app já em "Minha Casa": liga a câmera uma única vez (pede a permissão se preciso). */
    fun ensurePassthroughCamera() {
        if (homeAutoStarted) return
        homeAutoStarted = true
        startPassthrough()
    }

    fun goHome() = goTo(Screen.HOME)
    fun back(): Boolean {
        if (screen == Screen.HOME) return false
        if (screen == Screen.CINEMA) cinema.pause()
        if (screen == Screen.BROWSER) {
            // Voltar fecha o teclado/histórico, depois volta na página, e só então sai do navegador.
            if (kbdVisible || showHistory) { kbdVisible = false; showHistory = false; editing = false; applyVisibility(); return true }
            if (browser.goBack()) return true
        }
        if (screen == Screen.LOG || screen == Screen.PERF) { goTo(Screen.DIAG); return true }
        goTo(Screen.HOME)
        return true
    }

    private fun goTo(s: Screen) {
        VrLog.i("ui", "tela $screen -> $s (vr=${controller.isVrMode()}, display=${Telemetry.displayRotationDeg}°)")
        if (screen == Screen.BROWSER && s != Screen.BROWSER) browser.setActive(false)
        if (s == Screen.BROWSER) { browser.setActive(true); kbdVisible = false; showHistory = false; editing = false }
        screen = s
        applyVisibility()
        main.alpha = 0.3f   // transição suave (fade-in)
        main.dirty = true
        controls.dirty = true
    }

    private fun applyVisibility() {
        val cin = screen == Screen.CINEMA
        val cam = screen == Screen.CAMERA
        video.visible = cin; controls.visible = cin
        camView.visible = cam; camBar.visible = cam
        val web = screen == Screen.BROWSER
        webView.visible = web; webBar.visible = web; kbd.visible = web && (kbdVisible || showHistory)
        val full = cin || cam || web
        main.visible = !full; dock.visible = !full; status.visible = !full
        for (p in all) p.dirty = true
    }

    fun geometry(p: Panel): PanelGeo {
        return PanelLayout.geo(
            p.ax, p.ay, p.baseW, p.baseH, p.userScale,
            settings.panelDistance, settings.panelScale, p.layoutFactor
        )
    }

    class DragState(val dist: Float, val off: FloatArray)

    /** Pose real (no mundo) de um painel: pose da tela virtual + deslocamento local do painel nela. */
    fun pose(p: Panel): PanelPose {
        val g = geometry(p)                                   // só o layout local (cx, cy) e o tamanho
        val v = ws.q.rotate(floatArrayOf(g.cx, g.cy, 0f))
        return PanelPose(floatArrayOf(ws.p[0] + v[0], ws.p[1] + v[1], ws.p[2] + v[2]), ws.q, g.w, g.h)
    }

    /**
     * Atualiza o destaque do botão sob o ponteiro.
     * Marca os painéis antigo e novo como dirty para que a cor de hover seja redesenhada.
     */
    fun setHover(hit: Hit?) {
        val nextPanel = hit?.panel
        val nextButton = hit?.button?.id
        if (hoverPanel === nextPanel && hoverButton == nextButton) return

        hoverPanel?.dirty = true
        nextPanel?.dirty = true
        hoverPanel = nextPanel
        hoverButton = nextButton
    }

    /** Raio dos olhos ([origin], [dir]) contra os painéis visíveis. Preenche outWorld com o ponto atingido. */
    fun hitTest(origin: FloatArray, dir: FloatArray, outWorld: FloatArray): Hit? {
        for (p in hitOrder) {
            if (!p.visible || p.alpha < 0.3f) continue
            val ps = pose(p)
            val r = PanelPoseMath.intersect(origin, dir, ps.c, ps.q, ps.w, ps.h) ?: continue
            val px = r[0] * p.texW; val py = r[1] * p.texH
            val b = p.buttons.lastOrNull { it.rect.contains(px, py) }
            for (i in 0..2) outWorld[i] = origin[i] + dir[i] * r[2]
            return Hit(p, px, py, r[0], r[1], b)
        }
        val d = settings.panelDistance
        for (i in 0..2) outWorld[i] = origin[i] + dir[i] * d
        return null
    }

    /** Começa a segurar a tela: guarda a distância até o ponto agarrado e o deslocamento do centro. */
    fun beginDrag(p: Panel, origin: FloatArray, dir: FloatArray): DragState {
        val ps = pose(p)
        val r = PanelPoseMath.intersect(origin, dir, ps.c, ps.q, ps.w, ps.h)
        val t = r?.get(2) ?: PanelPoseMath.distance(origin, ws.p)
        val off = floatArrayOf(ws.p[0] - (origin[0] + dir[0] * t), ws.p[1] - (origin[1] + dir[1] * t), ws.p[2] - (origin[2] + dir[2] * t))
        draggingWs = true
        releaseAnchor()                                       // enquanto segura, a mão é quem manda
        return DragState(t.coerceIn(0.5f, 6f), off)
    }

    /**
     * Move a tela livremente no espaço: ela segue o ponto apontado, à distância em que foi agarrada, e fica
     * voltada para o usuário. Sem limite de cubo/face: frente, trás, laterais, chão, altura e teto.
     */
    fun dragTo(p: Panel, origin: FloatArray, dir: FloatArray, st: DragState) {
        val tp = floatArrayOf(origin[0] + dir[0] * st.dist + st.off[0], origin[1] + dir[1] * st.dist + st.off[1], origin[2] + dir[2] * st.dist + st.off[2])
        val up = head.worldOrientation().rotate(floatArrayOf(0f, 1f, 0f))
        ws.setTarget(tp, PanelPoseMath.faceTowards(tp, origin, up))
        ws.placed = true
    }

    /** Soltou: a tela PERMANECE nesse ponto do mundo (e ganha uma âncora espacial, se houver rastreamento). */
    fun endDrag(p: Panel) {
        draggingWs = false
        ws.placed = true
        createAnchor()
    }

    /** Traz a tela de volta para a frente do usuário (na direção em que ele olha agora), à distância padrão. */
    fun placeInFront() {
        val eye = head.position
        val f = head.worldOrientation().rotate(floatArrayOf(0f, 0f, -1f))
        var hx = f[0]; var hz = f[2]
        val n = Math.sqrt((hx * hx + hz * hz).toDouble()).toFloat()
        if (n < 1e-3f) { hx = 0f; hz = -1f } else { hx /= n; hz /= n }
        val d = settings.panelDistance
        val pos = floatArrayOf(eye[0] + hx * d, eye[1], eye[2] + hz * d)
        releaseAnchor()
        ws.setTarget(pos, PanelPoseMath.faceTowards(pos, eye, floatArrayOf(0f, 1f, 0f)))
        ws.placed = true
        createAnchor()
    }

    // Âncoras espaciais (ARCore): preenchidas quando o rastreamento espacial está ativo.
    private fun releaseAnchor() {
        (ws.anchor as? ArTracker.AnchorHandle)?.let { ar.detach(it) }
        ws.anchor = null
    }

    /** Âncora espacial no ponto onde a tela foi deixada: o ARCore a mantém no lugar físico (e a corrige). */
    private fun createAnchor() {
        if (settings.spatial && Telemetry.arTracking) ws.anchor = ar.createAnchor(ws.tp.copyOf(), ws.tq)
    }

    fun onSwipe(dir: Int) {
        when (screen) {
            Screen.SETTINGS -> { settingsPage = (settingsPage - dir + pageCount) % pageCount; main.dirty = true }
            Screen.TUTORIAL -> { tutorialPage = (tutorialPage - dir + 3) % 3; main.dirty = true }
            Screen.ENV -> setEnv(settings.environment - dir)
            else -> {}
        }
    }

    // ------------------------------------------------------- ciclo

    fun onGlCreated() { for (p in all) { p.tex = 0; p.dirty = true } }

    fun update(now: Long) {
        head.enabled = settings.headTracking
        head.sensitivity = settings.headSensitivity
        head.smoothingTauMs = settings.headSmoothing * 100f

        while (true) {
            val m = pending.poll() ?: break
            notes.addFirst(timeFmt.format(Date()) to m)
            while (notes.size > 4) notes.removeLast()
            if (screen == Screen.HOME) main.dirty = true
        }
        val dt = if (lastUpdate == 0L) 16L else now - lastUpdate
        lastUpdate = now
        val k = 1f - exp(-dt / 80f)
        val k2 = 1f - exp(-dt / 70f)   // o painel segue a mão com ~70 ms de suavização (sem tremor, sem atraso perceptível)
        for (p in all) {
            val target = if (p.visible) 1f else 0f
            p.alpha += (target - p.alpha) * k
            p.ax += (p.tax - p.ax) * k2
            p.ay += (p.tay - p.ay) * k2
        }
        // A tela virtual: padrão (à frente) até o usuário movê-la; depois fica onde foi deixada.
        if (!ws.placed) ws.setTarget(floatArrayOf(0f, 0f, -settings.panelDistance), Quat.IDENTITY)
        if (settings.panelDistance != lastDist) { lastDist = settings.panelDistance; if (ws.placed) placeInFront() }
        val ah = ws.anchor as? ArTracker.AnchorHandle
        if (ah != null && !draggingWs) ar.anchorPoseR(ah)?.let { (ap, aq) -> ws.setTarget(ap, aq) }   // correção de deriva
        ws.step(k2)
        if (Telemetry.cameraObstructed != lastObstructed) {
            lastObstructed = Telemetry.cameraObstructed
            if (lastObstructed) notify("Imagem da câmera muito escura: pode estar bloqueada pelo headset. Em Diagnóstico, use \"Voltar aos sensores\".")
        }
        if (now - lastSecond >= 1000) { lastSecond = now; pollDevice(); status.dirty = true }
        if (now - lastFast >= 250) {
            lastFast = now
            if (screen == Screen.DIAG || screen == Screen.TUTORIAL) main.dirty = true
            if (screen == Screen.CINEMA) { controls.dirty = true; video.dirty = true }
            if (screen == Screen.CAMERA) { camBar.dirty = true; camView.dirty = true }
            if (screen == Screen.BROWSER) { webBar.dirty = true; webView.dirty = true }
            if (screen == Screen.LOG || screen == Screen.PERF) main.dirty = true
            status.dirty = true
            // Leitura física da orientação (independe de recentralizar): ajuda a achar "de cabeça para baixo".
            val q = head.raw
            val f = q.rotate(floatArrayOf(0f, 0f, -1f))
            val u = q.rotate(floatArrayOf(0f, 1f, 0f))
            val r = q.rotate(floatArrayOf(1f, 0f, 0f))
            Telemetry.headPitchDeg = Math.toDegrees(asin(f[1].toDouble().coerceIn(-1.0, 1.0))).toFloat()
            Telemetry.headRollDeg = Math.toDegrees(atan2(r[1].toDouble(), u[1].toDouble())).toFloat()
            // Rastro para descobrir QUEM altera a orientação: display, sinal do remapeamento, inclinação e giro.
            if (now - lastOrientLog > 2000) {
                lastOrientLog = now
                VrLog.i("orient", "display=${Telemetry.displayRotationDeg}° sinal=${head.remapSign} pitch=${"%.0f".format(Telemetry.headPitchDeg)}° roll=${"%.0f".format(Telemetry.headRollDeg)}° vr=${controller.isVrMode()} tela=$screen")
                if (abs(Telemetry.headRollDeg) > 135f) VrLog.w("orient", "roll ~180°: a visão está INVERTIDA segundo o sensor")
            }
        }
        // A prévia (custo extra) só é gerada enquanto alguém a mostra.
        pipeline.tracker.wantPreview = screen == Screen.CAMERA || cameraBackground
        pipeline.tracker.wantThumbnail = screen == Screen.DIAG
        Telemetry.passthrough = cameraBackground
        if (manualBg && Telemetry.cameraState != CameraState.ACTIVE) {
            manualBg = false   // sem imagens válidas, volta ao ambiente 3D
            notify("Câmera sem imagem: voltando ao ambiente 3D")
        }
        if (confirmResetUntil != 0L && now > confirmResetUntil) { confirmResetUntil = 0L; main.dirty = true }
    }

    fun refreshTextures() {
        for (p in all) {
            if (p.tex == 0) { p.tex = GlUtil.newTexture(); p.dirty = true }
            if (p.dirty && (p.visible || p.alpha > 0.01f)) {
                p.buttons.clear()
                p.canvas.drawColor(0, PorterDuff.Mode.CLEAR)
                p.drawFn(p.canvas, p)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, p.tex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, p.bitmap, 0)
                p.dirty = false
            }
        }
    }

    private fun pollDevice() {
        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                Telemetry.batteryPct = if (level >= 0) level * 100 / scale else -1
                Telemetry.batteryTempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                Telemetry.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            Telemetry.net = when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Móvel"
                else -> "Rede"
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                Telemetry.thermal = pm.currentThermalStatus
                val hot = Telemetry.thermal >= PowerManager.THERMAL_STATUS_SEVERE
                if (hot && !Telemetry.thermalThrottle) notify("Aparelho quente: rastreio de mãos reduzido a 10 fps")
                Telemetry.thermalThrottle = hot
            }
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------ widgets

    private fun btn(
        p: Panel, c: Canvas, id: String, r: RectF, label: String, enabled: Boolean = true,
        accent: Boolean = false, size: Float = 28f, onScrub: ((Float) -> Unit)? = null, onClick: () -> Unit
    ) {
        p.buttons.add(Button(id, RectF(r), enabled, onScrub, onClick))
        val hover = enabled && hoverPanel === p && hoverButton == id
        Gfx.rrect(c, r, 16f, if (hover) Gfx.BTN_HOVER else Gfx.BTN,
            if (hover || accent) Gfx.ACCENT else 0x33FFFFFF, if (hover) 4f else 2f)
        Gfx.text(c, label, r.centerX(), r.centerY() + size * 0.35f, size,
            if (enabled) Gfx.TEXT else Gfx.DISABLED, Paint.Align.CENTER)
    }

    private fun title(c: Canvas, s: String) { Gfx.text(c, s, 64f, 58f, 44f, Gfx.ACCENT, bold = true) }

    // -------------------------------------------------------- telas

    private fun handCount(): Int {
        val snap = pipeline.tracker.snapshot.get() ?: return 0
        return if (SystemClock.elapsedRealtime() - snap.timestampMs < 400) snap.hands.size else 0
    }

    /** Resumo honesto: "detectada" só com câmera ativa E mão realmente vista. */
    private fun handSummary(): String = when (Telemetry.cameraState) {
        CameraState.OFF -> "Mãos: desligado"
        CameraState.WAITING_PERMISSION -> "Mãos: aguardando permissão"
        CameraState.INITIALIZING -> "Mãos: iniciando"
        CameraState.UNAVAILABLE -> "Mãos: indisponível"
        CameraState.ACTIVE ->
            if (Telemetry.handsError != null) "Mãos: indisponível (${Telemetry.handsError})"
            else handCount().let { if (it > 0) "Mãos: $it detectada(s)" else "Mãos: nenhuma detectada" }
    }

    private fun drawStatus(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val bat = if (Telemetry.batteryPct >= 0) "${Telemetry.batteryPct}%${if (Telemetry.charging) "+" else ""}" else "--"
        Gfx.text(c, timeFmt.format(Date()), 40f, 58f, 34f, Gfx.TEXT, bold = true)
        Gfx.text(c, "Bat $bat  ${Telemetry.net}", 170f, 54f, 21f, Gfx.DIM)
        val headTxt = if (head.enabled) (if (Telemetry.headRateHz > 0f) "Cabeça OK" else "Cabeça: sem dados") else "Cabeça off"
        val cam = "Câm: ${Telemetry.cameraState.label}${if (Telemetry.cameraObstructed) " (escura)" else ""}"
        val col = when (Telemetry.cameraState) {
            CameraState.UNAVAILABLE -> Gfx.BAD
            CameraState.ACTIVE -> if (Telemetry.cameraObstructed) Gfx.WARN else Gfx.OK
            else -> Gfx.ACCENT
        }
        val arTxt = if (settings.spatial) " | AR: ${if (Telemetry.arTracking) "6DoF" else "…"}" else ""
        Gfx.text(c, "$cam | ${handSummary()}$arTxt | Entrada: ${Telemetry.inputMethod} | $headTxt", 1060f, 54f, 21f, col, Paint.Align.RIGHT)
    }

    private fun drawDock(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val labels = listOf(
            "inicio" to "Início", "cinema" to "Cinema", "camera" to "Câmera", "web" to "Web", "config" to "Config.", "calib" to "Calibrar", "diag" to "Diag.",
            "recenter" to "Recentrar", "mode" to (if (controller.isVrMode()) "Sair do VR" else "Entrar VR"),
            "hand" to (if (settings.handEnabled) "Mãos: ON" else "Mãos: OFF")
        )
        val w = 100f; val gap = 5f
        var x = (p.texW - (labels.size * w + (labels.size - 1) * gap)) / 2f
        for ((id, label) in labels) {
            val r = RectF(x, 28f, x + w, 122f)
            btn(p, c, id, r, label, accent = (id == "inicio" && screen == Screen.HOME) || id == "mode", size = 17f) {
                when (id) {
                    "inicio" -> goHome()
                    "cinema" -> goTo(Screen.CINEMA)
                    "camera" -> goTo(Screen.CAMERA)
                    "web" -> goTo(Screen.BROWSER)
                    "config" -> goTo(Screen.SETTINGS)
                    "calib" -> goTo(Screen.CALIB)
                    "diag" -> goTo(Screen.DIAG)
                    "recenter" -> { controller.recenter(); resetPlacements(); notify("Visão e menu centralizados") }
                    "mode" -> controller.setVrMode(!controller.isVrMode())
                    "hand" -> controller.setHandTracking(!settings.handEnabled)
                }
                dock.dirty = true
            }
            x += w + gap
        }
    }

    private fun drawHome(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        Gfx.text(c, "VR BOX OS", 64f, 90f, 56f, Gfx.ACCENT, bold = true)
        Gfx.text(c, dateFmt.format(Date()), 1216f, 88f, 28f, Gfx.DIM, Paint.Align.RIGHT)
        for ((i, t) in tiles.withIndex()) {
            val col = i % 5; val row = i / 5
            val x = 64f + col * (210f + 18f); val y = 130f + row * (190f + 24f)
            val r = RectF(x, y, x + 210f, y + 190f)
            btn(p, c, "tile_${t.id}", r, "", enabled = t.available, onClick = t.action)
            val cc = if (t.available) Gfx.ACCENT else 0x55FFFFFF
            Gfx.circle(c, r.centerX(), y + 62f, 34f, (cc and 0x00FFFFFF) or 0x33000000)
            Gfx.text(c, t.title.take(1), r.centerX(), y + 76f, 40f, cc, Paint.Align.CENTER, bold = true)
            val col2 = if (t.available) Gfx.TEXT else Gfx.DISABLED
            Gfx.text(c, t.title, r.centerX(), y + 135f, 24f, col2, Paint.Align.CENTER)
            Gfx.text(c, t.sub, r.centerX(), y + 168f, 19f, if (t.available) Gfx.DIM else Gfx.WARN, Paint.Align.CENTER)
        }
        Gfx.text(c, "Notificações", 64f, 590f, 26f, Gfx.DIM, bold = true)
        var y = 626f
        for (n in notes) { Gfx.text(c, "${n.first}  ${n.second}", 64f, y, 24f, Gfx.TEXT); y += 30f }
    }

    private fun drawSettings(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Configurações")
        val start = settingsPage * rowsPerPage
        for (i in 0 until rowsPerPage) {
            val idx = start + i
            if (idx >= rows.size) break
            val row = rows[idx]
            val y = 100f + i * 78f
            Gfx.text(c, row.label, 64f, y + 46f, 30f)
            Gfx.rrect(c, RectF(660f, y + 6f, 960f, y + 66f), 14f, 0x33000000)
            Gfx.text(c, row.value(), 810f, y + 46f, 30f, Gfx.ACCENT, Paint.Align.CENTER)
            btn(p, c, "dec$idx", RectF(990f, y + 6f, 1070f, y + 66f), "−", size = 36f) { row.dec(); p.dirty = true }
            btn(p, c, "inc$idx", RectF(1090f, y + 6f, 1170f, y + 66f), "+", size = 36f) { row.inc(); p.dirty = true }
        }
        btn(p, c, "prev", RectF(64f, 596f, 150f, 676f), "<", size = 36f) { settingsPage = (settingsPage - 1 + pageCount) % pageCount; p.dirty = true }
        Gfx.text(c, "${settingsPage + 1}/$pageCount", 205f, 648f, 28f, Gfx.DIM, Paint.Align.CENTER)
        btn(p, c, "next", RectF(260f, 596f, 346f, 676f), ">", size = 36f) { settingsPage = (settingsPage + 1) % pageCount; p.dirty = true }
        btn(p, c, "recenter", RectF(380f, 596f, 640f, 676f), "Recentrar vista", size = 24f) { controller.recenter(); notify("Visão recentralizada") }
        btn(p, c, "resetpos", RectF(660f, 596f, 930f, 676f), "Restaurar painéis", size = 24f) {
            for (q in all) q.resetPlacement(); notify("Painéis restaurados")
        }
        val confirming = confirmResetUntil != 0L
        btn(p, c, "resetall", RectF(950f, 596f, 1216f, 676f), if (confirming) "Confirmar?" else "Padrões…", accent = confirming, size = 24f) {
            if (confirmResetUntil != 0L) {
                confirmResetUntil = 0L
                val hand = settings.handEnabled
                settings.resetDefaults()
                if (hand) controller.setHandTracking(false)
                notify("Configurações restauradas")
            } else confirmResetUntil = SystemClock.elapsedRealtime() + 3000
            p.dirty = true
        }
    }

    private fun drawEnv(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Ambientes")
        for (i in Environments.NAMES.indices) {
            val x = 64f + i * (270f + 24f)
            val r = RectF(x, 130f, x + 270f, 520f)
            btn(p, c, "env$i", r, "") { selectEnvironment(i); p.dirty = true }
            val cur = settings.environment == i
            Gfx.text(c, Environments.NAMES[i], r.centerX(), 220f, 25f, if (cur) Gfx.ACCENT else Gfx.TEXT, Paint.Align.CENTER, bold = true)
            Gfx.paragraph(c, Environments.DESCRIPTIONS[i], x + 24f, 290f, 225f, 24f, Gfx.DIM)
            if (cur) Gfx.text(c, "● Ativo", r.centerX(), 490f, 26f, Gfx.OK, Paint.Align.CENTER)
        }
        Gfx.text(c, "A escolha é salva e mantida entre sessões.", 64f, 600f, 26f, Gfx.DIM)
    }

    private fun drawTutorial(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Tutorial (${tutorialPage + 1}/3)")
        when (tutorialPage) {
            0 -> Gfx.paragraph(c,
                "Olhar: mire num botão e mantenha o olhar até o anel fechar.\n" +
                "Mãos: aponte com o indicador e faça a pinça (polegar + indicador) para clicar.\n" +
                "Segure a pinça na faixa superior de um painel para movê-lo. Com duas mãos em pinça, afaste ou aproxime para redimensionar.\n" +
                "Recentrar: botão na barra inferior, ou segure o punho por 1 s (Menu).\n" +
                "Hand tracking exige uma câmera que enxergue suas mãos (veja o README).", 64f, 120f, 1150f, 32f)
            1 -> Gfx.paragraph(c,
                "1 Mão aberta: mostra a mão virtual.   2 Punho: comando configurável.\n" +
                "3 Indicador: aponta o cursor.   4 Pinça: seleciona/clica.\n" +
                "5 Abrir após pinça: solta.   6 Punho sobre painel: agarra e solta.\n" +
                "7 Deslizar a mão aberta: troca de página.   8 Duas mãos: redimensionar.\n" +
                "9 Punho 1 s: Menu (configurável).   10 Palma 1,2 s: Voltar (configurável).\n" +
                "Gestos que causem falsos positivos podem ser desativados em Configurações.", 64f, 120f, 1150f, 32f)
            else -> {
                val r = router
                val snap = pipeline.tracker.snapshot.get()
                val h = snap?.hands?.firstOrNull()
                Gfx.text(c, "Pratique: faça os gestos e veja a contagem.", 64f, 130f, 32f)
                Gfx.text(c, "Método ativo: ${Telemetry.inputMethod}", 64f, 200f, 30f, Gfx.ACCENT)
                Gfx.text(c, "Gesto atual: ${h?.pose ?: "sem mão"}  (confiança ${"%.2f".format(h?.poseConfidence ?: 0f)})", 64f, 260f, 30f)
                Gfx.text(c, "Pinças: ${r?.pinches ?: 0}    Cliques: ${r?.clicks ?: 0}    Deslizes: ${r?.swipes ?: 0}", 64f, 320f, 30f)
                if (!settings.handEnabled) Gfx.text(c, "Hand tracking desligado: ative em Configurações ou na barra inferior.", 64f, 400f, 26f, Gfx.WARN)
            }
        }
        btn(p, c, "tprev", RectF(64f, 596f, 200f, 676f), "<", size = 36f) { tutorialPage = (tutorialPage + 2) % 3; p.dirty = true }
        btn(p, c, "tnext", RectF(1080f, 596f, 1216f, 676f), ">", size = 36f) { tutorialPage = (tutorialPage + 1) % 3; p.dirty = true }
    }

    private fun drawDiag(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Diagnóstico")
        val box = RectF(40f, 100f, 600f, 460f)
        val snap = pipeline.tracker.snapshot.get()
        val hand = snap?.hands?.firstOrNull()
        val fov = when {
            hand == null -> Gfx.DIM
            (0 until 21).all { hand.lm[it * 3] in 0.03f..0.97f && hand.lm[it * 3 + 1] in 0.03f..0.97f } -> Gfx.OK
            else -> Gfx.WARN
        }
        Gfx.rrect(c, box, 14f, 0x66000000, fov, 5f)
        val bmp = pipeline.tracker.thumbnail
        if (bmp != null && settings.handEnabled) {
            val ar = bmp.width.toFloat() / bmp.height
            val w = min(box.width(), box.height() * ar); val h = w / ar
            val dst = RectF(box.centerX() - w / 2, box.centerY() - h / 2, box.centerX() + w / 2, box.centerY() + h / 2)
            c.drawBitmap(bmp, null, dst, null)
            snap?.hands?.forEach { hs ->
                fun px(i: Int) = dst.left + (if (settings.mirrorHands) 1f - hs.lm[i * 3] else hs.lm[i * 3]) * dst.width()
                fun py(i: Int) = dst.top + hs.lm[i * 3 + 1] * dst.height()
                for (b in HandTopology.BONES) Gfx.line(c, px(b[0]), py(b[0]), px(b[1]), py(b[1]), Gfx.ACCENT, 3f)
                for (i in 0 until 21) Gfx.circle(c, px(i), py(i), 4f, Gfx.TEXT)
            }
        } else {
            Gfx.text(c, "Sem imagem da câmera", box.centerX(), box.centerY(), 28f, Gfx.DIM, Paint.Align.CENTER)
        }
        val fovMsg = when (fov) { Gfx.OK -> "Campo: mão inteira dentro"; Gfx.WARN -> "Campo: mão cortada nas bordas"; else -> "Campo: nenhuma mão" }
        Gfx.text(c, fovMsg, box.left, 490f, 26f, fov)

        val lines = ArrayList<String>()
        lines += "Render ${"%.0f".format(Telemetry.renderFps)} fps   Mãos ${"%.0f".format(Telemetry.handFps)} fps"
        lines += "Latência de inferência: ${"%.0f".format(Telemetry.handLatencyMs)} ms (não é glass-to-glass)"
        lines += "Câmera: ${Telemetry.cameraState.label}${Telemetry.cameraError?.let { " - $it" } ?: ""}  (${Telemetry.framesReceived} quadros)"
        lines += "Rastreio: ${Telemetry.handStatus}"
        lines += "Fonte: ${Telemetry.sourceName}"
        lines += "Disponíveis: ${Telemetry.sourcesText}"
        val n = snap?.hands?.size ?: 0
        lines += if (settings.handEnabled) "Rastreia: mãos (21 pontos 2D). Não rastreia rosto, marcadores nem posição."
                 else "Câmera desligada: cabeça por sensores (giroscópio)."
        if (Telemetry.cameraObstructed) lines += "AVISO: imagem escura - câmera possivelmente bloqueada"
        lines += "Mãos detectadas: $n"
        snap?.hands?.forEachIndexed { i, h ->
            lines += "  [$i] ${h.pose} conf ${"%.2f".format(h.poseConfidence)} pinça ${"%.2f".format(h.pinchRatio)}"
        }
        lines += "Cabeça: ${Telemetry.headStatus} ${"%.0f".format(Telemetry.headRateHz)} Hz"
        lines += "Sensores: ${Telemetry.sensorsText}"
        lines += "Display ${Telemetry.displayRotationDeg}°  inclinação ${"%.0f".format(Telemetry.headPitchDeg)}°  giro ${"%.0f".format(Telemetry.headRollDeg)}° (0=em pé, 180=de cabeça p/ baixo)"
        lines += "Bateria ${Telemetry.batteryPct}%  ${if (Telemetry.batteryTempC.isNaN()) "" else "%.1f°C".format(Telemetry.batteryTempC)}  térmico ${Telemetry.thermal}"
        lines += "${Build.MANUFACTURER} ${Build.MODEL}  Android ${Build.VERSION.RELEASE}"
        var y = 118f
        for (l in lines) { Gfx.text(c, l, 640f, y, 19f); y += 26f }

        btn(p, c, "toggle", RectF(40f, 530f, 400f, 620f), if (settings.handEnabled) "Parar rastreio" else "Iniciar rastreio", size = 28f) {
            controller.setHandTracking(!settings.handEnabled); p.dirty = true
        }
        btn(p, c, "source", RectF(420f, 530f, 840f, 620f), "Fonte: ${settings.camera.label}", size = 26f) {
            settings.camera = cyc(settings.camera, 1)
            if (settings.handEnabled) controller.restartHandSource()
            p.dirty = true
        }
        btn(p, c, "recenter", RectF(860f, 530f, 1216f, 620f), "Recentrar vista", size = 26f) { controller.recenter() }
        btn(p, c, "sensors", RectF(40f, 632f, 290f, 702f), "Sensores", enabled = settings.handEnabled, size = 22f) {
            controller.setHandTracking(false); p.dirty = true
        }
        btn(p, c, "perf", RectF(300f, 632f, 560f, 702f), "Desempenho", size = 22f) { goTo(Screen.PERF) }
        btn(p, c, "log", RectF(570f, 632f, 830f, 702f), "Ver log", size = 22f) { goTo(Screen.LOG) }
        btn(p, c, "sharelog", RectF(840f, 632f, 1216f, 702f), "Compartilhar log", size = 22f) { controller.shareLog() }
    }

    private fun drawCalib(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Calibração das lentes")
        val items = listOf("Alinhamento", "Escala da imagem", "IPD", "Distorção", "Orientação")
            .map { k -> rows.first { it.label.startsWith(k) } }
        for ((i, row) in items.withIndex()) {
            val y = 100f + i * 74f
            Gfx.text(c, row.label, 64f, y + 46f, 30f)
            Gfx.rrect(c, RectF(660f, y + 6f, 960f, y + 66f), 14f, 0x33000000)
            Gfx.text(c, row.value(), 810f, y + 46f, 30f, Gfx.ACCENT, Paint.Align.CENTER)
            btn(p, c, "cdec$i", RectF(990f, y + 6f, 1070f, y + 66f), "−", size = 36f) { row.dec(); p.dirty = true }
            btn(p, c, "cinc$i", RectF(1090f, y + 6f, 1170f, y + 66f), "+", size = 36f) { row.inc(); p.dirty = true }
        }
        Gfx.paragraph(c,
            "No modo VR, cada olho mostra moldura, cruz e círculos. Alinhe a cruz ao centro de cada lente. " +
            "IPD e distorção são ajustes visuais: não substituem o ajuste físico das lentes do headset.",
            64f, 500f, 1150f, 24f, Gfx.DIM)
        btn(p, c, "center", RectF(64f, 596f, 360f, 676f), "Centralizar", size = 26f) {
            settings.alignX = 0f; settings.viewScale = 1f; notify("Imagens centralizadas"); p.dirty = true
        }
        btn(p, c, "defaults", RectF(380f, 596f, 760f, 676f), "Restaurar padrão", size = 26f) {
            settings.alignX = 0f; settings.viewScale = 1f; settings.ipdMm = 63f
            settings.fovDeg = 90f; settings.lensK1 = 0f
            notify("Calibração restaurada"); p.dirty = true
        }
        btn(p, c, "vrtoggle", RectF(780f, 596f, 1216f, 676f),
            if (controller.isVrMode()) "Sair do VR" else "Entrar no modo VR", accent = true, size = 26f) {
            controller.setVrMode(!controller.isVrMode()); p.dirty = true
        }
    }

    /** Liga/desliga a imagem real da câmera como fundo. Só com câmera ATIVA (quadros válidos). */
    fun toggleCameraBackground() {
        if (settings.environment == Environments.HOME_INDEX) {
            notify("Em \"Minha Casa\" a câmera já é o fundo. Escolha outro ambiente para sair.")
            return
        }
        if (manualBg) { manualBg = false; notify("Fundo: ambiente 3D"); return }
        if (Telemetry.cameraState != CameraState.ACTIVE) {
            notify("Ative a câmera primeiro (estado: ${Telemetry.cameraState.label})")
            return
        }
        manualBg = true
        notify("Fundo: câmera (imagem real, presa à cabeça)")
    }

    private fun drawCamPlaceholder(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val msg = when (Telemetry.cameraState) {
            CameraState.OFF -> "Câmera desligada.\nToque em “Ligar câmera”. O Android pedirá a permissão de câmera."
            CameraState.WAITING_PERMISSION -> "Aguardando a permissão de câmera…"
            CameraState.INITIALIZING -> "Inicializando a câmera…\nAguardando as primeiras imagens."
            CameraState.ACTIVE -> "Câmera ativa, aguardando a próxima imagem…"
            CameraState.UNAVAILABLE -> "Câmera indisponível:\n${Telemetry.cameraError ?: "erro desconhecido"}"
        }
        Gfx.paragraph(c, msg, 40f, 200f, 560f, 28f, Gfx.TEXT)
    }

    private fun drawCamBar(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val st = Telemetry.cameraState
        val col = when (st) {
            CameraState.ACTIVE -> if (Telemetry.cameraObstructed) Gfx.WARN else Gfx.OK
            CameraState.UNAVAILABLE -> Gfx.BAD
            else -> Gfx.ACCENT
        }
        Gfx.text(c, "Câmera: ${st.label}${if (Telemetry.cameraObstructed) " (imagem escura: possível bloqueio)" else ""}   ${handSummary()}",
            30f, 46f, 26f, col, bold = true)
        Gfx.text(c, "Fonte: ${settings.camera.label}   Disponíveis: ${Telemetry.sourcesText}   ${"%.0f".format(Telemetry.handFps)} fps",
            30f, 84f, 20f, Gfx.DIM)
        val on = settings.handEnabled
        val items = listOf(
            "cb_home" to "Início",
            "cb_toggle" to (if (on) "Desligar câmera" else "Ligar câmera"),
            "cb_bg" to (if (cameraBackground) "Fundo: Câmera" else "Fundo: Ambiente"),
            "cb_src" to "Fonte: ${settings.camera.label}"
        )
        val w = 280f; val gap = 10f
        var x = (p.texW - (items.size * w + (items.size - 1) * gap)) / 2f
        for ((id, label) in items) {
            btn(p, c, id, RectF(x, 112f, x + w, 184f), label, accent = id == "cb_bg" && cameraBackground, size = 24f) {
                when (id) {
                    "cb_home" -> goHome()
                    "cb_toggle" -> controller.setHandTracking(!settings.handEnabled)
                    "cb_bg" -> toggleCameraBackground()
                    "cb_src" -> {
                        settings.camera = cyc(settings.camera, 1)
                        if (settings.handEnabled) controller.restartHandSource()
                    }
                }
                p.dirty = true
            }
            x += w + gap
        }
    }

    // ------------------------------------------------------ navegador

    /** Toque na página: (u,v) em 0..1 sobre o painel -> pixels do WebView. */
    fun webTouch(action: Int, u: Float, v: Float) {
        browser.touch(action, u * BrowserController.W, v * BrowserController.H)
    }

    private fun fit(s: String, maxW: Float, size: Float, keepEnd: Boolean): String {
        if (Gfx.measure(s, size) <= maxW) return s
        var t = s
        while (t.length > 1 && Gfx.measure(if (keepEnd) "…$t" else "$t…", size) > maxW)
            t = if (keepEnd) t.substring(1) else t.substring(0, t.length - 1)
        return if (keepEnd) "…$t" else "$t…"
    }

    /** No VR o teclado do Android quebraria a divisão da tela: usa-se o teclado virtual. */
    private fun startEditing() {
        if (controller.isVrMode()) {
            browserInput = ""; editing = true; kbdVisible = true; showHistory = false; applyVisibility()
        } else {
            controller.promptText("Endereço ou pesquisa", browser.url) { text -> browser.load(text) }
        }
    }

    private fun submitInput() {
        val t = browserInput
        editing = false; kbdVisible = false; applyVisibility()
        if (t.isNotBlank()) browser.load(t)
    }

    private fun typeKey(s: String) { if (browserInput.length < 300) browserInput += s; webBar.dirty = true }

    private fun drawWebPlaceholder(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val msg = when {
            browser.error != null && !browser.ready -> browser.error!!
            !browser.ready -> "Abrindo o navegador…"
            browser.error != null -> "Não foi possível abrir a página:\n${browser.error}"
            else -> "Aguardando a primeira imagem da página…"
        }
        Gfx.paragraph(c, msg, 80f, 300f, 1120f, 36f, Gfx.TEXT)
    }

    private fun drawWebBar(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val err = browser.error
        val status = when {
            err != null -> "Erro: $err"
            browser.loading -> "Carregando ${browser.progress}%  ${fit(browser.url, 800f, 20f, false)}"
            else -> fit(if (browser.title.isNotBlank()) "${browser.title} - ${browser.url}" else browser.url, 1200f, 20f, false)
        }
        Gfx.text(c, status, 24f, 32f, 20f, if (err != null) Gfx.BAD else if (browser.loading) Gfx.ACCENT else Gfx.DIM)

        val field = RectF(20f, 44f, 880f, 104f)
        btn(p, c, "addr", field, "", accent = editing, size = 26f) { startEditing(); p.dirty = true }
        val shown = if (editing) fit(browserInput + "|", 820f, 26f, true) else fit(browser.url, 820f, 26f, false)
        Gfx.text(c, shown, 36f, 86f, 26f, if (editing) Gfx.TEXT else Gfx.DIM)
        btn(p, c, "go", RectF(890f, 44f, 970f, 104f), "Ir", enabled = editing && browserInput.isNotBlank(), size = 26f) { submitInput(); p.dirty = true }
        btn(p, c, "vkbd", RectF(980f, 44f, 1110f, 104f), "Virtual", accent = kbdVisible, size = 22f) {
            kbdVisible = !kbdVisible; showHistory = false; if (kbdVisible) { editing = true; browserInput = "" }
            applyVisibility(); p.dirty = true
        }
        btn(p, c, "akbd", RectF(1120f, 44f, 1260f, 104f), "Android", enabled = !controller.isVrMode(), size = 22f) {
            controller.promptText("Endereço ou pesquisa", browser.url) { text -> browser.load(text) }
        }

        val vr = controller.isVrMode()
        val items = listOf(
            "wb_home" to "Início", "wb_back" to "Voltar", "wb_fwd" to "Avançar",
            "wb_reload" to (if (browser.loading) "Parar" else "Atualizar"), "wb_start" to "Página inicial",
            "wb_hist" to "Histórico", "wb_up" to "Rolar ▲", "wb_down" to "Rolar ▼",
            "wb_vr" to (if (vr) "Sair do VR" else "Entrar VR")
        )
        val w = 130f; val gap = 8f
        var x = (p.texW - (items.size * w + (items.size - 1) * gap)) / 2f
        for ((id, label) in items) {
            val en = when (id) { "wb_back" -> browser.canGoBack; "wb_fwd" -> browser.canGoForward; else -> true }
            btn(p, c, id, RectF(x, 114f, x + w, 176f), label, enabled = en, accent = id == "wb_vr" && vr, size = 20f) {
                when (id) {
                    "wb_home" -> goHome()
                    "wb_back" -> browser.goBack()
                    "wb_fwd" -> browser.goForward()
                    "wb_reload" -> browser.reload()
                    "wb_start" -> browser.home()
                    "wb_hist" -> { showHistory = !showHistory; kbdVisible = false; editing = false; applyVisibility() }
                    "wb_up" -> browser.scrollBy(-400)
                    "wb_down" -> browser.scrollBy(400)
                    "wb_vr" -> controller.setVrMode(!controller.isVrMode())
                }
                p.dirty = true
            }
            x += w + gap
        }
        if (browser.loading) {
            Gfx.rrect(c, RectF(20f, 184f, 1260f, 192f), 4f, 0x33FFFFFF)
            Gfx.rrect(c, RectF(20f, 184f, 20f + 1240f * browser.progress / 100f, 192f), 4f, Gfx.ACCENT)
        }
    }

    private val kbRows = listOf("1234567890", "qwertyuiop", "asdfghjkl.", "zxcvbnm/:-")

    private fun drawKbd(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        if (showHistory) { drawHistory(c, p); return }
        val kw = 118f; val kh = 70f; val gap = 6f
        for ((r, row) in kbRows.withIndex()) {
            val y = 14f + r * (kh + gap)
            for ((i, ch) in row.withIndex()) {
                val x = 23f + i * (kw + gap)
                btn(p, c, "k_$ch", RectF(x, y, x + kw, y + kh), ch.toString(), size = 32f) { typeKey(ch.toString()) }
            }
        }
        val y = 14f + 4 * (kh + gap)
        val specs = listOf("k_com" to (".com" to 120f), "k_at" to ("@" to 80f), "k_us" to ("_" to 80f), "k_sp" to ("espaço" to 250f),
            "k_del" to ("Apagar" to 150f), "k_clr" to ("Limpar" to 130f), "k_go" to ("Ir" to 130f), "k_close" to ("Fechar" to 150f))
        var x = (p.texW - (specs.sumOf { it.second.second.toDouble() }.toFloat() + (specs.size - 1) * gap)) / 2f
        for ((id, spec) in specs) {
            val (label, width) = spec
            btn(p, c, id, RectF(x, y, x + width, y + kh), label, accent = id == "k_go", size = 26f) {
                when (id) {
                    "k_com" -> typeKey(".com")
                    "k_at" -> typeKey("@")
                    "k_us" -> typeKey("_")
                    "k_sp" -> typeKey(" ")
                    "k_del" -> { if (browserInput.isNotEmpty()) browserInput = browserInput.dropLast(1); webBar.dirty = true }
                    "k_clr" -> { browserInput = ""; webBar.dirty = true }
                    "k_go" -> submitInput()
                    "k_close" -> { kbdVisible = false; editing = false; applyVisibility() }
                }
                p.dirty = true
            }
            x += width + gap
        }
    }

    private fun drawHistory(c: Canvas, p: Panel) {
        Gfx.text(c, "Histórico recente", 24f, 40f, 28f, Gfx.ACCENT, bold = true)
        val list = browser.historyList().take(5)
        if (list.isEmpty()) Gfx.text(c, "Nenhuma página visitada ainda.", 24f, 100f, 26f, Gfx.DIM)
        for ((i, u) in list.withIndex()) {
            val y = 56f + i * 62f
            btn(p, c, "h$i", RectF(20f, y, 1260f, y + 56f), "", size = 24f) { showHistory = false; applyVisibility(); browser.load(u) }
            Gfx.text(c, fit(u, 1200f, 24f, false), 36f, y + 37f, 24f, Gfx.TEXT)
        }
        btn(p, c, "hclose", RectF(1080f, 372f, 1260f, 420f), "Fechar", size = 22f) { showHistory = false; applyVisibility() }
    }

    // ------------------------------------------------------ desempenho

    /** Fluidez da IMAGEM e latência do RECONHECIMENTO medidas separadamente, mais o estado do rastreamento espacial. */
    private fun drawPerf(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Desempenho e rastreamento espacial")
        val cam = Telemetry.cameraFps; val disp = Telemetry.displayFps; val hand = Telemetry.handFps
        val lines = ArrayList<Pair<String, Int>>()
        fun add(s: String, col: Int = Gfx.TEXT) { lines += s to col }
        add("IMAGEM DA CÂMERA (fluidez do vídeo)", Gfx.ACCENT)
        add("  câmera entrega ${"%.0f".format(cam)} quadros/s | desenhados na tela ${"%.0f".format(disp)}/s")
        val sensor = if (Telemetry.captureToAnalyzerMs > 0f) "${"%.0f".format(Telemetry.captureToAnalyzerMs)} ms" else "n/d"
        add("  atraso app→GPU ${"%.0f".format(Telemetry.displayLagMs)} ms | sensor→app (estimado) $sensor")
        add("RECONHECIMENTO DE MÃOS (latência)", Gfx.ACCENT)
        add("  ${"%.0f".format(hand)} resultados/s | inferência ${"%.0f".format(Telemetry.handLatencyMs)} ms | quadro→resultado ${"%.0f".format(Telemetry.handE2eMs)} ms")
        add("  quadros descartados por reconhecimento ocupado: ${Telemetry.recoDropped} | delegate: ${Telemetry.handDelegate}")
        val diag = when {
            !settings.handEnabled -> "Reconhecimento desligado: só a imagem está sendo medida."
            disp >= 0.8f * cam && cam > 0f && hand < 0.8f * disp -> "Imagem fluida; o reconhecimento é mais lento (esperado): as causas são separadas."
            cam > 0f && disp < 0.7f * cam -> "A GPU/renderização está atrasando a imagem (não é a câmera nem o MediaPipe)."
            cam in 0.1f..20f -> "A própria câmera entrega poucos quadros (pouca luz? modo de baixa taxa?)."
            else -> "Imagem e reconhecimento dentro do esperado."
        }
        add("  Diagnóstico: $diag", Gfx.WARN)
        add("RASTREAMENTO ESPACIAL (ARCore)", Gfx.ACCENT)
        add("  ${if (settings.spatial) "Ligado" else "Desligado (só rotação, 3DoF)"} | estado: ${Telemetry.arStatus}")
        add("  posição (m): x ${"%.2f".format(Telemetry.arX)}  y ${"%.2f".format(Telemetry.arY)}  z ${"%.2f".format(Telemetry.arZ)}")
        add("  superfícies: ${Telemetry.arPlanes} | pontos de referência: ${Telemetry.arPoints} | âncoras: ${Telemetry.arAnchors}")
        add("  rotação da imagem de CPU: ${Telemetry.arImageRotation}° (ajuste em Configurações se o reconhecimento a vê girada)")
        var y = 100f
        for ((s, col) in lines) { Gfx.text(c, fit(s, 1180f, 21f, false), 50f, y, 21f, col); y += 30f }
        btn(p, c, "perfback", RectF(64f, 626f, 400f, 696f), "Voltar", size = 24f) { goTo(Screen.DIAG) }
    }

    // ------------------------------------------------------ log

    private fun drawLog(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Log do app")
        var y = 100f
        for (l in VrLog.last(19)) { Gfx.text(c, fit(l, 1180f, 17f, false), 50f, y, 17f, Gfx.TEXT); y += 25f }
        btn(p, c, "logback", RectF(64f, 626f, 400f, 696f), "Voltar", size = 24f) { goTo(Screen.DIAG) }
        btn(p, c, "logshare", RectF(420f, 626f, 820f, 696f), "Compartilhar", size = 24f) { controller.shareLog() }
        btn(p, c, "logclear", RectF(840f, 626f, 1216f, 696f), "Limpar", size = 24f) { VrLog.clear(); p.dirty = true }
    }

    // ------------------------------------------------------ cinema

    private fun mmss(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private fun drawVideoPlaceholder(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val msg = when {
            cinema.error != null -> cinema.error!!
            cinema.hasMedia -> "Carregando vídeo…"
            else -> "Nenhum vídeo selecionado.\nToque em “Vídeo” nos controles (fora do headset) para escolher um arquivo local."
        }
        Gfx.paragraph(c, msg, 120f, 300f, 1040f, 36f, Gfx.TEXT)
    }

    private fun drawControls(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val bar = RectF(30f, 22f, 1170f, 56f)
        p.buttons.add(Button("seek", RectF(bar), cinema.hasMedia, { u -> cinema.seekFraction(u) }) {})
        Gfx.rrect(c, bar, 17f, 0x55FFFFFF)
        val frac = if (cinema.durationMs > 0) cinema.positionMs.toFloat() / cinema.durationMs else 0f
        Gfx.rrect(c, RectF(bar.left, bar.top, bar.left + bar.width() * frac.coerceIn(0f, 1f), bar.bottom), 17f, Gfx.ACCENT)
        Gfx.text(c, "${mmss(cinema.positionMs)} / ${mmss(cinema.durationMs)}", 30f, 98f, 24f, Gfx.TEXT)
        Gfx.text(c, if (cinema.muted) "Mudo" else "Volume ${(cinema.volume * 100).toInt()}%", 1170f, 98f, 24f, Gfx.DIM, Paint.Align.RIGHT)
        Gfx.text(c, "Formato: ${cinema.format.label} (escolhido por você)", 600f, 98f, 22f, Gfx.ACCENT, Paint.Align.CENTER)
        val items = listOf(
            "home" to "Início", "b10" to "-10s", "play" to (if (cinema.isPlaying) "Pausar" else "Tocar"), "f10" to "+10s",
            "mute" to (if (cinema.muted) "Som" else "Mudo"), "vm" to "Vol -", "vp" to "Vol +",
            "sm" to "Tela -", "sp" to "Tela +", "flat" to (if (flatTheater) "Sala" else "Plana"),
            "fmt" to (when (cinema.format) {
                VideoFormat.FLAT -> "2D"
                VideoFormat.SBS -> "SBS"
                VideoFormat.TB -> "TB"
                VideoFormat.EQ360 -> "360°"
                VideoFormat.EQ360_TB -> "360 TB"
            }), "pick" to "Vídeo"
        )
        val w = 90f; val gap = 6f
        var x = (p.texW - (items.size * w + (items.size - 1) * gap)) / 2f
        for ((id, label) in items) {
            val en = cinema.hasMedia || id == "home" || id == "pick" || id == "sm" || id == "sp" || id == "flat" || id == "fmt" || id == "mute"
            btn(p, c, id, RectF(x, 122f, x + w, 186f), label, enabled = en, size = 20f) {
                when (id) {
                    "home" -> back()
                    "b10" -> cinema.seekBy(-10_000)
                    "f10" -> cinema.seekBy(10_000)
                    "play" -> cinema.togglePlay()
                    "vm" -> cinema.changeVolume(-0.1f)
                    "vp" -> cinema.changeVolume(0.1f)
                    "sm" -> video.userScale = (video.userScale - 0.1f).coerceAtLeast(0.5f)
                    "sp" -> video.userScale = (video.userScale + 0.1f).coerceAtMost(2.5f)
                    "flat" -> flatTheater = !flatTheater
                    "fmt" -> cinema.format = cinema.format.next()
                    "mute" -> cinema.toggleMute()
                    "pick" -> controller.pickVideo()
                }
                p.dirty = true
            }
            x += w + gap
        }
    }
}
