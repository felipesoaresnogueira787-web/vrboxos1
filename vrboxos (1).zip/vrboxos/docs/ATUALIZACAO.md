# Atualização: modo VR lado a lado, calibração, orientação, câmera e mídia

> **O ZIP citado no pedido não chegou** (pasta de uploads vazia). Esta atualização foi feita sobre o
> projeto VR BOX OS desta conversa. Nenhum arquivo foi recriado; as telas e funções existentes foram mantidas.

## Arquivos novos
`media/VideoFormat.kt`, `render/SphereMesh.kt`, `app/src/test/.../StereoCalibrationTest.kt`, `docs/ATUALIZACAO.md`.

## Arquivos alterados
`settings/Settings.kt` (alinhamento, escala, orientação) · `render/StereoLayout.kt` (viewport calibrado, FOV) ·
`render/VrRenderer.kt` (calibração no pós-processamento, esfera 360, guias, FOV) · `render/Renderers.kt`
(SphereRenderer) · `media/CinemaPlayer.kt` (formato, mudo, foco de áudio) · `ui/SpatialUi.kt` (tela de calibração,
Entrar/Sair VR, novas linhas de configuração, controles do cinema, avisos) · `input/InputRouter.kt` (FOV do toque) ·
`hands/CameraXSource.kt` (rotação acompanha o display) · `hands/HandTracker.kt` (câmera escura) ·
`hands/HandPipeline.kt`, `Telemetry.kt`, `AppController.kt`, `MainActivity.kt` (permissão, orientação, toque no VR) ·
`README.md`, `docs/STATUS.md`.

## Correções
* Rotação da câmera não acompanhava o display (imagem de cabeça para baixo ao virar o celular): agora o
  `ImageAnalysis.targetRotation` é atualizado por `DisplayListener`. **Não há "inversão da interface inteira".**
* Orientação: agora há modos automático/paisagem/invertida e `requestedOrientation` é reaplicado ao entrar/sair do VR.
* Em telas em pé o campo de visão horizontal era cortado: o FOV vertical é recalculado pela proporção.

## O que foi testado
Somente em Python (replicando as mesmas fórmulas) e por análise estática: viewport calibrado, FOV, UV por olho,
malha da esfera, balanceamento e referências. Testes JVM novos estão escritos e **não foram executados**.
Nada foi compilado nem rodado em celular/headset.

## Depende de celular + headset reais
Alinhamento correto nas lentes, sinal/valor da distorção, orientação em cada sentido, áudio/sincronia,
câmera externa USB, desempenho térmico, qualidade do reconhecimento de mãos.
