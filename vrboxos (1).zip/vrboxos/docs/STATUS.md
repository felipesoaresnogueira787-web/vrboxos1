# Status real do projeto

Legenda: **E** escrito · **C** compilado · **T** testado (automático JVM) · **H** testado em aparelho real.

> Nenhum item está marcado **C** nem **H**: o ambiente onde o código foi escrito não tinha Gradle,
> Android SDK nem rede. A primeira compilação acontecerá no GitHub Actions.

| Requisito | E | C | T | H | Observações |
|---|:-:|:-:|:-:|:-:|---|
| Projeto Gradle/Manifesto/Workflow | ✔ | ✘ | – | ✘ | Gradle 8.7 via `setup-gradle`, AGP 8.5.2, Kotlin 1.9.24 |
| Render estéreo (2 olhos, IPD, FOV, FBO) | ✔ | ✘ | parcial | ✘ | testado só a geometria (viewports, sinal do IPD) |
| Correção de distorção da lente | ✔ | ✘ | ✘ | ✘ | passada de shader com k1 ajustável; **desligada por padrão (k1=0)**; sinal/valor ideal exigem calibração visual |
| Rastreio da cabeça (rotação 3DoF) | ✔ | ✘ | parcial | ✘ | matemática verificada numericamente; mapeamento real do sensor não testado |
| Recentralizar / sensibilidade / suavização | ✔ | ✘ | ✔ | ✘ | |
| Sem sensor / pausa-retomada | ✔ | ✘ | ✘ | ✘ | avisa e segue; sensores reiniciam em `onResume` |
| MediaPipe Hand Landmarker (21 pts, 2 mãos) | ✔ | ✘ | ✘ | ✘ | API usada: `detectForVideo(MPImage, long)` — conferir no primeiro build |
| Classificação de gestos (aberta, punho, apontar, pinça, agarrar, deslizar, 2 mãos, hold) | ✔ | ✘ | ✔ | ✘ | testado com mãos **sintéticas**, não com câmera real |
| Filtro de tremor, histerese, confirmação temporal, trava de clique | ✔ | ✘ | ✔ | ✘ | |
| Perda/recuperação de mão e de câmera | ✔ | ✘ | ✔ (mão) | ✘ | câmera: até 5 tentativas a cada 3 s |
| Mãos virtuais desenhadas dos pontos reais | ✔ | ✘ | ✘ | ✘ | 2D mapeado na cabeça; **z do MediaPipe é impreciso, não é posição 3D absoluta** |
| Abstração de fonte de vídeo | ✔ | ✘ | – | ✘ | `VideoSource`; só `CameraXSource` implementada |
| Câmera externa/USB | parcial | ✘ | ✘ | ✘ | só se o Android a expõe via Camera2 (`LENS_FACING_EXTERNAL`); **UVC genérica NÃO implementada** |
| Tela de calibração do campo de visão | ✔ | ✘ | ✘ | ✘ | no Diagnóstico (borda verde/amarela/cinza) |
| Diagnóstico (imagem, pontos, gestos, confiança, fps, latência) | ✔ | ✘ | ✘ | ✘ | latência = inferência, não "glass-to-glass" |
| Navegação por olhar (permanência) | ✔ | ✘ | ✔ | ✘ | |
| Controle Bluetooth | parcial | ✘ | ✘ | ✘ | só teclas/botões; analógicos não |
| Home, dock, status, notificações internas | ✔ | ✘ | ✘ | ✘ | |
| Config. persistentes | ✔ | ✘ | ✘ | ✘ | teste instrumentado escrito, não rodado |
| 3 ambientes 3D + persistência | ✔ | ✘ | ✘ | ✘ | geometria leve (linhas/caixas/pontos) |
| Cinema: vídeo local, play/pause, volume, ±10 s, barra, tamanho, tela plana | ✔ | ✘ | ✘ | ✘ | Media3 → textura externa |
| Cinema: 3D lado a lado (SBS) e cima/baixo (TB) | ✔ | ✘ | ✔ (UV) | ✘ | formato escolhido pelo usuário; cada olho recorta sua metade |
| Cinema: 360° e 360° cima/baixo (esfera equiretangular) | ✔ | ✘ | ✔ (malha) | ✘ | só rotação; 180° e outras projeções **não** implementadas |
| Calibração: alinhamento, escala, centralizar, restaurar (salvos) | ✔ | ✘ | ✔ (viewport) | ✘ | guias por olho; recorte impede invadir o outro olho |
| Orientação automática/manual; FOV por proporção de tela | ✔ | ✘ | ✔ (FOV) | ✘ | `requestedOrientation` e rotação do ImageAnalysis por display |
| Permissão de câmera negada: explicação, nova tentativa, abrir configurações | ✔ | ✘ | ✘ | ✘ | |
| Detecção de câmera escura/bloqueada + volta aos sensores | ✔ | ✘ | ✘ | ✘ | heurística de brilho; escuro também ocorre em ambiente sem luz |
| Mudo, foco de áudio, pausa ao desconectar fones | ✔ | ✘ | ✘ | ✘ | Media3 |
| Toque como clique no VR | ✔ | ✘ | ✘ | ✘ | 
| Navegador web | ✘ | – | – | – | **não implementado** (tile marcado) |
| Galeria / visualizador 360° / imagens estéreo | ✘ | – | – | – | **não implementado** (tiles marcados) |
| Mover/redimensionar painéis | ✔ | ✘ | ✘ | ✘ | mãos e toque; por olhar só restaurar posições |
| Minimizar/restaurar painéis | ✘ | – | – | – | não implementado |
| Confirmação em ações importantes | ✔ | ✘ | ✘ | ✘ | "Padrões…" exige 2 cliques em 3 s |
| Controle térmico | ✔ | ✘ | ✘ | ✘ | `PowerManager` ≥ SEVERE reduz o rastreio a 10 fps |
| Delegate GPU do MediaPipe | ✘ | – | – | – | só CPU |
| Testes: renderização, mídia, recuperação de interrupção | ✘ | – | – | – | pendentes (exigem aparelho/emulador) |

## Critérios de conclusão (seção 17 do pedido)

1. Compila sem erros — **não verificado**.
2. Estéreo funciona num VR Box — **não verificado**.
3. Cabeça controla a visão — **não verificado**.
4. Menu navegável sem tocar — implementado (olhar/mãos); **não verificado**.
5. Hand tracking processa imagens reais — implementado; **não verificado**.
6. Gestos geram comandos verificáveis — lógica testada com dados sintéticos; **não verificado em câmera real**.
7. Perda de câmera/mãos tratada — implementado; mão testada sinteticamente.
8. Ambientes e cinema — implementados; **não verificados**.
9. Configurações persistidas — implementado; teste não rodado.
10. Actions produz APK — workflow escrito; **não executado**.

**Conclusão: o projeto NÃO pode ser considerado concluído.**
