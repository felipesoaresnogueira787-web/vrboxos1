package com.vrboxos.hands

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.vrboxos.Telemetry
import com.vrboxos.settings.CameraKind
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Câmera via CameraX. FRONT/BACK são as câmeras do celular. EXTERNAL só funciona se o Android
 * expor a câmera USB pela API Camera2 (LENS_FACING_EXTERNAL) — nem todo aparelho faz isso.
 */
class CameraXSource(
    private val activity: ComponentActivity,
    private val kind: CameraKind,
    private val fpsCap: () -> Int
) : VideoSource {
    override val name get() = "CameraX/${kind.label}"
    override val mirrored = kind == CameraKind.FRONT

    private var provider: ProcessCameraProvider? = null
    private var executor: ExecutorService? = null
    @Volatile private var lastTs = 0L
    @Volatile private var stopped = false
    private var displayListener: DisplayManager.DisplayListener? = null

    @Suppress("DEPRECATION")
    private fun currentRotation() = activity.windowManager.defaultDisplay.rotation

    private fun facing(k: CameraKind) = when (k) {
        CameraKind.FRONT -> CameraSelector.LENS_FACING_FRONT
        CameraKind.BACK -> CameraSelector.LENS_FACING_BACK
        CameraKind.EXTERNAL -> CameraSelector.LENS_FACING_EXTERNAL
    }

    override fun start(onFrame: (Bitmap, Long) -> Unit, onError: (String) -> Unit) {
        stopped = false
        val exec = Executors.newSingleThreadExecutor().also { executor = it }
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val selector = CameraSelector.Builder().requireLensFacing(facing(kind)).build()
                if (!p.hasCamera(selector)) {
                    onError("Fonte indisponível neste aparelho: ${kind.label}")
                    return@addListener
                }
                @Suppress("DEPRECATION")
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST) // descarta quadros velhos
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy ->
                    try {
                        if (!stopped) handle(proxy, onFrame)
                    } catch (t: Throwable) {
                        onError("Falha ao processar quadro: ${t.message}")
                    } finally {
                        proxy.close()
                    }
                }
                p.unbindAll()
                val cam = p.bindToLifecycle(activity, selector, analysis)
                // O CameraX só ajusta a rotação da imagem para a rotação do display informada.
                // Sem isto a imagem fica de cabeça para baixo ao virar o celular (paisagem <-> invertida).
                analysis.targetRotation = currentRotation()
                val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                val l = object : DisplayManager.DisplayListener {
                    override fun onDisplayAdded(displayId: Int) {}
                    override fun onDisplayRemoved(displayId: Int) {}
                    override fun onDisplayChanged(displayId: Int) { analysis.targetRotation = currentRotation() }
                }
                dm.registerDisplayListener(l, Handler(Looper.getMainLooper()))
                displayListener = l
                cam.cameraInfo.cameraState.observe(activity) { st ->
                    st.error?.let { onError("Erro da câmera (código ${it.code})") }
                }
            } catch (e: Exception) {
                onError(e.message ?: "erro ao abrir a câmera")
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    private fun handle(proxy: ImageProxy, onFrame: (Bitmap, Long) -> Unit) {
        val now = SystemClock.elapsedRealtime()
        val minInterval = 1000L / fpsCap().coerceAtLeast(1)
        if (now - lastTs < minInterval) return
        lastTs = now
        val src = proxy.toBitmap()
        val m = Matrix()
        m.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
        if (mirrored) m.postScale(-1f, 1f)
        val upright = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (upright !== src) src.recycle()
        onFrame(upright, now)
    }

    override fun stop() {
        stopped = true
        displayListener?.let {
            try { (activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(it) } catch (_: Exception) {}
        }
        displayListener = null
        try { provider?.unbindAll() } catch (_: Exception) {}
        executor?.shutdown()
        executor = null
    }

    companion object {
        /** Descobre quais fontes o aparelho oferece (para a tela de diagnóstico). */
        fun probe(activity: ComponentActivity) {
            val future = ProcessCameraProvider.getInstance(activity)
            future.addListener({
                try {
                    val p = future.get()
                    fun has(k: Int) = try {
                        p.hasCamera(CameraSelector.Builder().requireLensFacing(k).build())
                    } catch (_: Exception) { false }
                    fun s(b: Boolean) = if (b) "sim" else "não"
                    Telemetry.sourcesText = "Frontal ${s(has(CameraSelector.LENS_FACING_FRONT))} / " +
                        "Traseira ${s(has(CameraSelector.LENS_FACING_BACK))} / " +
                        "Externa ${s(has(CameraSelector.LENS_FACING_EXTERNAL))}"
                } catch (e: Exception) {
                    Telemetry.sourcesText = "indisponível"
                }
            }, ContextCompat.getMainExecutor(activity))
        }
    }
}
