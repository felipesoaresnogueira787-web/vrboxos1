package com.vrboxos.hands

import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import com.vrboxos.Telemetry
import com.vrboxos.settings.Settings
import java.util.concurrent.Executors

/** Liga fonte de vídeo -> MediaPipe -> GestureEngine, com recuperação automática de falhas. */
class HandPipeline(
    private val activity: ComponentActivity,
    private val settings: Settings,
    private val notify: (String) -> Unit
) {
    val engine = GestureEngine()
    val tracker = HandTracker(activity.applicationContext, engine)

    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var source: VideoSource? = null
    @Volatile private var wanted = false
    private var retries = 0
    private var generation = 0

    val running get() = wanted

    private fun fpsCap() = if (Telemetry.thermalThrottle) 10 else settings.handFpsCap

    fun start() {
        wanted = true
        retries = 0
        launch()
    }

    private fun launch() {
        if (!wanted) return
        stopSource()
        val gen = ++generation
        Telemetry.handStatus = "Iniciando..."
        bg.execute {
            val ok = tracker.init()                       // carrega o modelo fora da thread principal
            main.post {
                if (gen != generation || !wanted) return@post
                if (!ok) {
                    // Sem modelo não adianta tentar de novo: avisar e seguir só com olhar.
                    wanted = false
                    Telemetry.handStatus = "Erro: ${tracker.error}"
                    notify("Hand tracking indisponível: modelo ausente. Usando olhar.")
                    return@post
                }
                openSource(gen)
            }
        }
    }

    private fun openSource(gen: Int) {
        val src = CameraXSource(activity, settings.camera) { fpsCap() }
        source = src
        Telemetry.sourceName = src.name
        var first = true
        src.start(
            onFrame = { bmp, ts ->
                if (gen == generation) {
                    engine.config.sensitivity = settings.gestureSens
                    tracker.wantThumbnail = true
                    tracker.onFrame(bmp, ts, settings.mirrorHands)
                    if (first) { first = false; retries = 0 }
                }
            },
            onError = { msg -> main.post { if (gen == generation) handleError(msg) } }
        )
    }

    private fun handleError(msg: String) {
        stopSource()
        Telemetry.handStatus = "Falha: $msg"
        notify("Câmera: $msg")
        if (wanted && retries < MAX_RETRIES) {
            retries++
            main.postDelayed({ launch() }, 3000L)
        } else if (wanted) {
            wanted = false
            notify("Câmera perdida. Hand tracking desligado; usando olhar.")
        }
    }

    private fun stopSource() {
        source?.stop()
        source = null
    }

    fun stop() {
        wanted = false
        generation++
        stopSource()
        Telemetry.handStatus = "Desligado"
        Telemetry.handFps = 0f
        Telemetry.cameraObstructed = false
        // esquece pinça/punho/posições: ao retomar, nada fica "preso" a uma pose antiga
        tracker.reset()
    }

    fun release() {
        stop()
        tracker.close()
        bg.shutdown()
    }

    companion object { private const val MAX_RETRIES = 5 }
}
