package com.vrboxos

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.vrboxos.hands.CameraXSource
import com.vrboxos.hands.HandPipeline
import com.vrboxos.head.HeadPose
import com.vrboxos.head.HeadTracker
import com.vrboxos.input.InputRouter
import com.vrboxos.media.CinemaPlayer
import com.vrboxos.render.VrRenderer
import com.vrboxos.settings.OrientationMode
import com.vrboxos.settings.Settings
import com.vrboxos.ui.SpatialUi

class MainActivity : ComponentActivity(), AppController {
    private lateinit var settings: Settings
    private val head = HeadPose()
    private lateinit var headTracker: HeadTracker
    private lateinit var cinema: CinemaPlayer
    private lateinit var pipeline: HandPipeline
    private lateinit var ui: SpatialUi
    private lateinit var router: InputRouter
    private lateinit var renderer: VrRenderer
    private lateinit var glView: GLSurfaceView
    private lateinit var feedback: Feedback
    private var lastBack = 0L

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) enableHand() else onCameraDenied()
    }

    /** Explica por que a câmera é necessária e permite tentar de novo (ou abrir as configurações). */
    private fun onCameraDenied() {
        settings.handEnabled = false
        ui.notify("Permissão de câmera negada: usando sensores e olhar.")
        val permanent = !shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
        AlertDialog.Builder(this)
            .setTitle("Câmera não autorizada")
            .setMessage(
                "A câmera só é usada para detectar suas mãos. Sem ela o app continua com sensores e olhar." +
                    if (permanent) " Para autorizar, abra as configurações do app." else " Você pode tentar de novo."
            )
            .setPositiveButton(if (permanent) "Abrir configurações" else "Tentar de novo") { _, _ ->
                if (permanent) startActivity(
                    Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                ) else permLauncher.launch(Manifest.permission.CAMERA)
            }
            .setNegativeButton("Agora não", null)
            .show()
    }

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            cinema.load(uri)
            ui.notify("Vídeo carregado")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        settings = Settings(this)
        feedback = Feedback(this, settings)
        cinema = CinemaPlayer(applicationContext)
        pipeline = HandPipeline(this, settings) { msg -> if (::ui.isInitialized) ui.notify(msg) }
        ui = SpatialUi(applicationContext, settings, head, this, pipeline, cinema)
        router = InputRouter(ui, settings, feedback, pipeline, this)
        ui.router = router
        headTracker = HeadTracker(this, head) { displayRotation() }
        renderer = VrRenderer(applicationContext, ui, head, settings, cinema, router, pipeline)
        renderer.vrMode = settings.vrMode

        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnTouchListener { _, e ->
                if (!renderer.vrMode) {   // modo plano (configuração fora do headset): toque normal
                    val x = e.x; val y = e.y; val a = e.actionMasked
                    queueEvent { router.touch(x, y, a) }
                } else if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    // No VR, um toque (ex.: botão condutivo do headset) clica onde o olhar aponta.
                    queueEvent { router.onKey(KeyEvent.KEYCODE_BUTTON_A) }
                }
                true
            }
        }
        setContentView(glView)
        hideSystemBars()
        applyOrientation()

        onBackPressedDispatcher.addCallback(this) {
            glView.queueEvent {
                if (!ui.back()) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastBack < 2000) runOnUiThread { finish() }
                    else { lastBack = now; ui.notify("Aperte voltar de novo para sair") }
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        if (!headTracker.start()) ui.notify("Sem sensor de rotação: a visão não acompanha a cabeça.")
        CameraXSource.probe(this)
        if (settings.handEnabled) {
            if (hasCameraPermission()) pipeline.start() else settings.handEnabled = false
        }
    }

    override fun onPause() {
        pipeline.stop()
        headTracker.stop()
        cinema.pause()
        glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        pipeline.release()
        cinema.release()
        feedback.release()
        super.onDestroy()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val handled = when (code) {
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_MENU -> true
            else -> false
        }
        if (handled) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) glView.queueEvent { router.onKey(code) }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun enableHand() {
        settings.handEnabled = true
        pipeline.start()
        ui.notify("Hand tracking iniciado (${settings.camera.label})")
    }

    // ---------------------------------------------------------- AppController

    override fun pickVideo() { runOnUiThread { pickLauncher.launch(arrayOf("video/*")) } }

    override fun setHandTracking(enable: Boolean) = runOnUiThread {
        when {
            !enable -> {
                settings.handEnabled = false
                pipeline.stop()
                ui.notify("Hand tracking desligado")
            }
            hasCameraPermission() -> enableHand()
            else -> AlertDialog.Builder(this)
                .setTitle("Permissão da câmera")
                .setMessage(
                    "O VR BOX OS usa a câmera somente para detectar suas mãos neste aparelho. " +
                        "As imagens são processadas em memória e não são gravadas nem enviadas. " +
                        "Conceda a permissão com o aparelho fora do headset."
                )
                .setPositiveButton("Continuar") { _, _ -> permLauncher.launch(Manifest.permission.CAMERA) }
                .setNegativeButton("Agora não", null)
                .show().let { }
        }
    }

    override fun restartHandSource() { runOnUiThread { if (settings.handEnabled && hasCameraPermission()) pipeline.start() } }

    override fun applyOrientation() {
        runOnUiThread {
            requestedOrientation = when (settings.orientation) {
                OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                OrientationMode.LANDSCAPE_REVERSE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                // Automática: livre fora do VR; paisagem nos dois sentidos dentro do VR.
                OrientationMode.AUTO ->
                    if (renderer.vrMode) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            }
        }
    }

    override fun setVrMode(vr: Boolean) {
        settings.vrMode = vr
        renderer.vrMode = vr
        applyOrientation()
        ui.notify(if (vr) "Modo VR: coloque o aparelho no headset" else "Modo plano (configuração)")
    }

    override fun isVrMode() = renderer.vrMode
    override fun recenter() { head.recenter() }
    override fun exitApp() { runOnUiThread { finish() } }
}
