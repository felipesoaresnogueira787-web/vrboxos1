# VR BOX OS

Sistema de realidade virtual para smartphones Android usados em headsets **VR Box genéricos**:
interface espacial 3D, renderização estereoscópica, rastreamento de cabeça (3DoF), cinema virtual e
**reconhecimento de mãos por visão computacional** (MediaPipe Hand Landmarker).

> **Leia primeiro `docs/STATUS.md`.** Ele separa, sem enfeite, o que foi *escrito*, o que foi *compilado*
> e o que foi *testado em hardware real*. Neste momento: **escrito sim; compilado não; testado em
> aparelho não.** O primeiro build no GitHub Actions é o primeiro teste de compilação de verdade.

## Como gerar o APK sem Android Studio (GitHub Actions)

1. Crie um repositório no GitHub e envie **todo o conteúdo desta pasta** (incluindo `.github/`).
2. Abra a aba **Actions** → workflow **Build APK (debug)** → *Run workflow* (ou faça um `push`).
3. Ao terminar, abra a execução e baixe o artefato **`vrboxos-debug-apk`** (contém `app-debug.apk`).
   Se falhar, baixe os logs, me envie o erro e eu corrijo — espere ajustes no primeiro build.
4. No celular: ative *instalar apps desconhecidos*, copie o APK e instale.

O modelo `hand_landmarker.task` (Apache 2.0) é baixado pelo próprio Gradle (tarefa `downloadHandModel`) e
também por `scripts/baixar_modelos.sh`; ele **não** está no repositório. Sem o modelo o app abre normalmente e o hand tracking informa o erro,
caindo para navegação por olhar. Nenhuma chave ou senha é necessária (APK de depuração usa a chave de debug).

## Primeiro uso

1. Abra o app **fora do headset** (modo *Plano*): aqui o toque na tela funciona.
2. Em **Configurações** ajuste IPD, campo de visão, distância dos painéis etc. (tudo é salvo).
3. Para mãos: ligue *Hand tracking* (a permissão de câmera é explicada e pedida nesse momento).
4. Em **Cinema → Vídeo**, escolha um arquivo local.
5. Na barra inferior, **Modo: Plano → VR**, coloque o aparelho no headset.
   No modo VR o toque é ignorado de propósito; use olhar (permanência), mãos ou controle Bluetooth.

## O problema da câmera (importante)

No VR Box a câmera frontal olha para o seu rosto e a traseira fica bloqueada. **O rastreamento de mãos
só funciona dentro do headset se alguma câmera enxergar suas mãos** (por exemplo, câmera USB OTG presa na
frente do headset, se o seu celular a expuser ao Android). Sem isso o app avisa e usa olhar.
Detalhes e compatibilidade: `docs/CAMERA_E_HAND_TRACKING.md`.

## Modo VR, calibração e orientação (novo)

* **Entrar/Sair do VR:** botão "Entrar VR" / "Sair do VR" na barra inferior e na tela de calibração.
  No VR a tela é dividida **lado a lado** (esquerda = olho esquerdo, direita = olho direito), em tela cheia
  imersiva. Dentro do VR um **toque na tela** (ou botão condutivo do headset) clica onde o olhar aponta.
* **Calibração das lentes** (tile "Calibração" ou botão "Calibrar"): alinhamento horizontal, escala da imagem,
  IPD visual, distorção, orientação, "Centralizar" e "Restaurar padrão". As guias (moldura, cruz, círculos)
  aparecem em cada olho. Tudo é salvo. Padrão: imagem ocupa 100% de cada metade, sem margens.
* **Orientação:** Automática (livre fora do VR; paisagem nos dois sentidos no VR), Paisagem ou Paisagem invertida.
  A rotação da câmera acompanha o display (corrige imagem de cabeça para baixo ao virar o celular).
* **Rastreio:** "Sensores (giroscópio)" ou "Câmera (mãos 2D)". A câmera rastreia **mãos**, não a cabeça nem
  posição. Se a imagem fica escura (câmera bloqueada) o app avisa e há "Voltar aos sensores" no Diagnóstico.
* **Cinema:** mudo, volume, ±10 s, formato escolhido por você (2D, 3D lado a lado, 3D cima/baixo, 360°,
  360° cima/baixo). O app **nunca** adivinha o formato.

## Minha Casa, menu na mão e seleção por dedo (quinta atualização)

* **Minha Casa** (Ambientes ou Configurações > Ambiente): mostra a câmera **traseira** ao vivo como fundo, com o
  menu por cima, nos dois olhos (VR lado a lado). Pede a permissão de câmera se precisar. É vídeo 2D comum:
  **sem profundidade e sem mapeamento 3D**. "Zoom da câmera" em Configurações ajusta a escala da imagem.
  A imagem acompanha o movimento do aparelho por natureza (a câmera está nele); os sensores mantêm o menu parado
  no espaço. Se a câmera traseira estiver tampada pelo headset, a imagem fica escura e o app avisa.
* **Pegar o menu:** faça a pinça (polegar+indicador) sobre o menu e **segure movendo a mão**: o menu (barra de status,
  painel e barra inferior juntos) fica com contorno verde e segue a mão; ao soltar, fica onde está. Uma pinça
  rápida continua sendo um clique. Ele não sai de um cone de 45° (horizontal) e 35° (vertical) em volta da frente.
  **Recentrar** (barra inferior) ou segurar o punho 1 s traz o menu de volta à posição padrão.
* **Apontar e esperar:** aponte com o indicador (os outros dedos dobrados). O ponto aparece onde o dedo aparece na
  tela; sobre um botão um anel enche em **5 s** (ajustável) e o botão é acionado. Sair do botão cancela, apontar
  outro reinicia, pequenos tremores são tolerados e não repete sem sair do botão.

## Navegador (terceira atualização)

* Tile "Navegador" ou botão **Web** na barra inferior. Barra de endereço (texto que não é endereço vira
  pesquisa), apenas HTTPS, voltar/avançar/atualizar, página inicial, progresso, mensagens de erro em
  português, histórico e rolagem.
* **No modo VR** a página aparece nos dois olhos (2D duplicado, sem profundidade). Digite no **teclado virtual**
  (olhar/mãos). O teclado do Android é desligado no VR porque quebraria a divisão da tela.
* **Clique na página:** toque (modo plano), pinça (mãos) ou olhar parado ~1,5 s. Arrastar rola a página.
* Segurança: sem acesso a arquivos, sem conteúdo misto, certificado inválido bloqueia, esquemas
  `javascript:`/`file:`/`intent:` não navegam, páginas não acessam câmera/microfone/localização.
* Limites: campos de texto dentro das páginas só funcionam no modo plano; taxa de quadros baixa (~8 fps).

## Câmera, mãos e sensores (segunda atualização)

* **Estados da câmera** (barra de status, tela "Câmera" e Diagnóstico): Desligada, Aguardando permissão,
  Inicializando, Ativa, Indisponível (com o motivo). "Ativa" só aparece depois de receber quadros reais.
* **Tela "Câmera"** (botão na barra inferior): imagem real com os pontos das mãos, "Ligar/Desligar câmera",
  "Fundo: Ambiente/Câmera" e troca de fonte. O ambiente 3D continua intacto; volte pelo botão Início.
* **Fundo da cena = câmera:** mostra a imagem real atrás dos painéis, presa à cabeça e em mono. Não é
  passthrough espacial. Se a câmera deixar de entregar imagens, volta sozinho ao ambiente 3D.
* **Indicador de mãos:** ponto no campo de visão e texto na barra de status (nenhuma / detectada / indisponível).
* **Sensores:** só ficam registrados com "Rastreio da cabeça" ligado (200 Hz no VR, 60 Hz no modo plano).
  Sem vetor de rotação o app integra o giroscópio (com deriva; use Recentrar). Sem nenhum dos dois, avisa.
* **Se a imagem aparecer de cabeça para baixo:** abra *Diagnóstico* e veja "Display" e "giro". Em
  *Calibração*, o triângulo deve ficar no topo e o quadrado no canto superior esquerdo de cada olho.
  Se não, escolha *Paisagem* ou *Paisagem invertida* em Orientação e me envie os valores lidos.

## Entradas

| Método | Como funciona |
|---|---|
| Mãos | indicador aponta o cursor; pinça clica; segurar pinça na faixa superior move o painel; punho agarra; duas mãos em pinça redimensionam; deslizar a mão aberta troca de página |
| Olhar | mire e espere o anel fechar (tempo configurável) |
| Toque | só no modo Plano |
| Controle Bluetooth | A/Enter = clicar no ponto do olhar, B/Voltar = voltar, Start/Menu = Menu |

O app mostra o método ativo na barra de status e alterna sozinho para o olhar se as mãos somem.

## Estrutura

```
app/src/main/java/com/vrboxos/
  head/      Quat, HeadPose (recentralizar, sensibilidade), HeadTracker (sensor)
  hands/     GestureEngine (puro), OneEuro, HandTracker (MediaPipe), CameraXSource, VideoSource, HandPipeline
  input/     InputRouter (mãos/olhar/toque/teclas), ClickGuard, DwellTracker
  render/    VrRenderer (estéreo, FBO, distorção), Environments (3 ambientes), shaders
  ui/        SpatialUi (telas), Panel, Gfx, PanelGeometry
  media/     CinemaPlayer (Media3 -> textura externa)
  settings/  Settings (SharedPreferences)
app/src/test/        testes unitários (JVM)
app/src/androidTest/ testes instrumentados (precisam de aparelho/emulador)
```

## Testes

* **Automáticos (JVM, rodam no Actions):** `GestureEngineTest`, `CoreLogicTest`
  (`gradle :app:testDebugUnitTest`). Cobrem gestos sintéticos, trava de clique duplo, perda de mão,
  permanência do olhar, geometria dos painéis, viewports/IPD, recentralização.
* **Instrumentados (precisam de aparelho):** `SettingsPersistenceTest`. **Não executados.**
* **Físicos:** procedimento em `docs/AVALIACAO_HAND_TRACKING.md`. **Não executados.**

## Licenças

Modelo `hand_landmarker.task` e MediaPipe: Apache License 2.0 (Google). CameraX e Media3: Apache 2.0.
