package com.vrboxos.ui

/** Painel plano em z = cz (negativo, na frente do usuário), centro (cx,cy), tamanho (w,h) em metros. */
data class PanelGeo(val cx: Float, val cy: Float, val cz: Float, val w: Float, val h: Float)

/** Posição/tamanho reais (em metros) de um painel no ambiente 3D, a partir do layout base e dos ajustes. */
object PanelLayout {
    /** Plano de referência (m) em que as posições base (ax, ay) dos painéis foram desenhadas. */
    const val REFERENCE_DISTANCE = 2f

    /**
     * [distance]: distância real do painel ao usuário (z = -distance).
     * [panelScale] * [layoutFactor]: escala do LAYOUT inteiro (posições e tamanhos juntos, para painéis
     * maiores não se sobreporem). [userScale]: escala individual (duas mãos / botões de tamanho).
     */
    /**
     * Limites do CENTRO de um painel (coordenadas base) para que ele nunca saia de um cone confortável em
     * volta da frente: 45° na horizontal e 35° na vertical. Como tan(ângulo) = ax * layout / 2, o menu não
     * pode ser jogado para fora do alcance nem desaparecer.
     */
    fun maxAx(layout: Float) = 2f * 1.0f / layout
    fun maxAy(layout: Float) = 2f * 0.70f / layout

    fun geo(
        ax: Float, ay: Float, baseW: Float, baseH: Float, userScale: Float,
        distance: Float, panelScale: Float, layoutFactor: Float
    ): PanelGeo {
        val k = distance / REFERENCE_DISTANCE
        val layout = panelScale * layoutFactor
        val sc = layout * userScale
        return PanelGeo(ax * k * layout, ay * k * layout, -REFERENCE_DISTANCE * k, baseW * k * sc, baseH * k * sc)
    }
}

object PanelGeometry {
    /**
     * Raio partindo da origem com direção (dx,dy,dz). Retorna (u,v) em [0,1] (v=0 no topo)
     * se atinge o painel; null caso contrário (fora, ou raio apontando para trás).
     */
    fun intersect(dx: Float, dy: Float, dz: Float, g: PanelGeo): FloatArray? {
        if (dz >= -1e-4f) return null
        val t = g.cz / dz
        val hx = dx * t
        val hy = dy * t
        val u = (hx - g.cx) / g.w + 0.5f
        val v = 0.5f - (hy - g.cy) / g.h
        if (u < 0f || u > 1f || v < 0f || v > 1f) return null
        return floatArrayOf(u, v)
    }
}
