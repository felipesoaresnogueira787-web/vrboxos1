package com.vrboxos.hands

enum class Pose { NONE, OPEN, FIST, POINT, PINCH, OTHER }
enum class HoldGesture { FIST, OPEN }

/** Mão crua do detector: 21 pontos (x,y,z) normalizados, 63 floats. */
class RawHand(val lm: FloatArray, val label: String, val score: Float) {
    fun mirrored(): RawHand {
        val c = lm.copyOf()
        for (k in 0 until 21) c[k * 3] = 1f - c[k * 3]
        return RawHand(c, label, score)
    }
}

data class HandState(
    val slot: Int,
    val label: String,
    val score: Float,
    val lm: FloatArray,
    val pose: Pose,
    val poseConfidence: Float,
    val pinchRatio: Float,
    val pinching: Boolean,
    val cursorX: Float,
    val cursorY: Float,
    val palmX: Float,
    val palmY: Float,
    val fade: Float,
    val ageMs: Long
)

sealed class GestureEvent {
    data class HandFound(val slot: Int, val t: Long) : GestureEvent()
    data class HandLost(val slot: Int, val t: Long) : GestureEvent()
    data class PinchStart(val slot: Int, val x: Float, val y: Float, val t: Long) : GestureEvent()
    data class PinchEnd(val slot: Int, val t: Long, val heldMs: Long) : GestureEvent()
    data class GrabStart(val slot: Int, val x: Float, val y: Float, val t: Long) : GestureEvent()
    data class GrabEnd(val slot: Int, val t: Long) : GestureEvent()
    data class Swipe(val dirX: Int, val t: Long) : GestureEvent()
    data class Hold(val gesture: HoldGesture, val t: Long) : GestureEvent()
}

class HandSnapshot(
    val timestampMs: Long,
    val hands: List<HandState>,
    /** Distância entre as palmas (corrigida pela proporção da imagem); -1 se não há duas mãos. */
    val twoHandDistance: Float,
    val imageAspect: Float,
    val latencyMs: Float
) {
    /** Instante (elapsedRealtime) em que o resultado ficou pronto: base da medida resultado → tela. */
    @Volatile var readyMs: Long = 0L
}

object HandTopology {
    val BONES = arrayOf(
        intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 4),
        intArrayOf(0, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 8),
        intArrayOf(5, 9), intArrayOf(9, 10), intArrayOf(10, 11), intArrayOf(11, 12),
        intArrayOf(9, 13), intArrayOf(13, 14), intArrayOf(14, 15), intArrayOf(15, 16),
        intArrayOf(13, 17), intArrayOf(17, 18), intArrayOf(18, 19), intArrayOf(19, 20),
        intArrayOf(0, 17)
    )
}
