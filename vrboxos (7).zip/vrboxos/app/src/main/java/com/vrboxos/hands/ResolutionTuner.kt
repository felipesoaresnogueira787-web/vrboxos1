package com.vrboxos.hands

/**
 * Escolhe a escala da imagem de entrada do MediaPipe pelo DESEMPENHO MEDIDO no próprio aparelho:
 * desce de nível quando a inferência não acompanha a câmera (ou quadros estão sendo descartados) e só volta a subir
 * se a previsão para o nível maior ainda cabe com folga (evita oscilar). Em aparelhos rápidos fica em 100%.
 * Pura (JVM).
 */
class ResolutionTuner(
    private val levels: FloatArray = floatArrayOf(1f, 0.75f, 0.5f),
    private val settleMs: Long = 2500L,
    private val upProbeMs: Long = 8000L
) {
    var level = 0
        private set
    private var lastChange = -1L           // -1 = janela ainda não iniciada
    val scale: Float get() = levels[level]

    /**
     * [inferMs]: média da inferência no nível atual; [intervalMs]: intervalo entre quadros da câmera;
     * [dropRate]: fração dos quadros enviados que foram descartados por o reconhecimento estar ocupado.
     */
    fun update(now: Long, inferMs: Float, intervalMs: Float, dropRate: Float): Int {
        if (lastChange < 0L) lastChange = now
        val since = now - lastChange
        if (since >= settleMs && level < levels.size - 1 && (inferMs > 0.9f * intervalMs || dropRate > 0.2f)) {
            level++; lastChange = now
        } else if (since >= upProbeMs && level > 0 && dropRate < 0.02f) {
            val ratio = levels[level - 1] / levels[level]
            val predicted = inferMs * ratio * ratio          // custo aproximadamente proporcional à área
            if (predicted < 0.8f * intervalMs) { level--; lastChange = now }
        }
        return level
    }

    fun force(lv: Int) { level = lv.coerceIn(0, levels.size - 1); lastChange = -1L }
}
