package com.vrboxos

/** Métricas compartilhadas entre threads (somente leitura na UI). */
object Telemetry {
    @Volatile var cameraState = com.vrboxos.hands.CameraState.OFF
    @Volatile var cameraError: String? = null
    /** Motivo de o reconhecimento de mãos estar indisponível (ex.: modelo ausente) mesmo com a câmera ativa. */
    @Volatile var handsError: String? = null
    @Volatile var framesReceived = 0
    @Volatile var lastFrameMs = 0L
    @Volatile var sensorsText = "?"
    @Volatile var displayRotationDeg = 0
    @Volatile var headPitchDeg = 0f
    @Volatile var headRollDeg = 0f
    /** Chegou quadro da câmera há pouco tempo? (evita mostrar "ativa" sem imagens) */
    fun cameraFresh(now: Long) = lastFrameMs != 0L && now - lastFrameMs < 1500
    @Volatile var renderFps = 0f
    @Volatile var handFps = 0f
    @Volatile var handLatencyMs = 0f
    @Volatile var handStatus = "Desligado"
    @Volatile var sourceName = "-"
    @Volatile var sourcesText = "?"
    @Volatile var headStatus = "Iniciando"
    @Volatile var headRateHz = 0f
    @Volatile var batteryPct = -1
    @Volatile var batteryTempC = Float.NaN
    @Volatile var charging = false
    @Volatile var net = "?"
    @Volatile var thermal = 0
    @Volatile var thermalThrottle = false
    @Volatile var inputMethod = "Olhar"
    /** true se a imagem da câmera ficou escura por alguns segundos (possível bloqueio pelo headset). */
    @Volatile var cameraObstructed = false
    /** "Minha Casa" / fundo de câmera ativo: pede mais quadros e prévia sem cópia. */
    @Volatile var passthrough = false
    // --- Medidas SEPARADAS: fluidez da imagem x latência do reconhecimento
    /** Quadros/s que a câmera entrega ao app (taxa da imagem). */
    @Volatile var cameraFps = 0f
    /** Quadros/s realmente enviados à GPU e desenhados (taxa da imagem exibida). */
    @Volatile var displayFps = 0f
    /** Chegada do quadro no app -> textura na GPU (ms). Não inclui o atraso interno do sensor/ISP. */
    @Volatile var displayLagMs = 0f
    /** Estimativa sensor -> app (ms), só quando o carimbo de tempo do CameraX é confiável. */
    @Volatile var captureToAnalyzerMs = 0f
    /** Chegada do quadro -> resultado de mãos pronto (fila + cópia + inferência) (ms). */
    @Volatile var handE2eMs = 0f
    /** Quadros descartados porque o reconhecimento ainda estava ocupado (sinal de inferência lenta). */
    @Volatile var recoDropped = 0
    @Volatile var handDelegate = "CPU"
    // --- Latência por etapa do hand tracking (médias móveis, ms)
    @Volatile var convMs = 0f              // quadro da câmera -> bitmap vertical (captura)
    @Volatile var prepMs = 0f              // cópia/escala para a entrada do MediaPipe
    @Volatile var engineMs = 0f            // gestos + filtro do cursor
    @Volatile var resultToScreenMs = 0f    // resultado pronto -> início do desenho do quadro
    @Volatile var handToScreenMs = 0f      // quadro chegou ao app -> início do desenho que usa o resultado
    @Volatile var recoScale = 1f           // escala atual da imagem de entrada do reconhecimento
    @Volatile var cameraFpsRange = "padrão"
    // --- Rastreamento espacial (ARCore)
    @Volatile var arStatus = "Desligado"
    @Volatile var arTracking = false
    @Volatile var arPlanes = 0
    @Volatile var arPoints = 0
    @Volatile var arX = 0f
    @Volatile var arY = 0f
    @Volatile var arZ = 0f
    @Volatile var arImageRotation = 0
    @Volatile var arAnchors = 0
}
