package com.vrboxos.hands

import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

class GestureConfig(
    @Volatile var sensitivity: Float = 1f,       // 0.6..1.4 (maior = pinça mais fácil)
    var minScore: Float = 0.5f,
    var minPoseMs: Long = 90,
    var pinchConfirmMs: Long = 50,
    /** Soltar a pinça confirma mais rápido que engatar: o objeto/menu solta sem atraso perceptível. */
    var pinchReleaseConfirmMs: Long = 30,
    var pinchLockoutMs: Long = 250,
    var fistHoldMs: Long = 1000,
    var openHoldMs: Long = 1200,
    var holdMaxMoveNorm: Float = 0.08f,
    var swipeMinDx: Float = 0.30f,
    var swipeMinSpeed: Float = 1.0f,
    var swipeLockMs: Long = 700,
    var lossGraceMs: Long = 250,
    var pinchEngage: Float = 0.28f,
    var pinchRelease: Float = 0.45f
)

/**
 * Classifica poses e gera eventos a partir dos 21 pontos de cada mão.
 * Kotlin puro (sem Android): testável na JVM. Usar a partir de uma única thread.
 * Os pontos são 2D da imagem; a profundidade (z) NÃO é usada para decisões.
 */
class GestureEngine(val config: GestureConfig = GestureConfig()) {
    val events = ConcurrentLinkedQueue<GestureEvent>()

    private class Slot {
        var active = false
        var lastSeen = 0L
        var lastPalmX = 0.5f
        var state: HandState? = null
        var candPose = Pose.NONE
        var candSince = 0L
        var stable = Pose.NONE
        var poseSince = 0L
        var pinching = false
        var pinchStart = 0L
        var lastPinchEnd = -1_000_000L
        var pinchCand = false
        var pinchCandSince = 0L
        val fx = OneEuro(CURSOR_MIN_CUTOFF, CURSOR_BETA, CURSOR_D_CUTOFF)
        val fy = OneEuro(CURSOR_MIN_CUTOFF, CURSOR_BETA, CURSOR_D_CUTOFF)
        val curHist = ArrayDeque<FloatArray>()   // t, x, y
        val palmHist = ArrayDeque<FloatArray>()  // t, x, y
        var fistFired = false
        var openFired = false
        var lastSwipe = -1_000_000L
        fun fresh(ts: Long, grace: Long) = active && ts - lastSeen <= grace
        fun reset() {
            active = false; state = null; candPose = Pose.NONE; stable = Pose.NONE
            pinching = false; pinchCand = false; pinchCandSince = 0L
            fx.reset(); fy.reset(); curHist.clear(); palmHist.clear()
            fistFired = false; openFired = false
        }
    }

    private val slots = arrayOf(Slot(), Slot())

    fun process(ts: Long, raw: List<RawHand>, aspect: Float, mirror: Boolean, latencyMs: Float): HandSnapshot {
        val cfg = config
        val hs = raw.filter { it.score >= cfg.minScore }
            .map { if (mirror) it.mirrored() else it }
            .sortedBy { it.lm[WRIST * 3] }
            .take(2)

        val assigned = arrayOfNulls<RawHand>(2)
        if (hs.size == 2) {
            assigned[0] = hs[0]; assigned[1] = hs[1]
        } else if (hs.size == 1) {
            val h = hs[0]
            val x = h.lm[WRIST * 3]
            val a0 = slots[0].fresh(ts, cfg.lossGraceMs)
            val a1 = slots[1].fresh(ts, cfg.lossGraceMs)
            val idx = when {
                a0 && !a1 -> 0
                a1 && !a0 -> 1
                a0 && a1 -> if (abs(x - slots[0].lastPalmX) <= abs(x - slots[1].lastPalmX)) 0 else 1
                else -> if (x < 0.5f) 0 else 1
            }
            assigned[idx] = h
        }

        for (i in 0..1) {
            val h = assigned[i]
            if (h != null) update(i, slots[i], h, ts, aspect)
            else checkLoss(i, slots[i], ts)
        }

        val states = ArrayList<HandState>(2)
        for (i in 0..1) {
            val s = slots[i]
            val st = s.state ?: continue
            if (!s.active) continue
            val age = ts - s.lastSeen
            val fade = (1f - age.toFloat() / cfg.lossGraceMs).coerceIn(0f, 1f)
            states.add(st.copy(fade = fade, ageMs = age))
        }

        var dist = -1f
        val s0 = slots[0]; val s1 = slots[1]
        val st0 = s0.state; val st1 = s1.state
        if (st0 != null && st1 != null && s0.fresh(ts, 100) && s1.fresh(ts, 100)) {
            dist = hypot((st0.palmX - st1.palmX) * aspect, st0.palmY - st1.palmY)
        }
        return HandSnapshot(ts, states, dist, aspect, latencyMs)
    }

    /** Esquece todo o estado (usar ao parar/reiniciar a fonte de vídeo). Não emite eventos. */
    fun reset() {
        for (s in slots) s.reset()
        events.clear()
    }

    private fun emit(e: GestureEvent) { events.add(e) }

    private fun checkLoss(i: Int, s: Slot, ts: Long) {
        if (s.active && ts - s.lastSeen > config.lossGraceMs) {
            endInteractions(i, s, ts)
            s.reset()
            emit(GestureEvent.HandLost(i, ts))
        }
    }

    private fun endInteractions(i: Int, s: Slot, ts: Long) {
        if (s.pinching) emit(GestureEvent.PinchEnd(i, ts, ts - s.pinchStart))
        if (s.stable == Pose.FIST) emit(GestureEvent.GrabEnd(i, ts))
    }

    private fun update(i: Int, s: Slot, hand: RawHand, ts: Long, aspect: Float) {
        val cfg = config
        val lm = hand.lm
        if (!s.active) { s.active = true; emit(GestureEvent.HandFound(i, ts)) }
        s.lastSeen = ts

        fun d(a: Int, b: Int) = hypot((lm[a * 3] - lm[b * 3]) * aspect, lm[a * 3 + 1] - lm[b * 3 + 1])
        fun ratio(tip: Int, pip: Int) = d(tip, WRIST) / max(d(pip, WRIST), 1e-4f)

        val palm = max(d(WRIST, MIDDLE_MCP), 1e-4f)
        val rIdx = ratio(8, 6); val rMid = ratio(12, 10); val rRing = ratio(16, 14); val rPink = ratio(20, 18)
        val extended = booleanArrayOf(rIdx > 1.15f, rMid > 1.15f, rRing > 1.15f, rPink > 1.15f)
        val folded = booleanArrayOf(rIdx < 1.05f, rMid < 1.05f, rRing < 1.05f, rPink < 1.05f)
        val nExt = extended.count { it }
        val pinchRatio = d(THUMB_TIP, INDEX_TIP) / palm

        // Pinça com histerese e confirmação temporal. Exige indicador não dobrado (evita punho = pinça).
        val sens = cfg.sensitivity
        val engage = cfg.pinchEngage * sens
        val release = cfg.pinchRelease * sens
        val want = if (s.pinching) !(pinchRatio > release) else (pinchRatio < engage && rIdx >= 0.85f)

        val palmX = (lm[0] + lm[5 * 3] + lm[9 * 3] + lm[13 * 3] + lm[17 * 3]) / 5f
        val palmY = (lm[1] + lm[5 * 3 + 1] + lm[9 * 3 + 1] + lm[13 * 3 + 1] + lm[17 * 3 + 1]) / 5f
        s.lastPalmX = palmX

        // Pose crua (sem pinça)
        val rawPose = when {
            nExt >= 3 -> Pose.OPEN
            folded.all { it } -> Pose.FIST
            extended[0] && folded[1] && folded[2] && folded[3] -> Pose.POINT
            else -> Pose.OTHER
        }
        if (rawPose == s.stable) {
            s.candPose = rawPose; s.candSince = ts
        } else {
            if (rawPose != s.candPose) { s.candPose = rawPose; s.candSince = ts }
            if (ts - s.candSince >= cfg.minPoseMs) {
                val old = s.stable
                s.stable = rawPose
                s.poseSince = ts
                s.fistFired = false; s.openFired = false
                if (old == Pose.FIST) emit(GestureEvent.GrabEnd(i, ts))
            }
        }

        // Cursor
        val (cx0, cy0) = when {
            s.stable == Pose.FIST && !s.pinching -> lm[9 * 3] to lm[9 * 3 + 1]
            s.pinching || pinchRatio < 0.7f ->
                (lm[THUMB_TIP * 3] + lm[INDEX_TIP * 3]) / 2f to (lm[THUMB_TIP * 3 + 1] + lm[INDEX_TIP * 3 + 1]) / 2f
            else -> lm[INDEX_TIP * 3] to lm[INDEX_TIP * 3 + 1]
        }
        val cx = s.fx.filter(cx0, ts)
        val cy = s.fy.filter(cy0, ts)
        s.curHist.addLast(floatArrayOf(ts.toFloat(), cx, cy))
        while (s.curHist.size > 1 && ts - s.curHist.first()[0] > 500) s.curHist.removeFirst()
        s.palmHist.addLast(floatArrayOf(ts.toFloat(), palmX, palmY))
        while (s.palmHist.size > 1 && ts - s.palmHist.first()[0] > 500) s.palmHist.removeFirst()

        // Estado da pinça
        if (want != s.pinching) {
            if (s.pinchCandSince == 0L || s.pinchCand != want) { s.pinchCand = want; s.pinchCandSince = ts }
            if (ts - s.pinchCandSince >= (if (want) cfg.pinchConfirmMs else cfg.pinchReleaseConfirmMs)) {
                if (want) {
                    if (ts - s.lastPinchEnd >= cfg.pinchLockoutMs) {
                        s.pinching = true; s.pinchStart = ts; s.pinchCandSince = 0L
                        val c = cursorAt(s, ts - 120)
                        emit(GestureEvent.PinchStart(i, c[0], c[1], ts))
                    }
                } else {
                    s.pinching = false; s.lastPinchEnd = ts; s.pinchCandSince = 0L
                    emit(GestureEvent.PinchEnd(i, ts, ts - s.pinchStart))
                }
            }
        } else {
            s.pinchCandSince = 0L
        }

        // Grab (punho estável) começa aqui
        if (s.stable == Pose.FIST && s.candPose == Pose.FIST && ts - s.poseSince == 0L && !s.pinching) {
            emit(GestureEvent.GrabStart(i, cx, cy, ts))
        }

        // Comandos por permanência
        val still = movement(s, 300) < cfg.holdMaxMoveNorm
        if (!s.pinching && still) {
            if (s.stable == Pose.FIST && !s.fistFired && ts - s.poseSince >= cfg.fistHoldMs) {
                s.fistFired = true; emit(GestureEvent.Hold(HoldGesture.FIST, ts))
            }
            if (s.stable == Pose.OPEN && !s.openFired && ts - s.poseSince >= cfg.openHoldMs) {
                s.openFired = true; emit(GestureEvent.Hold(HoldGesture.OPEN, ts))
            }
        }

        // Deslize lateral (mão aberta)
        if (s.stable == Pose.OPEN && !s.pinching && ts - s.lastSwipe >= cfg.swipeLockMs) {
            val first = s.palmHist.firstOrNull { ts - it[0] <= 350 }
            if (first != null && ts - first[0] >= 80) {
                val dx = palmX - first[1]
                val speed = dx / ((ts - first[0]) / 1000f)
                if (abs(dx) >= cfg.swipeMinDx && abs(speed) >= cfg.swipeMinSpeed) {
                    s.lastSwipe = ts
                    s.palmHist.clear()
                    emit(GestureEvent.Swipe(if (dx > 0) 1 else -1, ts))
                }
            }
        }

        val exposed = if (s.pinching) Pose.PINCH else s.stable
        val stability = ((ts - s.poseSince).toFloat() / 300f).coerceIn(0f, 1f)
        s.state = HandState(
            slot = i, label = hand.label, score = hand.score, lm = lm.copyOf(),
            pose = exposed, poseConfidence = hand.score * stability,
            pinchRatio = pinchRatio, pinching = s.pinching,
            cursorX = cx, cursorY = cy, palmX = palmX, palmY = palmY, fade = 1f, ageMs = 0
        )
    }

    private fun cursorAt(s: Slot, t: Long): FloatArray {
        var best = s.curHist.firstOrNull() ?: return floatArrayOf(0.5f, 0.5f)
        for (e in s.curHist) { if (e[0] <= t) best = e else break }
        return floatArrayOf(best[1], best[2])
    }

    private fun movement(s: Slot, windowMs: Long): Float {
        val last = s.palmHist.lastOrNull() ?: return 0f
        var mx = 0f
        for (e in s.palmHist) {
            if (last[0] - e[0] <= windowMs) mx = max(mx, hypot(last[1] - e[1], last[2] - e[2]))
        }
        return mx
    }

    companion object {
        // Filtro do cursor (One Euro), escolhido por simulação a 30 resultados/s: o atraso a 0,3 unid./s caiu de
        // 38,8 ms (1,5/4/1) para 9,7 ms, mantendo o ruído de repouso em ~55%. A tolerância da seleção por permanência
        // (HOLD_MARGIN) absorve o tremor restante sem reintroduzir atraso.
        const val CURSOR_MIN_CUTOFF = 1.0f
        const val CURSOR_BETA = 40f
        const val CURSOR_D_CUTOFF = 3f
        const val WRIST = 0
        const val THUMB_TIP = 4
        const val INDEX_TIP = 8
        const val MIDDLE_MCP = 9
    }
}
