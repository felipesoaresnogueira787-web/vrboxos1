package com.vrboxos.hands

/** Escolha da faixa de FPS-alvo do auto-exposição. Pura (JVM): testável sem Android. */
object FpsRange {
    /**
     * Prefere uma faixa FIXA [alvo, alvo]: impede que a auto-exposição derrube a taxa da câmera (para 15-20 fps em
     * ambientes escuros), o que dobra o intervalo entre quadros e o atraso do rastreamento. Se não existir, usa a
     * de maior piso cujo teto é o alvo. null se nada serve (aí nenhuma faixa é solicitada).
     */
    fun pick(ranges: List<IntArray>, target: Int): IntArray? {
        ranges.firstOrNull { it.size == 2 && it[0] == target && it[1] == target }?.let { return it }
        return ranges.filter { it.size == 2 && it[1] == target }.maxByOrNull { it[0] }
    }
}
