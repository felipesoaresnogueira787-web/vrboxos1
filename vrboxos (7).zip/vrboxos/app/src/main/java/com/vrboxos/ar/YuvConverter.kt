package com.vrboxos.ar

/** YUV_420_888 -> ARGB, já girado no sentido horário. Pura (JVM): testável sem Android. */
object YuvConverter {
    /** Tamanho de saída: (w,h) para 0/180 graus e (h,w) para 90/270. */
    fun outW(w: Int, h: Int, rot: Int) = if (rot % 180 == 0) w else h
    fun outH(w: Int, h: Int, rot: Int) = if (rot % 180 == 0) h else w

    fun toArgb(
        w: Int, h: Int,
        y: ByteArray, yRow: Int,
        u: ByteArray, uRow: Int, uPix: Int,
        v: ByteArray, vRow: Int, vPix: Int,
        rot: Int, out: IntArray,
        mirror: Boolean = false
    ) {
        val ow = outW(w, h, rot)
        for (sy in 0 until h) {
            val yBase = sy * yRow
            val uBase = (sy shr 1) * uRow
            val vBase = (sy shr 1) * vRow
            for (sx in 0 until w) {
                val yy = y[yBase + sx].toInt() and 0xFF
                val uu = (u[uBase + (sx shr 1) * uPix].toInt() and 0xFF) - 128
                val vv = (v[vBase + (sx shr 1) * vPix].toInt() and 0xFF) - 128
                var r = yy + ((1436 * vv) shr 10)
                var g = yy - ((352 * uu + 731 * vv) shr 10)
                var b = yy + ((1814 * uu) shr 10)
                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255
                val argb = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                val dx: Int
                val dy: Int
                when (rot) {
                    90 -> { dx = h - 1 - sy; dy = sx }
                    180 -> { dx = w - 1 - sx; dy = h - 1 - sy }
                    270 -> { dx = sy; dy = w - 1 - sx }
                    else -> { dx = sx; dy = sy }
                }
                out[dy * ow + (if (mirror) ow - 1 - dx else dx)] = argb
            }
        }
    }
}
