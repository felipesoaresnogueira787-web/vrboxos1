package com.vrboxos.hands

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.ComponentActivity
import com.vrboxos.Telemetry
import com.vrboxos.ar.ArTracker
import com.vrboxos.VrLog
import com.vrboxos.settings.CameraKind
import com.vrboxos.settings.Settings
import java.util.concurrent.Executors

/** Liga fonte de vídeo -> MediaPipe -> GestureEngine, com estados reais e recuperação de falhas. */
class HandPipeline(
    private val activity: ComponentActivity,
    private val settings: Settings,
    private val ar: ArTracker,
    private val notify: (String) -> Unit
) {
    val engine = GestureEngine()
    val tracker = HandTracker(activity.applicationContext, engine)

    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var source: VideoSource? = null
    private var activeKind: CameraKind? = null
    private var arActive = false
    private var activeSpatial = false
    @Volatile private var wanted = false
    private var retries = 0
    private var generation = 0
    private var startedAt = 0L

    val running get() = wanted

    /** Taxa máxima do RECONHECIMENTO (a imagem exibida não depende dela). */
    private fun recoCap() = if (Telemetry.thermalThrottle) 10 else if (Telemetry.passthrough) 30 else settings.handFpsCap

    /** Taxa que a captura entrega: sem limite artificial quando a imagem está sendo exibida. */
    private fun fpsCap() = if (tracker.wantPreview || tracker.recognitionEnabled) 60 else 10   // sem corte artificial de taxa

    /** Idempotente: não reabre a câmera se ela já está em uso com a mesma fonte. */
    fun start() {
        val st = Telemetry.cameraState
        if (wanted && (source != null || arActive) && activeKind == settings.camera && activeSpatial == settings.spatial &&
            (st == CameraState.INITIALIZING || st == CameraState.ACTIVE)
        ) return
        wanted = true
        retries = 0
        launch()
    }

    /** Força reabrir (ex.: o usuário trocou a fonte de câmera). */
    fun restart() {
        wanted = true
        retries = 0
        launch()
    }

    private fun setState(s: CameraState, error: String? = null) {
        VrLog.i("camera", "estado: ${s.label}" + (error?.let { " ($it)" } ?: ""))
        Telemetry.cameraState = s
        Telemetry.cameraError = error
    }

    private fun launch() {
        if (!wanted) return
        stopSource()
        val gen = ++generation
        // Modo espacial: o ARCore passa a ser a fonte da câmera (ele exige a câmera só para si).
        val spatialWanted = settings.spatial
        val useAr = spatialWanted && ar.availability() == ArTracker.Availability.SUPPORTED
        if (spatialWanted && !useAr) {
            Telemetry.arStatus = "ARCore indisponível"
            notify("Rastreamento espacial indisponível neste aparelho: usando só rotação (3DoF).")
        }
        activeSpatial = spatialWanted
        setState(CameraState.INITIALIZING)
        Telemetry.framesReceived = 0
        Telemetry.lastFrameMs = 0L
        Telemetry.handStatus = "Iniciando..."
        startedAt = SystemClock.elapsedRealtime()
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, 1000)
        bg.execute {
            tracker.useGpu = settings.useGpu
            val ok = tracker.init()                       // carrega o modelo na thread de reconhecimento
            main.post {
                if (gen != generation || !wanted) return@post
                if (!ok) {
                    // O modelo é só do reconhecimento: a CÂMERA segue funcionando (prévia, fundo, diagnóstico).
                    Telemetry.handsError = tracker.error ?: "modelo de mãos indisponível"
                    Telemetry.handStatus = "Mãos indisponíveis: ${tracker.error}"
                    notify("Reconhecimento de mãos indisponível (${tracker.error ?: "modelo"}). A câmera segue ativa.")
                } else Telemetry.handsError = null
                if (useAr) startAr(gen) else openSource(gen)
            }
        }
    }

    private fun openSource(gen: Int) {
        val src = CameraXSource(activity, settings.camera) { fpsCap() }
        source = src
        activeKind = settings.camera
        src.onNotice = { msg -> main.post { notify(msg) } }
        Telemetry.sourceName = src.name
        var first = true
        src.start(
            onFrame = { bmp, ts ->
                if (gen == generation) {
                    engine.config.sensitivity = settings.gestureSens
                    tracker.recognitionEnabled = settings.handEnabled
                    tracker.recoFpsCap = recoCap()
                    tracker.resolutionMode = settings.recoResolution
                    tracker.onCameraFrame(bmp, ts, settings.mirrorHands)
                    if (first) { first = false; retries = 0 }
                }
            },
            onError = { msg -> main.post { if (gen == generation) handleError(msg) } }
        )
    }

    /** Fonte ARCore: os quadros chegam pelo ArTracker (GL) já convertidos em bitmaps verticais. */
    private fun startAr(gen: Int) {
        arActive = true
        activeKind = settings.camera
        Telemetry.sourceName = "ARCore (câmera traseira)"
        ar.sink = { bmp, ts ->
            if (gen == generation) {
                engine.config.sensitivity = settings.gestureSens
                tracker.recognitionEnabled = settings.handEnabled
                tracker.recoFpsCap = recoCap()
                tracker.resolutionMode = settings.recoResolution
                tracker.onCameraFrame(bmp, ts, false)
            }
        }
        val ok = ar.start { msg -> main.post { if (gen == generation) handleError(msg) } }
        VrLog.i("camera", "fonte: ARCore (ok=$ok)")
    }

    /** Se a câmera "abriu" mas não entrega imagens, o estado NÃO fica como ativo. */
    private val watchdog = object : Runnable {
        override fun run() {
            if (!wanted) return
            val now = SystemClock.elapsedRealtime()
            when (Telemetry.cameraState) {
                CameraState.ACTIVE ->
                    if (now - Telemetry.lastFrameMs > 3000) handleError("a câmera parou de entregar imagens")
                CameraState.INITIALIZING ->
                    if (now - startedAt > 10_000) handleError("a câmera não entregou imagens em 10 s")
                else -> {}
            }
            main.postDelayed(this, 1000)
        }
    }

    private fun handleError(msg: String) {
        stopSource()
        setState(CameraState.UNAVAILABLE, msg)
        Telemetry.handStatus = "Falha: $msg"
        notify("Câmera: $msg")
        if (wanted && retries < MAX_RETRIES) {
            retries++
            main.postDelayed({ launch() }, 3000L)
        } else if (wanted) {
            wanted = false
            notify("Câmera perdida. Hand tracking desligado; usando olhar.")
        }
    }

    private fun stopSource() {
        source?.stop()
        source = null
        if (arActive) { ar.sink = null; ar.pause(); arActive = false }
    }

    fun stop() {
        wanted = false
        generation++
        main.removeCallbacks(watchdog)
        stopSource()
        // O diálogo de permissão do sistema pausa a Activity: não apagar o "aguardando permissão".
        if (Telemetry.cameraState != CameraState.WAITING_PERMISSION) setState(CameraState.OFF)
        Telemetry.handStatus = "Desligado"
        Telemetry.handFps = 0f
        Telemetry.cameraObstructed = false
        // esquece pinça/punho/posições: ao retomar, nada fica "preso" a uma pose antiga
        tracker.reset()
    }

    fun release() {
        stop()
        ar.close()
        tracker.close()
        bg.shutdown()
    }

    companion object { private const val MAX_RETRIES = 5 }
}
