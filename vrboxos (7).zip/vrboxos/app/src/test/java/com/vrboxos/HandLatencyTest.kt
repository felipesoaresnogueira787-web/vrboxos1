package com.vrboxos

import com.vrboxos.ar.YuvConverter
import com.vrboxos.hands.FpsRange
import com.vrboxos.hands.GestureEngine
import com.vrboxos.hands.OneEuro
import com.vrboxos.hands.ResolutionTuner
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.sin
import kotlin.math.sqrt

/** Testes dos parâmetros que determinam a latência do hand tracking (cálculos exatos, não medidas de aparelho). */
class HandLatencyTest {
    /** Atraso (ms) de um filtro seguindo uma rampa de velocidade [v] (unid./s) com resultados a 30 Hz. */
    private fun lagMs(f: OneEuro, v: Float): Float {
        val dt = 1000f / 30f
        val n = 180
        var sum = 0f; var cnt = 0
        for (i in 0 until n) {
            val t = i * dt
            val x = 0.2f + v * t / 1000f
            val y = f.filter(x, t.toLong())
            if (i > n / 2) { sum += (x - y) / v * 1000f; cnt++ }
        }
        return sum / cnt
    }

    private fun newFilter() = OneEuro(GestureEngine.CURSOR_MIN_CUTOFF, GestureEngine.CURSOR_BETA, GestureEngine.CURSOR_D_CUTOFF)
    private fun oldFilter() = OneEuro(1.5f, 4f, 1f)

    @Test fun cursorFilterLagDropsSeveralFold() {
        assertTrue("antigo a 0,3/s", lagMs(oldFilter(), 0.3f) > 30f)
        assertTrue("novo a 0,3/s", lagMs(newFilter(), 0.3f) < 12f)
        assertTrue("antigo a 1/s", lagMs(oldFilter(), 1f) > 15f)
        assertTrue("novo a 1/s", lagMs(newFilter(), 1f) < 5f)
        assertTrue("novo a 2/s", lagMs(newFilter(), 2f) < 3f)
    }

    @Test fun restingJitterIsStillReduced() {
        val f = newFilter()
        val sigma = 0.003f
        val outs = ArrayList<Float>()
        for (i in 0 until 600) {
            val noise = sigma * sin(i * 2.399f) + sigma * 0.7f * sin(i * 0.77f + 1f)
            val y = f.filter(0.5f + noise, (i * 33).toLong())
            if (i > 60) outs.add(y)
        }
        val m = outs.average().toFloat()
        val sd = sqrt(outs.map { (it - m) * (it - m) }.average()).toFloat()
        assertTrue("o ruído de repouso deve cair (restou ${sd / sigma})", sd < 0.8f * sigma)
    }

    @Test fun releasingThePinchIsConfirmedFasterThanEngaging() {
        val cfg = com.vrboxos.hands.GestureConfig()
        assertTrue(cfg.pinchReleaseConfirmMs < cfg.pinchConfirmMs)
        assertEquals(30L, cfg.pinchReleaseConfirmMs)
    }

    // ---------------- resolução adaptativa (medida no aparelho) ----------------
    private fun feed(t: ResolutionTuner, fromSec: Int, toSec: Int, infer: Float, drop: Float = 0f, interval: Float = 33f) {
        for (s in fromSec..toSec) t.update(s * 1000L, infer, interval, drop)
    }

    @Test fun fastDeviceKeepsFullResolution() {
        val t = ResolutionTuner()
        feed(t, 0, 120, 12f)
        assertEquals(0, t.level); assertEquals(1f, t.scale, 0f)
    }

    @Test fun slowDeviceStepsDownUntilItKeepsUpAndNeverBelowTheLast() {
        val t = ResolutionTuner()
        feed(t, 0, 3, 40f)
        assertEquals(1, t.level)                       // 40 ms > 90% de 33 ms: desce um nível
        feed(t, 4, 60, 40f)                            // continua lento mesmo reduzido: desce de novo e para no último
        assertEquals(2, t.level)
        assertEquals(0.5f, t.scale, 0f)
    }

    @Test fun stepsDownThenStaysWhenTheLowerLevelIsEnough() {
        val t = ResolutionTuner()
        feed(t, 0, 3, 36f)                             // nível 0 custa 36 ms
        assertEquals(1, t.level)
        feed(t, 4, 80, 36f * 0.5625f)                  // no nível 0,75 custa ~20 ms; subir previsto = 36 ms: NÃO sobe
        assertEquals(1, t.level)
    }

    @Test fun returnsToFullResolutionWhenTheLoadDisappears() {
        val t = ResolutionTuner()
        feed(t, 0, 3, 40f)
        assertEquals(1, t.level)
        feed(t, 4, 30, 14f)                            // previsto no nível 0: 14 * 1,78 = 25 ms < 80% de 33 ms
        assertEquals(0, t.level)
    }

    @Test fun droppedFramesAlsoTriggerAStepDown() {
        val t = ResolutionTuner()
        feed(t, 0, 3, 10f, drop = 0.3f)
        assertEquals(1, t.level)
    }

    @Test fun manualChoiceOverridesAuto() {
        val t = ResolutionTuner()
        t.force(2); assertEquals(0.5f, t.scale, 0f)
        t.force(9); assertEquals(2, t.level)
        t.force(-3); assertEquals(0, t.level)
    }

    // ---------------- faixa de FPS fixa ----------------
    @Test fun fixedThirtyFpsRangeIsPreferred() {
        val r = listOf(intArrayOf(15, 30), intArrayOf(30, 30), intArrayOf(24, 30))
        assertArrayEquals(intArrayOf(30, 30), FpsRange.pick(r, 30))
    }

    @Test fun otherwiseTheHighestFloorUnderTheTarget() {
        val r = listOf(intArrayOf(15, 30), intArrayOf(24, 30), intArrayOf(7, 24))
        assertArrayEquals(intArrayOf(24, 30), FpsRange.pick(r, 30))
        assertNull(FpsRange.pick(listOf(intArrayOf(15, 24)), 30))
        assertNull(FpsRange.pick(emptyList(), 30))
    }

    // ---------------- conversão da captura: espelhamento (câmera frontal) ----------------
    private fun gray(v: Int) = (0xFF shl 24) or (v shl 16) or (v shl 8) or v

    private fun run(rot: Int, mirror: Boolean): IntArray {
        val y = ByteArray(8) { (it * 10).toByte() }
        val c = ByteArray(2) { 128.toByte() }
        val out = IntArray(8)
        YuvConverter.toArgb(4, 2, y, 4, c, 2, 1, c, 2, 1, rot, out, mirror)
        return out
    }

    @Test fun mirroringFlipsTheOutputHorizontally() {
        val a = run(0, true)                                  // linha 0 vira 30,20,10,0
        assertEquals(gray(30), a[0]); assertEquals(gray(0), a[3]); assertEquals(gray(70), a[4]); assertEquals(gray(40), a[7])
        val b = run(90, true)                                 // saída 2x4
        assertEquals(gray(0), b[0]); assertEquals(gray(40), b[1])
        // sem espelhar, igual ao comportamento anterior
        val c = run(0, false); for (i in 0 until 8) assertEquals(gray(i * 10), c[i])
    }
}
