# Atualização: modo VR lado a lado, calibração, orientação, câmera e mídia

> **O ZIP citado no pedido não chegou** (pasta de uploads vazia). Esta atualização foi feita sobre o
> projeto VR BOX OS desta conversa. Nenhum arquivo foi recriado; as telas e funções existentes foram mantidas.

## Arquivos novos
`media/VideoFormat.kt`, `render/SphereMesh.kt`, `app/src/test/.../StereoCalibrationTest.kt`, `docs/ATUALIZACAO.md`.

## Arquivos alterados
`settings/Settings.kt` (alinhamento, escala, orientação) · `render/StereoLayout.kt` (viewport calibrado, FOV) ·
`render/VrRenderer.kt` (calibração no pós-processamento, esfera 360, guias, FOV) · `render/Renderers.kt`
(SphereRenderer) · `media/CinemaPlayer.kt` (formato, mudo, foco de áudio) · `ui/SpatialUi.kt` (tela de calibração,
Entrar/Sair VR, novas linhas de configuração, controles do cinema, avisos) · `input/InputRouter.kt` (FOV do toque) ·
`hands/CameraXSource.kt` (rotação acompanha o display) · `hands/HandTracker.kt` (câmera escura) ·
`hands/HandPipeline.kt`, `Telemetry.kt`, `AppController.kt`, `MainActivity.kt` (permissão, orientação, toque no VR) ·
`README.md`, `docs/STATUS.md`.

## Correções
* Rotação da câmera não acompanhava o display (imagem de cabeça para baixo ao virar o celular): agora o
  `ImageAnalysis.targetRotation` é atualizado por `DisplayListener`. **Não há "inversão da interface inteira".**
* Orientação: agora há modos automático/paisagem/invertida e `requestedOrientation` é reaplicado ao entrar/sair do VR.
* Em telas em pé o campo de visão horizontal era cortado: o FOV vertical é recalculado pela proporção.

## O que foi testado
Somente em Python (replicando as mesmas fórmulas) e por análise estática: viewport calibrado, FOV, UV por olho,
malha da esfera, balanceamento e referências. Testes JVM novos estão escritos e **não foram executados**.
Nada foi compilado nem rodado em celular/headset.

## Depende de celular + headset reais
Alinhamento correto nas lentes, sinal/valor da distorção, orientação em cada sentido, áudio/sincronia,
câmera externa USB, desempenho térmico, qualidade do reconhecimento de mãos.


---

# Segunda atualização: câmera integrada ao ambiente, estados reais, sensores e diagnóstico

> **O ZIP citado no pedido continua sem chegar** (uploads vazios nas duas vezes). O trabalho segue sobre o
> VR BOX OS desta conversa; nada foi recriado.

## Arquivos novos
`hands/CameraState.kt`, `app/src/test/.../HeadTrackingTest.kt`.

## Arquivos alterados
`hands/HandPipeline.kt` (estados, watchdog, partida idempotente, `restart()`) · `hands/HandTracker.kt`
(quadros válidos, prévia com pontos) · `head/HeadTracker.kt` e `head/Quat.kt` (giroscópio, taxa, sensores) ·
`render/VrRenderer.kt` (textura da câmera, painel e fundo, indicador, marcadores de orientação) ·
`ui/SpatialUi.kt`, `ui/Panel.kt` (tela Câmera, status, configurações, diagnóstico) · `MainActivity.kt`,
`AppController.kt`, `Telemetry.kt` (permissão, sensores sob demanda, teclas de mídia) · `README.md`, `docs/STATUS.md`.

## Sobre a imagem "de cabeça para baixo"
Não consegui reproduzir (não há aparelho). Foi verificado, por conta e análise estática: (1) a cadeia
sensor -> tela -> mundo GL dá identidade para um celular em paisagem, de pé, olhando ao Norte, nos dois
sentidos de paisagem; (2) o caminho de textura dos painéis e do pós-processamento não inverte o eixo vertical;
(3) a rotação do `ImageAnalysis` da câmera não acompanhava o display (corrigido na atualização anterior).
Se ainda ocorrer, o Diagnóstico agora mostra a rotação do display, a inclinação e o giro (roll) lidos do sensor
e a Calibração mostra marcadores de "topo": com esses números dá para apontar a causa real sem chute.
Não foi aplicada nenhuma rotação fixa de 180°.

## O que foi testado
Somente análise estática e replicação em Python das contas (giroscópio, viewport, UV, esfera). Testes JVM
escritos e **não executados**. **Nada foi compilado nem rodado em celular ou headset.**

## Depende de celular + headset reais
Orientação nos dois sentidos de paisagem; estados da câmera na prática; imagem real chegando; qualidade do
reconhecimento de mãos; se a câmera enxerga as mãos com o aparelho no headset; câmera externa USB; deriva do
giroscópio puro; áudio e sincronia; temperatura e bateria.


---

# Terceira atualização: causas reais da câmera e da inversão, e navegador

> **O ZIP citado no pedido continua sem chegar** (uploads vazios nas três vezes). O trabalho segue sobre o VR BOX
> OS desta conversa; nada foi recriado. Os sintomas que você descreveu (câmera "indisponível", imagem certa por
> ~1 s e depois invertida) vieram de rodar este app, então a análise abaixo é sobre o código dele.

## Causa 1: imagem certa por ~1 s e depois de cabeça para baixo
Até chegar o **primeiro evento do sensor**, a orientação da cabeça é a identidade (tudo em pé). Quando o sensor
começa (cerca de 1 s depois de abrir), o app passa a aplicar a orientação medida. O remapeamento para paisagem usava
`Rz(+90°)` para `ROTATION_90` e `Rz(-90°)` para `ROTATION_270`. Pela documentação do Android, `ROTATION_90` é o
aparelho girado 90° no sentido anti-horário (topo à esquerda), o que exige o oposto. Com o sinal trocado a visão
fica girada 180° **nas duas paisagens**, e persiste ao girar o aparelho, como você viu. Em retrato (usado nas
verificações antigas) o erro não aparece.
* **Correção:** sinal derivado da física, com testes nas quatro rotações do display; o teste de regressão
  confirma que o sinal antigo inverte as duas paisagens.
* **Rede de segurança:** o acelerômetro/gravidade confere se "para cima" aponta para o topo da tela e, se não,
  troca o sinal sozinho e registra no log.
* **Logs:** `orient` (display, sinal, inclinação, giro a cada 2 s; aviso se giro > 135°), mudanças de
  configuração/orientação da Activity, e rotação aplicada à imagem da câmera.

## Causa 2: câmera "indisponível"
* Qualquer erro do CameraX, **inclusive os recuperáveis** (ex.: câmera em uso), era tratado como fatal.
* Se o **modelo de mãos** não carregasse, a câmera inteira era marcada como indisponível, com a mensagem "modelo
  ausente". Agora a câmera segue ativa e só o reconhecimento fica indisponível (aparece no status).
* Sem câmera do tipo escolhido, agora tenta as outras e avisa qual usou.
* O modelo passa a ser baixado pelo próprio Gradle (não depende do passo do workflow).
* Faltava a permissão **INTERNET** (necessária ao navegador).
* Erros agora mostram a causa real (ex.: `IllegalArgumentException: ...`) e vão para o log.

## Navegador
WebView real (JavaScript ligado, sem acesso a arquivos), desenhado em textura e mostrado nos dois olhos, com barra
de endereço, pesquisa, HTTPS, histórico, rolagem, teclado virtual (VR) e teclado do Android (modo plano).

## O que foi testado
Análise estática e replicação numérica em Python (poses físicas nas 4 rotações, gravidade, giroscópio, viewport,
UV, esfera); testes JVM novos escritos e **não executados**. **Nada foi compilado nem rodado em celular.**
Se a visão ainda estiver invertida, abra Diagnóstico > Compartilhar log: ele mostra o display, o sinal e o giro
medidos, e basta me enviar.

## Depende de celular + headset
Orientação nos dois sentidos de paisagem; estados e imagens da câmera; reconhecimento de mãos com o aparelho no
headset; desempenho do WebView desenhado em bitmap; teclado do Android em páginas; áudio/sincronia; bateria.


---

# Quarta atualização: erro de compilação do CameraX e menu mais perto

## 1. `Unresolved reference: ERROR_TYPE_CRITICAL` (CameraXSource.kt, linha 136)
As constantes `ERROR_TYPE_CRITICAL/RECOVERABLE` não são acessíveis como eu usava na versão do CameraX do projeto
(1.3.4). Agora a classificação usa o **código** do erro (`StateError.code`), que já era usado no arquivo:
códigos 1, 2 e 3 = recuperáveis (o CameraX tenta de novo, só avisa); os demais = críticos (derrubam e o pipeline
tenta reabrir). A lógica ficou em `hands/CameraErrors.kt` (testável) e o `import ... as XCameraState`, que ficou
sem uso, foi removido. O tratamento de erros da câmera e o reconhecimento de mãos foram preservados.
Busquei no projeto por outras referências a constantes do CameraX: não há mais nenhuma.

## 2. Menu do VR mais perto e mais legível
* **Posição real:** distância padrão dos painéis **2,0 m -> 1,25 m** (`z = -1,25`), com paralaxe estéreo real.
* **Tamanho:** a escala padrão passou de **1,0 -> 1,3** e agora vale para o layout inteiro (posições e tamanhos
  juntos, senão painéis maiores se sobreporiam). Largura angular do menu: **53° -> 66°**.
* Centrado (topo 29,3° / base 29,4° do centro), dentro do campo de visão; a mão virtual (a 1,0 m) continua na frente.
* Navegador e cinema, que são maiores, usam um fator menor (0,8 e 0,75) e continuam dentro do campo (<= 41,5°).
* Configurações salvas com chaves novas (`*_v2`): o novo padrão vale mesmo para quem já abriu o app.
  Distância ajustável de 0,8 m a 4 m; escala de 0,6x a 1,8x (Configurações).
* **Não foi alterada** a rotação (`DEFAULT_REMAP_SIGN` segue -1), nem a câmera além do item 1, nem o resto.

## O que foi verificado
Análise estática (delimitadores, referências, restos de símbolos) e contas em Python da geometria do menu.
Testes JVM novos (`PanelLayoutTest`) escritos e **não executados**.
**A compilação NÃO foi feita**: o ambiente tem apenas o Java (sem javac, Gradle, Android SDK ou rede).
O resultado do build vem do GitHub Actions.


---

# Quinta atualização: Minha Casa, menu na mão e seleção por dedo

## Arquivos novos
`app/src/test/.../HandInteractionTest.kt`.

## Arquivos alterados
`render/Environments.kt` (4º ambiente) · `render/VrRenderer.kt` (zoom, mapeamento alinhado, contorno do menu agarrado) ·
`settings/Settings.kt` (ambiente 0..3, tempo do dedo, zoom) · `input/InputUtil.kt` (`HoldSelector`) ·
`input/InputRouter.kt` (`HandMapping` alinhado à câmera, pinça que pega o menu, permanência do dedo) ·
`ui/SpatialUi.kt`, `ui/Panel.kt`, `ui/PanelGeometry.kt` (grupos, alvo suavizado, alcance, seleção de ambiente) ·
`hands/HandTracker.kt`, `hands/HandPipeline.kt`, `Telemetry.kt` (latência) · `MainActivity.kt` (liga a câmera ao abrir em
Minha Casa) · docs.

## Como cada pedido foi atendido
1. **Minha Casa:** o fundo de câmera que já existia agora é ativado pelo ambiente; câmera traseira por padrão
   (a frontal olha para você); as mãos continuam, porque os mesmos quadros alimentam o fundo e o MediaPipe.
2. **Menu na mão:** pinça + movimento agarra o grupo inteiro do menu; a posição-alvo é suavizada (~70 ms);
   limite de alcance; "Recentrar" restaura.
3. **Dedo + 5 s:** ponto e anel já existiam para o olhar; agora também para a mão, com `HoldSelector` (tolerância
   de tremor, reinício, sem repetição). O ponto usa o mesmo enquadramento da imagem da câmera.
4. **Latência:** no passthrough o mesmo bitmap vai à GPU sem cópia e antes da inferência; 30 fps; miniatura só no
   Diagnóstico; processamento já era fora da thread principal e descartava quadros antigos.

## Limites honestos
Passthrough 2D mono (sem profundidade). Seleção por dedo exige a pose "apontar" detectada pelo MediaPipe+classificador.
A câmera traseira pode estar tampada pelo headset. Latência real, precisão do alinhamento e conforto **não foram medidos**.

## O que foi testado
Contas replicadas em Python (seletor de permanência, mapeamento, alcance); análise estática; testes JVM novos escritos
e **não executados**. **Nada foi compilado nem rodado em celular** (o ambiente só tem o Java, sem javac/Gradle/SDK/rede).


---

# Sexta atualização: câmera fluida, tela no espaço e rastreamento espacial (ARCore)

## 1. Câmera travada: causa e correção
**Causa:** o quadro era entregue ao `HandTracker.onFrame`, que rodava a inferência do MediaPipe na MESMA thread e sob
`synchronized`. Logo a cadência do vídeo exibido era a da inferência (+ conversões), e cada quadro ainda criava dois
Bitmaps novos. **Correção:**
* Exibição e reconhecimento separados: a thread de captura só contabiliza, publica o quadro para a GPU sem cópia e
  retorna; o reconhecimento roda em thread própria e recebe, por uma caixa de correio de UM lugar, só o quadro mais novo
  (os antigos são descartados, nunca acumulam). O MediaPipe, o classificador de gestos e a taxa máxima do reconhecimento
  continuam como antes: nada foi reduzido ou desativado.
* Pool de 4 bitmaps reutilizados; uma conversão de formato e uma passada de rotação por quadro.
* Quadros e recursos fechados no `finally`; `fpsCap` não limita mais a imagem exibida.
* Medidas separadas (tela *Diagnóstico > Desempenho*): fps entregue pela câmera, fps desenhado, atraso app→GPU,
  inferência, quadro→resultado de mãos e descartados, com um diagnóstico em texto de qual é o gargalo.
* Delegate de GPU do MediaPipe: opcional (desligado), com volta ao CPU se falhar.

## 2. A tela virtual como objeto no espaço
Antes: a visão só tinha rotação e cada painel era um plano em `z = -distância`, preso à origem. Agora:
* `PanelGroup`: uma pose 3D (posição + orientação) compartilhada por todos os painéis, independente do ambiente.
* A matriz de visão inclui a **posição dos olhos** (`HeadPose.position`); o raio de apontar sai dos olhos.
* Arrasto livre: a tela segue o ponto apontado à distância em que foi agarrada, voltada para o usuário, em qualquer
  altura ou direção; ao soltar permanece (e, com ARCore, ganha uma âncora).
* "Recentrar" e o gesto de menu colocam a tela à frente, na direção em que você olha.

## 3. Rastreamento espacial
* `ar/ArTracker.kt` (todo o uso do ARCore): sessão, posição, âncoras, superfícies, pontos de referência e imagem de CPU.
* Alinhamento do mundo do ARCore com o do giroscópio pela guinada (`ArMath`), posição publicada em `HeadPose.position`.
* Com o espacial ligado o ARCore é a fonte da câmera (mãos e "Minha Casa"); sem ele, o CameraX de sempre.
* Opcional em tempo de execução e no manifesto (`camera.ar` não obrigatório); desligado por padrão.

## O que foi verificado
Replicação em Python de: interseção de raio em painéis orientados (frente, laterais, atrás, teto, chão), distâncias ao
andar, alinhamento de guinada, ida e volta AR↔renderização, rotação da imagem e conversão YUV; análise estática
(47 arquivos, referências e construtores). Testes JVM escritos e **não executados**.
**NADA foi compilado e NADA foi executado em celular**: o ambiente só tem o Java (sem javac/Gradle/SDK/rede).
A versão `com.google.ar:core:1.42.0` foi escolhida de memória: se o Gradle não resolvê-la, troque pela mais recente.

## Só um aparelho real confirma
Se a imagem ficou fluida e quanto; se o ARCore é suportado e rastreia com o celular no headset (e se o headset tampa a
câmera traseira); a escala e a deriva da posição; a rotação da imagem de CPU do ARCore (há ajuste manual); o conforto de
mover a tela; o delegate de GPU; a bateria e a temperatura com ARCore + MediaPipe juntos.


---

# Sétima atualização: menor latência no hand tracking

> Único objetivo: latência do hand tracking. Nenhuma funcionalidade nova. Rotação, AR, âncoras, passthrough e navegador
> não foram alterados (o conversor YUV ganhou um parâmetro OPCIONAL de espelhamento; as chamadas do AR continuam iguais).

## Como o frame chega à tela, e onde havia atraso (por leitura do código; sem aparelho para medir)
| Etapa | O que havia | Mudança |
|---|---|---|
| Sensor → CameraX | auto-exposição podia derrubar a taxa no escuro | pede faixa de FPS **fixa 30-30** (se o aparelho oferece) |
| Captura | formato RGBA com conversão em GPU do CameraX + 2 passos de cópia/rotação; corte de taxa a 20 fps | **YUV nativo**, uma passada para ARGB vertical/espelhado em buffers reutilizados; sem corte |
| Entrega ao MediaPipe | segundo corte de 20 fps no envio | sem corte (caixa de correio de 1 lugar: sempre o quadro mais novo; os velhos são descartados) |
| MediaPipe | entrada sempre 640x480 | **escala adaptativa** medida no aparelho (100% quando rápido); modo VIDEO e landmarker criado uma vez, como antes |
| Gestos/cursor | filtro One Euro 1,5/4/1: atrasa o cursor | 1,0/40/3: atraso calculado 38,8 → 9,7 ms (0,3 unid./s), 20,1 → 3,5 ms (1 unid./s) |
| Pinça/arrasto | soltar confirmava em 50 ms; arrasto só após 250 ms; menu seguia com ~70 ms | 30 ms; 120 ms; ~25 ms enquanto segurado |
| Renderização | já lia o resultado mais novo sem bloquear | inalterado; agora mede resultado→desenho |

## Números: o que é calculado e o que NÃO foi medido
* **Calculado (simulação exata do filtro, 30 resultados/s):** os atrasos do cursor acima e o ruído de repouso (39% → 55%).
* **NÃO medido:** captura→resultado, inferência, fps de mãos, resultado→tela e o total, antes ou depois: não há aparelho
  neste ambiente. **Não há comparação antes/depois medida.** Por isso o app agora mede tudo por etapa para você comparar
  as duas versões no seu celular (Desempenho / log `perf`).

## Limites reais
* O atraso interno da câmera (sensor/ISP/buffers do Android) e a varredura da tela não são controlados pelo app.
* A 30 resultados/s o piso de amostragem é ~33 ms por resultado: zerar o atraso não é possível com esta câmera.
* GPU no MediaPipe continua opcional e desligada: sem aparelho não afirmo que seja mais rápida que a CPU nele.
* A resolução menor (75%/50%) só entra se o aparelho não acompanhar; a precisão nesses níveis não foi medida.

## Verificação
Cálculo do filtro e réplicas em Python (sintonia de resolução, faixa de FPS, espelhamento, soltura da pinça); análise
estática (50 arquivos); testes JVM novos escritos e **não executados**. **Nada foi compilado nem rodado em celular.**
Uma réplica pegou um defeito real no `ResolutionTuner` (sentinela `0`), já corrigido.
