#!/usr/bin/env bash
# Baixa o modelo oficial do MediaPipe Hand Landmarker (Apache License 2.0) para os assets do app.
set -euo pipefail
DEST="app/src/main/assets/hand_landmarker.task"
URL="https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
mkdir -p "$(dirname "$DEST")"
if [ -s "$DEST" ]; then echo "Modelo já existe: $DEST"; exit 0; fi
curl -fL --retry 3 -o "$DEST" "$URL"
SIZE=$(stat -c%s "$DEST")
if [ "$SIZE" -lt 1000000 ]; then echo "Download suspeito ($SIZE bytes)"; rm -f "$DEST"; exit 1; fi
echo "Modelo baixado: $DEST ($SIZE bytes)"
