package com.vrboxos.render

object Shaders {
    const val TEX_VS = """
        attribute vec3 aPos; attribute vec2 aUv;
        uniform mat4 uMvp; uniform mat4 uUv;
        varying vec2 vUv;
        void main() { gl_Position = uMvp * vec4(aPos, 1.0); vUv = (uUv * vec4(aUv, 0.0, 1.0)).xy; }
    """
    const val TEX_FS = """
        precision mediump float;
        varying vec2 vUv; uniform sampler2D uTex; uniform vec4 uTint;
        void main() { gl_FragColor = texture2D(uTex, vUv) * uTint; }
    """
    const val OES_FS = """
        #extension GL_OES_EGL_image_external : require
        precision mediump float;
        varying vec2 vUv; uniform samplerExternalOES uTex; uniform vec4 uTint;
        void main() { gl_FragColor = texture2D(uTex, vUv) * uTint; }
    """
    const val COLOR_VS = """
        attribute vec3 aPos; attribute vec4 aColor;
        uniform mat4 uMvp; uniform float uPoint;
        varying vec4 vColor;
        void main() { gl_Position = uMvp * vec4(aPos, 1.0); gl_PointSize = uPoint; vColor = aColor; }
    """
    // Saída pré-multiplicada (blend ONE, ONE_MINUS_SRC_ALPHA).
    const val COLOR_FS = """
        precision mediump float;
        varying vec4 vColor;
        void main() { gl_FragColor = vec4(vColor.rgb * vColor.a, vColor.a); }
    """
    const val DIST_VS = """
        attribute vec2 aPos; attribute vec2 aUv;
        varying vec2 vUv;
        void main() { gl_Position = vec4(aPos, 0.0, 1.0); vUv = aUv; }
    """
    // Distorção radial por olho (calibração visual; k1=0 => passagem direta).
    const val DIST_FS = """
        precision mediump float;
        varying vec2 vUv; uniform sampler2D uTex; uniform float uK1; uniform float uU0;
        void main() {
            vec2 c = (vUv - 0.5) * 2.0;
            float r2 = dot(c, c);
            vec2 d = c * (1.0 + uK1 * r2);
            vec2 uv = d * 0.5 + 0.5;
            if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
                gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
            } else {
                gl_FragColor = texture2D(uTex, vec2(uU0 + uv.x * 0.5, uv.y));
            }
        }
    """
}
