package com.vrboxos.media

import android.content.Context
import android.graphics.SurfaceTexture
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Surface
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.vrboxos.render.GlUtil
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reproduz vídeo local (Media3/ExoPlayer) para uma SurfaceTexture que o renderizador desenha
 * como textura externa. O ExoPlayer só é tocado na thread principal; o estado é copiado para
 * campos @Volatile lidos pela thread GL.
 */
class CinemaPlayer(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var st: SurfaceTexture? = null
    private var surface: Surface? = null
    private val frameAvailable = AtomicBoolean(false)

    @Volatile var texId = 0
        private set
    val texMatrix = FloatArray(16)
    @Volatile var positionMs = 0L
    @Volatile var durationMs = 0L
    @Volatile var isPlaying = false
    @Volatile var hasFrame = false
    @Volatile var hasMedia = false
    @Volatile var videoAspect = 16f / 9f
    @Volatile var volume = 0.8f
    @Volatile var error: String? = null
    /** 0 = 2D, 1 = lado a lado (SBS), 2 = cima/baixo (TB). Cada olho vê a sua metade. */
    @Volatile var stereo = 0
        private set
    fun cycleStereo() { stereo = (stereo + 1) % 3 }
    val stereoLabel get() = when (stereo) { 1 -> "3D: SBS"; 2 -> "3D: TB"; else -> "3D: Off" }

    private val ticker = object : Runnable {
        override fun run() {
            player?.let {
                positionMs = it.currentPosition
                durationMs = if (it.duration > 0) it.duration else 0L
                isPlaying = it.isPlaying
            }
            main.postDelayed(this, 250)
        }
    }

    init { main.post(ticker) }

    /** Chamar na thread GL quando o contexto é (re)criado. */
    fun attachGl() {
        st?.release(); surface?.release()
        texId = GlUtil.newTexture(oes = true)
        val s = SurfaceTexture(texId)
        s.setOnFrameAvailableListener { frameAvailable.set(true) }
        st = s
        val sf = Surface(s)
        surface = sf
        hasFrame = false
        main.post { player?.setVideoSurface(sf) }
    }

    /** Thread GL, uma vez por quadro. */
    fun updateTexture() {
        if (frameAvailable.getAndSet(false)) {
            try {
                st?.updateTexImage()
                st?.getTransformMatrix(texMatrix)
                hasFrame = true
            } catch (_: Exception) { }
        }
    }

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(ctx).build()
        p.volume = volume
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) {
                if (v.height > 0) videoAspect = v.width * v.pixelWidthHeightRatio / v.height
            }
            override fun onPlayerError(e: PlaybackException) {
                error = "Não foi possível reproduzir: ${e.errorCodeName}"
                hasMedia = false
            }
        })
        surface?.let { p.setVideoSurface(it) }
        player = p
        return p
    }

    fun load(uri: Uri) = main.post {
        val p = ensurePlayer()
        error = null
        hasFrame = false
        p.setMediaItem(MediaItem.fromUri(uri))
        p.prepare()
        p.playWhenReady = true
        hasMedia = true
    }

    fun togglePlay() = main.post { player?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun seekBy(ms: Long) = main.post {
        player?.let { it.seekTo((it.currentPosition + ms).coerceIn(0L, it.duration.coerceAtLeast(0L))) }
    }
    fun seekFraction(f: Float) = main.post {
        player?.let { if (it.duration > 0) it.seekTo((it.duration * f.coerceIn(0f, 1f)).toLong()) }
    }
    fun changeVolume(delta: Float) {
        volume = (volume + delta).coerceIn(0f, 1f)
        main.post { player?.volume = volume }
    }
    fun pause() = main.post { player?.pause() }

    fun release() {
        main.removeCallbacks(ticker)
        main.post {
            player?.release(); player = null
            surface?.release(); st?.release()
        }
    }
}
