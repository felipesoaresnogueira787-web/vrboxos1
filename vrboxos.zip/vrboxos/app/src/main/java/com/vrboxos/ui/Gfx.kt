package com.vrboxos.ui

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface

/** Desenho 2D (vidro escuro, bordas luminosas, texto legível) usado nas texturas dos painéis. */
object Gfx {
    val TEXT = 0xFFF2F6FF.toInt()
    val DIM = 0xFF9AA7C7.toInt()
    val ACCENT = 0xFF4FD1FF.toInt()
    val OK = 0xFF55E08A.toInt()
    val WARN = 0xFFFFC44D.toInt()
    val BAD = 0xFFFF6B6B.toInt()
    val GLASS = 0xD0101626.toInt()
    val BTN = 0x80223055.toInt()
    val BTN_HOVER = 0xE61E2D55.toInt()
    val DISABLED = 0x66FFFFFF

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    private val tpBold = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }

    fun rrect(c: Canvas, r: RectF, rad: Float, color: Int, strokeColor: Int = 0, sw: Float = 2f) {
        fill.shader = null
        fill.color = color
        c.drawRoundRect(r, rad, rad, fill)
        if (strokeColor != 0) {
            stroke.shader = null
            stroke.color = strokeColor
            stroke.strokeWidth = sw
            c.drawRoundRect(r, rad, rad, stroke)
        }
    }

    /** Fundo de vidro com borda em degradê. */
    fun glass(c: Canvas, w: Int, h: Int) {
        val r = RectF(6f, 6f, w - 6f, h - 6f)
        val rad = minOf(36f, h / 2f)
        fill.shader = null
        fill.color = GLASS
        c.drawRoundRect(r, rad, rad, fill)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 3f
        stroke.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xAA4FD1FF.toInt(), 0x226A7BFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, stroke)
        stroke.shader = null
    }

    fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = TEXT,
             align: Paint.Align = Paint.Align.LEFT, bold: Boolean = false) {
        val p = if (bold) tpBold else tp
        p.textSize = size
        p.color = color
        p.textAlign = align
        c.drawText(s, x, y, p)
    }

    fun measure(s: String, size: Float): Float { tp.textSize = size; return tp.measureText(s) }

    /** Parágrafo com quebra de linha; retorna o y final. */
    fun paragraph(c: Canvas, s: String, x: Float, y: Float, maxW: Float, size: Float, color: Int = TEXT, gap: Float = 1.35f): Float {
        var yy = y
        tp.textSize = size
        for (para in s.split("\n")) {
            var line = ""
            for (word in para.split(" ")) {
                val t = if (line.isEmpty()) word else "$line $word"
                if (tp.measureText(t) > maxW && line.isNotEmpty()) {
                    text(c, line, x, yy, size, color); yy += size * gap; line = word
                } else line = t
            }
            text(c, line, x, yy, size, color); yy += size * gap
        }
        return yy
    }

    fun circle(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        fill.shader = null; fill.color = color; c.drawCircle(cx, cy, r, fill)
    }

    fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float) {
        stroke.shader = null; stroke.color = color; stroke.strokeWidth = w; c.drawLine(x1, y1, x2, y2, stroke)
    }
}
