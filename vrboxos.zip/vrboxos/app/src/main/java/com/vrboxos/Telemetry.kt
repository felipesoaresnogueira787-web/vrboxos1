package com.vrboxos

/** Métricas compartilhadas entre threads (somente leitura na UI). */
object Telemetry {
    @Volatile var renderFps = 0f
    @Volatile var handFps = 0f
    @Volatile var handLatencyMs = 0f
    @Volatile var handStatus = "Desligado"
    @Volatile var sourceName = "-"
    @Volatile var sourcesText = "?"
    @Volatile var headStatus = "Iniciando"
    @Volatile var headRateHz = 0f
    @Volatile var batteryPct = -1
    @Volatile var batteryTempC = Float.NaN
    @Volatile var charging = false
    @Volatile var net = "?"
    @Volatile var thermal = 0
    @Volatile var thermalThrottle = false
    @Volatile var inputMethod = "Olhar"
}
