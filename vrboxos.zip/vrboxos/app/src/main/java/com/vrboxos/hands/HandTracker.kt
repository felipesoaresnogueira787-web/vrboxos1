package com.vrboxos.hands

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.vrboxos.Telemetry
import java.util.concurrent.atomic.AtomicReference

/**
 * Executa o MediaPipe Hand Landmarker (21 pontos por mão, até 2 mãos) e alimenta o GestureEngine.
 * Decisão: usamos Hand Landmarker + classificador geométrico próprio (GestureEngine), porque o
 * Gesture Recognizer pronto não oferece pinça nem "agarrar" e não expõe histerese/limiares.
 */
class HandTracker(private val context: Context, private val engine: GestureEngine) {
    val snapshot = AtomicReference<HandSnapshot?>(null)
    @Volatile var error: String? = null
        private set
    @Volatile var wantThumbnail = false
    @Volatile var thumbnail: Bitmap? = null
        private set

    private val lock = Any()
    private var landmarker: HandLandmarker? = null
    private var lastTs = 0L
    private var frames = 0
    private var fpsStart = 0L
    private var latencyEma = 0f

    /** Carrega o modelo (assets/hand_landmarker.task). Retorna false e preenche [error] se falhar. */
    fun init(): Boolean = synchronized(lock) {
        if (landmarker != null) return true
        try {
            val base = BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build()
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = HandLandmarker.createFromOptions(context, opts)
            error = null
            true
        } catch (e: Exception) {
            error = "Modelo não carregou ($MODEL_ASSET): ${e.message}"
            false
        }
    }

    /** Chamado na thread de análise com um bitmap vertical. */
    fun onFrame(bitmap: Bitmap, nowMs: Long, mirrorHands: Boolean) {
        synchronized(lock) {
            val l = landmarker ?: return
            val t0 = SystemClock.elapsedRealtime()
            val ts = if (nowMs <= lastTs) lastTs + 1 else nowMs
            lastTs = ts
            val raw = ArrayList<RawHand>(2)
            try {
                val res = l.detectForVideo(BitmapImageBuilder(bitmap).build(), ts)
                val lms = res.landmarks()
                val hands = res.handedness()
                for (i in lms.indices) {
                    val a = FloatArray(63)
                    for (k in 0 until 21) {
                        val p = lms[i][k]
                        a[k * 3] = p.x(); a[k * 3 + 1] = p.y(); a[k * 3 + 2] = p.z()
                    }
                    val cat = hands.getOrNull(i)?.firstOrNull()
                    raw.add(RawHand(a, cat?.categoryName() ?: "?", cat?.score() ?: 0.5f))
                }
            } catch (e: Exception) {
                error = "Inferência falhou: ${e.message}"
                Telemetry.handStatus = "Erro: ${e.message}"
                return
            }
            val lat = (SystemClock.elapsedRealtime() - t0).toFloat()
            latencyEma = if (latencyEma == 0f) lat else latencyEma * 0.9f + lat * 0.1f
            val aspect = bitmap.width.toFloat() / bitmap.height.toFloat()
            snapshot.set(engine.process(ts, raw, aspect, mirrorHands, latencyEma))
            Telemetry.handLatencyMs = latencyEma
            Telemetry.handStatus = "Rodando"

            frames++
            if (fpsStart == 0L) fpsStart = ts
            if (ts - fpsStart >= 1000) {
                Telemetry.handFps = frames * 1000f / (ts - fpsStart)
                frames = 0; fpsStart = ts
            }
            if (wantThumbnail && frames % 3 == 0) {
                thumbnail = Bitmap.createScaledBitmap(bitmap, 160, (160f / aspect).toInt().coerceAtLeast(1), true)
            }
        }
    }

    /** Sem fonte de vídeo ativa: o motor precisa saber para expirar as mãos. */
    fun tickNoFrame(nowMs: Long) {
        synchronized(lock) {
            val s = engine.process(nowMs, emptyList(), snapshot.get()?.imageAspect ?: 1.33f, false, 0f)
            snapshot.set(s)
        }
    }

    /** Zera gestos e snapshot (a engine só pode ser tocada sob o mesmo lock da inferência). */
    fun reset() = synchronized(lock) {
        engine.reset()
        snapshot.set(null)
    }

    fun close() = synchronized(lock) {
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        snapshot.set(null)
    }

    companion object { const val MODEL_ASSET = "hand_landmarker.task" }
}
