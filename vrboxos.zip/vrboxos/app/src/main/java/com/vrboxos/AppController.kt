package com.vrboxos

/** Ações que a interface espacial pede ao Activity. */
interface AppController {
    fun pickVideo()
    fun setHandTracking(enable: Boolean)
    fun restartHandSource()
    fun setVrMode(vr: Boolean)
    fun isVrMode(): Boolean
    fun recenter()
    fun exitApp()
}
