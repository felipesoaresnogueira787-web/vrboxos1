package com.vrboxos.hands

import android.graphics.Bitmap

/**
 * Abstração da fonte de vídeo para o hand tracking. Para suportar outra câmera
 * (ex.: UVC via biblioteca própria), basta implementar esta interface.
 */
interface VideoSource {
    val name: String
    /** true quando o bitmap entregue já está espelhado (como num espelho). */
    val mirrored: Boolean
    /** [onFrame] recebe bitmap já na vertical + timestamp (ms). Chamado fora da thread principal. */
    fun start(onFrame: (Bitmap, Long) -> Unit, onError: (String) -> Unit)
    fun stop()
}
