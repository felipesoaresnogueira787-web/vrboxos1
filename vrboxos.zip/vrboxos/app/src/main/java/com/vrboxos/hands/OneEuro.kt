package com.vrboxos.hands

import kotlin.math.abs
import kotlin.math.max

/** Filtro One Euro: remove tremor com pouca latência quando a mão se move rápido. */
class OneEuro(private val minCutoff: Float, private val beta: Float, private val dCutoff: Float = 1f) {
    private var xPrev = 0f
    private var dxPrev = 0f
    private var tPrev = -1L

    fun filter(x: Float, tMs: Long): Float {
        if (tPrev < 0) { tPrev = tMs; xPrev = x; dxPrev = 0f; return x }
        val dt = max((tMs - tPrev) / 1000f, 1e-3f)
        tPrev = tMs
        val dx = (x - xPrev) / dt
        val edx = lp(dx, dxPrev, alpha(dCutoff, dt))
        dxPrev = edx
        val cutoff = minCutoff + beta * abs(edx)
        val xf = lp(x, xPrev, alpha(cutoff, dt))
        xPrev = xf
        return xf
    }

    fun reset() { tPrev = -1L }

    private fun lp(x: Float, prev: Float, a: Float) = a * x + (1f - a) * prev
    private fun alpha(cutoff: Float, dt: Float): Float {
        val tau = 1f / (2f * Math.PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }
}
