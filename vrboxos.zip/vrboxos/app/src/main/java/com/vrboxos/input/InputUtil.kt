package com.vrboxos.input

/** Impede cliques repetidos: só libera um novo clique após [lockoutMs]. */
class ClickGuard(private val lockoutMs: Long) {
    private var last = Long.MIN_VALUE / 2
    fun allow(now: Long): Boolean {
        if (now - last < lockoutMs) return false
        last = now
        return true
    }
}

/** Seleção por permanência do olhar. Depois de disparar, exige sair do alvo para rearmar. */
class DwellTracker {
    data class Result(val progress: Float, val fired: Boolean)

    private var target: String? = null
    private var since = 0L
    private var armed = true

    fun update(t: String?, now: Long, dwellMs: Long): Result {
        if (t != target) { target = t; since = now; armed = true }
        if (t == null) return Result(0f, false)
        if (!armed) return Result(1f, false)
        val p = ((now - since).toFloat() / dwellMs).coerceIn(0f, 1f)
        if (p >= 1f) { armed = false; return Result(1f, true) }
        return Result(p, false)
    }

    fun reset() { target = null; armed = true }
}
