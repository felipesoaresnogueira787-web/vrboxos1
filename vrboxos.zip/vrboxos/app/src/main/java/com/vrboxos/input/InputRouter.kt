package com.vrboxos.input

import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import com.vrboxos.AppController
import com.vrboxos.Feedback
import com.vrboxos.Telemetry
import com.vrboxos.hands.GestureEvent
import com.vrboxos.hands.HandPipeline
import com.vrboxos.hands.HandState
import com.vrboxos.hands.HoldGesture
import com.vrboxos.hands.Pose
import com.vrboxos.head.Quat
import com.vrboxos.settings.GestureCommand
import com.vrboxos.settings.InputMode
import com.vrboxos.settings.Settings
import com.vrboxos.ui.Button
import com.vrboxos.ui.Hit
import com.vrboxos.ui.Panel
import com.vrboxos.ui.SpatialUi
import kotlin.math.sqrt
import kotlin.math.tan

/** Converte posição 2D da mão na imagem em direção no espaço da cabeça. */
object HandMapping {
    const val HFOV_DEG = 80.0   // campo horizontal da câmera assumido (estimativa, não calibrado)
    const val GAIN = 1.3f       // amplifica o alcance para não precisar chegar às bordas da imagem

    /** Escreve (dx, dy) em unidades de tangente (direção = (dx, dy, -1) normalizada). */
    fun headSpace(nx: Float, ny: Float, aspect: Float, out: FloatArray) {
        val span = 2f * tan(Math.toRadians(HFOV_DEG / 2)).toFloat() * GAIN
        out[0] = (nx - 0.5f) * span
        out[1] = -(ny - 0.5f) * span / aspect
    }
}

/**
 * Decide qual método de entrada está ativo (mãos > olhar > toque) e transforma gestos,
 * permanência do olhar e toques em ações sobre os painéis. Roda na thread GL.
 */
class InputRouter(
    private val ui: SpatialUi,
    private val settings: Settings,
    private val feedback: Feedback,
    private val pipeline: HandPipeline,
    private val controller: AppController
) {
    enum class Method(val label: String) { HAND("Mãos"), GAZE("Olhar"), TOUCH("Toque") }

    @Volatile var method = Method.GAZE
        private set
    var hasPointer = false
        private set
    val pointerWorld = FloatArray(3)
    var dwellProgress = 0f
        private set
    var pressed = false
        private set
    var clicks = 0; private set
    var swipes = 0; private set
    var pinches = 0; private set

    private val guard = ClickGuard(350)
    private val dwell = DwellTracker()
    private val dirHead = FloatArray(3)
    private val dirWorld = FloatArray(3)
    private val tmp2 = FloatArray(2)
    private val tmpWorld = FloatArray(3)

    private var pressHit: Hit? = null
    private var dragPanel: Panel? = null
    private var dragOff = FloatArray(2)
    private var scalePanel: Panel? = null
    private var scaleD0 = 0f
    private var scaleS0 = 1f
    private var lastNote = 0L
    private var lastHit: Hit? = null

    private var touchDown = false
    private var touchPress = false
    private var touchRelease = false
    private var touchX = 0f
    private var touchY = 0f

    /** Chamado na thread GL (via queueEvent). */
    fun touch(x: Float, y: Float, action: Int) {
        touchX = x; touchY = y
        when (action) {
            MotionEvent.ACTION_DOWN -> { touchDown = true; touchPress = true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { touchDown = false; touchRelease = true }
        }
    }

    /** Controle Bluetooth / teclas. Chamado na thread GL. */
    fun onKey(code: Int): Boolean = when (code) {
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
            val b = lastHit?.button
            if (b != null && b.enabled && guard.allow(SystemClock.elapsedRealtime())) activate(b)
            true
        }
        KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK -> { if (!ui.back()) ui.notify("Você já está no início"); true }
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_MENU -> { runCommand(GestureCommand.MENU); true }
        else -> false
    }

    fun update(now: Long, q: Quat, vr: Boolean, aspect: Float, sw: Int, sh: Int) {
        val snap = pipeline.tracker.snapshot.get()
        val fresh = snap != null && now - snap.timestampMs < 400
        val hands: List<HandState> =
            if (fresh && settings.handEnabled) snap!!.hands.filter { it.fade > 0.3f } else emptyList()
        val handAspect = snap?.imageAspect ?: 1.33f
        val handOk = hands.isNotEmpty()

        val newMethod = when {
            !vr -> if (handOk) Method.HAND else Method.TOUCH
            settings.inputMode == InputMode.GAZE -> Method.GAZE
            else -> if (handOk) Method.HAND else Method.GAZE
        }
        if (newMethod != method) {
            method = newMethod
            Telemetry.inputMethod = method.label
            cancelInteractions()
            if (now - lastNote > 2000) { lastNote = now; ui.notify("Entrada ativa: ${method.label}") }
        }

        // Eventos de gesto: sempre esvaziados (evita acúmulo), só agem no método Mãos.
        while (true) {
            val e = pipeline.engine.events.poll() ?: break
            when (e) {
                is GestureEvent.PinchStart -> pinches++
                is GestureEvent.Swipe -> swipes++
                else -> {}
            }
            if (method == Method.HAND) handleEvent(e, now, q, handAspect)
        }

        // Ponteiro
        hasPointer = false
        when (method) {
            Method.HAND -> {
                val h = hands.firstOrNull { it.pose == Pose.PINCH || it.pose == Pose.POINT }
                    ?: hands.maxByOrNull { it.fade }
                if (h != null) {
                    HandMapping.headSpace(h.cursorX, h.cursorY, handAspect, tmp2)
                    setDirHead(tmp2[0], tmp2[1]); hasPointer = true
                }
            }
            Method.GAZE -> { dirHead[0] = 0f; dirHead[1] = 0f; dirHead[2] = -1f; hasPointer = true }
            Method.TOUCH -> if (touchDown || touchRelease) {
                val ty = tan(Math.toRadians(settings.fovDeg / 2.0)).toFloat()
                setDirHead((touchX / sw * 2f - 1f) * ty * aspect, (1f - touchY / sh * 2f) * ty)
                hasPointer = true
            }
        }
        var hit: Hit? = null
        if (hasPointer) {
            q.rotate(dirHead, dirWorld)
            hit = ui.hitTest(dirWorld, pointerWorld)
        }
        lastHit = hit ?: lastHit.takeIf { method == Method.GAZE }
        ui.setHover(hit)

        // Olhar: seleção por permanência
        if (method == Method.GAZE) {
            val b = hit?.button?.takeIf { it.enabled }
            val key = if (b != null && hit != null) "${hit.panel.id}:${b.id}" else null
            val r = dwell.update(key, now, (settings.dwellSec * 1000).toLong())
            dwellProgress = r.progress
            if (r.fired && b != null && guard.allow(now)) activate(b)
        } else {
            dwell.reset(); dwellProgress = 0f
        }

        // Toque (modo plano)
        if (method == Method.TOUCH) {
            if (touchPress) { touchPress = false; pressAt(hit, now) }
            if (touchRelease) { touchRelease = false; releaseAt(hit, now) }
        } else { touchPress = false; touchRelease = false }

        // Arrasto e barras (mãos/toque)
        if (method != Method.GAZE && hasPointer) {
            dragPanel?.let { ui.dragTo(it, dirWorld, dragOff) }
            val ph = pressHit
            val b = ph?.button
            if (pressed && b?.onScrub != null && hit != null && hit.button?.id == b.id) scrub(b, hit)
        }

        // Duas mãos agarrando: redimensiona o painel em foco
        if (method == Method.HAND && snap != null && hands.size == 2 && snap.twoHandDistance > 0f &&
            hands.all { it.pinching || it.pose == Pose.FIST }
        ) {
            val target = scalePanel ?: dragPanel ?: hit?.panel ?: ui.focusPanel()
            if (scalePanel == null) { scalePanel = target; scaleD0 = snap.twoHandDistance; scaleS0 = target.userScale }
            else scalePanel?.userScale = (scaleS0 * snap.twoHandDistance / scaleD0).coerceIn(0.5f, 2.5f)
        } else scalePanel = null
    }

    private fun setDirHead(dx: Float, dy: Float) {
        val n = sqrt(dx * dx + dy * dy + 1f)
        dirHead[0] = dx / n; dirHead[1] = dy / n; dirHead[2] = -1f / n
    }

    private fun rayFromCursor(x: Float, y: Float, aspect: Float, q: Quat) {
        HandMapping.headSpace(x, y, aspect, tmp2)
        setDirHead(tmp2[0], tmp2[1])
        q.rotate(dirHead, dirWorld)
    }

    private fun handleEvent(e: GestureEvent, now: Long, q: Quat, aspect: Float) {
        when (e) {
            is GestureEvent.PinchStart -> {
                rayFromCursor(e.x, e.y, aspect, q)
                pressAt(ui.hitTest(dirWorld, tmpWorld), now)
            }
            is GestureEvent.PinchEnd -> releaseAt(lastHit.takeIf { hasPointer } ?: ui.hitTest(dirWorld, tmpWorld), now)
            is GestureEvent.GrabStart -> {
                rayFromCursor(e.x, e.y, aspect, q)
                val h = ui.hitTest(dirWorld, tmpWorld)
                if (h != null) { dragPanel = h.panel; dragOff = ui.beginDrag(h.panel, dirWorld); pressed = true; feedback.tick() }
            }
            is GestureEvent.GrabEnd -> { dragPanel = null; pressed = false }
            is GestureEvent.Swipe -> ui.onSwipe(e.dirX)
            is GestureEvent.Hold -> if (dragPanel == null && !pressed) {
                runCommand(if (e.gesture == HoldGesture.FIST) settings.fistCommand else settings.openCommand)
            }
            is GestureEvent.HandLost -> cancelInteractions()
            is GestureEvent.HandFound -> {}
        }
    }

    private fun pressAt(h: Hit?, now: Long) {
        pressHit = h
        pressed = h != null
        if (h == null) return
        val b = h.button
        if (b?.onScrub != null) scrub(b, h)
        else if (b == null && h.panel.headerPx > 0f && h.py <= h.panel.headerPx) {
            dragPanel = h.panel
            dragOff = ui.beginDrag(h.panel, dirWorld)
        }
        feedback.tick()
    }

    private fun releaseAt(h: Hit?, now: Long) {
        val ph = pressHit
        pressHit = null
        pressed = false
        if (dragPanel != null) { dragPanel = null; return }
        if (ph == null) return
        val pb = ph.button ?: return
        if (pb.onScrub == null && pb.enabled && h != null && h.button?.id == pb.id &&
            h.panel === ph.panel && guard.allow(now)
        ) {
            activate(pb)
        }
    }

    private fun scrub(b: Button, h: Hit) {
        val u = ((h.px - b.rect.left) / b.rect.width()).coerceIn(0f, 1f)
        b.onScrub?.invoke(u)
    }

    private fun activate(b: Button) {
        feedback.click()
        clicks++
        b.onClick()
    }

    private fun runCommand(c: GestureCommand) {
        when (c) {
            GestureCommand.MENU -> { ui.goHome(); controller.recenter() }
            GestureCommand.BACK -> if (!ui.back()) ui.notify("Você já está no início")
            GestureCommand.NONE -> return
        }
        feedback.click()
    }

    private fun cancelInteractions() {
        pressHit = null; dragPanel = null; scalePanel = null; pressed = false; dwell.reset(); dwellProgress = 0f
    }
}
