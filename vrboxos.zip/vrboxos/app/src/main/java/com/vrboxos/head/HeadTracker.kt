package com.vrboxos.head

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import com.vrboxos.Telemetry
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt

/** Lê o vetor de rotação do aparelho (giroscópio fundido) e alimenta o HeadPose. */
class HeadTracker(
    ctx: Context,
    private val pose: HeadPose,
    private val displayRotation: () -> Int
) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var thread: HandlerThread? = null
    private var smoothed: Quat? = null
    private var lastNs = 0L
    private var countStart = 0L
    private var count = 0

    @Volatile var available = false
        private set

    fun start(): Boolean {
        stop()
        val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s == null) {
            available = false
            Telemetry.headStatus = "Sem sensor de rotação: rastreio da cabeça indisponível"
            return false
        }
        val t = HandlerThread("vrboxos-head").also { it.start() }
        thread = t
        // 5000 µs = 200 Hz (acima disso o Android 12+ exige permissão especial).
        val ok = sm.registerListener(this, s, 5000, Handler(t.looper))
        available = ok
        Telemetry.headStatus = if (ok) "OK (${s.name})" else "Falha ao registrar o sensor"
        return ok
    }

    fun stop() {
        sm.unregisterListener(this)
        thread?.quitSafely()
        thread = null
        smoothed = null
        lastNs = 0L
    }

    override fun onSensorChanged(e: SensorEvent) {
        val v = e.values
        val x = v[0]; val y = v[1]; val z = v[2]
        val w = if (v.size > 3) v[3] else sqrt(max(0f, 1f - x * x - y * y - z * z))
        val qh = HeadMath.sensorToHead(Quat(w, x, y, z).normalized(), displayRotation())
        val prev = smoothed
        val dtMs = if (lastNs == 0L) 0f else (e.timestamp - lastNs) / 1_000_000f
        lastNs = e.timestamp
        val tau = pose.smoothingTauMs
        val q = if (prev == null || tau <= 0f || dtMs <= 0f) qh
        else Quat.nlerp(prev, qh, 1f - exp(-dtMs / tau))
        smoothed = q
        pose.raw = q

        count++
        val now = e.timestamp
        if (countStart == 0L) countStart = now
        if (now - countStart >= 1_000_000_000L) {
            Telemetry.headRateHz = count * 1e9f / (now - countStart)
            count = 0; countStart = now
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
