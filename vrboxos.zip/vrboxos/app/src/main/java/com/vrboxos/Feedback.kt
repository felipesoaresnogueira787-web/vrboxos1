package com.vrboxos

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import com.vrboxos.settings.Settings

/** Feedback sonoro e tátil curto para cliques. */
class Feedback(ctx: Context, private val settings: Settings) {
    private val tone: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_SYSTEM, 50) } catch (_: Exception) { null }
    private val vib: Vibrator? = ctx.getSystemService(Vibrator::class.java)

    fun click() {
        if (settings.soundOn) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
        vibrate(15)
    }

    fun tick() { vibrate(8) }

    private fun vibrate(ms: Long) {
        try { vib?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
    }

    fun release() { tone?.release() }
}
