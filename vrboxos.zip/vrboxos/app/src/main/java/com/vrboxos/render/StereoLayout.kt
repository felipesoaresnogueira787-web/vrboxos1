package com.vrboxos.render

/** Geometria estereoscópica lado a lado (esquerdo = 0, direito = 1). */
object StereoLayout {
    /** Retorna [x, y, largura, altura] do olho. */
    fun eyeViewport(totalW: Int, totalH: Int, eye: Int): IntArray {
        val half = totalW / 2
        return intArrayOf(if (eye == 0) 0 else half, 0, half, totalH)
    }

    /**
     * Deslocamento lateral aplicado ao mundo para cada olho, em metros.
     * Olho esquerdo fica em -IPD/2, então o mundo desloca +IPD/2 (e o inverso no direito).
     */
    fun eyeShiftMeters(ipdMm: Float, eye: Int): Float = (if (eye == 0) 1f else -1f) * ipdMm / 2000f
}
