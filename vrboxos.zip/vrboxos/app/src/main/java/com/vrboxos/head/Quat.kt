package com.vrboxos.head

import kotlin.math.*

/** Quaternion (w,x,y,z). Matemática pura: testável na JVM. */
data class Quat(val w: Float, val x: Float, val y: Float, val z: Float) {
    operator fun times(o: Quat) = Quat(
        w * o.w - x * o.x - y * o.y - z * o.z,
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w
    )

    fun conjugate() = Quat(w, -x, -y, -z)
    fun dot(o: Quat) = w * o.w + x * o.x + y * o.y + z * o.z
    fun normalized(): Quat {
        val n = sqrt(w * w + x * x + y * y + z * z)
        return if (n < 1e-6f) IDENTITY else Quat(w / n, x / n, y / n, z / n)
    }

    /** Gira o vetor v (3 floats). */
    fun rotate(v: FloatArray, out: FloatArray = FloatArray(3)): FloatArray {
        val tx = 2f * (y * v[2] - z * v[1])
        val ty = 2f * (z * v[0] - x * v[2])
        val tz = 2f * (x * v[1] - y * v[0])
        out[0] = v[0] + w * tx + (y * tz - z * ty)
        out[1] = v[1] + w * ty + (z * tx - x * tz)
        out[2] = v[2] + w * tz + (x * ty - y * tx)
        return out
    }

    /** Escreve matriz 4x4 de rotação em ordem de colunas (padrão OpenGL). */
    fun toMatrix(m: FloatArray) {
        val q = normalized()
        val xx = q.x * q.x; val yy = q.y * q.y; val zz = q.z * q.z
        val xy = q.x * q.y; val xz = q.x * q.z; val yz = q.y * q.z
        val wx = q.w * q.x; val wy = q.w * q.y; val wz = q.w * q.z
        m[0] = 1f - 2f * (yy + zz); m[1] = 2f * (xy + wz); m[2] = 2f * (xz - wy); m[3] = 0f
        m[4] = 2f * (xy - wz); m[5] = 1f - 2f * (xx + zz); m[6] = 2f * (yz + wx); m[7] = 0f
        m[8] = 2f * (xz + wy); m[9] = 2f * (yz - wx); m[10] = 1f - 2f * (xx + yy); m[11] = 0f
        m[12] = 0f; m[13] = 0f; m[14] = 0f; m[15] = 1f
    }

    /** Multiplica o ângulo da rotação por s (s=1 não altera). */
    fun scaleAngle(s: Float): Quat {
        val q = if (w < 0f) Quat(-w, -x, -y, -z) else this
        val sinHalf = sqrt(q.x * q.x + q.y * q.y + q.z * q.z)
        if (sinHalf < 1e-6f) return IDENTITY
        val angle = 2f * atan2(sinHalf, q.w) * s
        val k = sin(angle / 2f) / sinHalf
        return Quat(cos(angle / 2f), q.x * k, q.y * k, q.z * k)
    }

    companion object {
        val IDENTITY = Quat(1f, 0f, 0f, 0f)
        fun fromAxisAngle(ax: Float, ay: Float, az: Float, rad: Float): Quat {
            val h = rad / 2f
            val s = sin(h)
            return Quat(cos(h), ax * s, ay * s, az * s)
        }

        fun nlerp(a: Quat, b: Quat, t: Float): Quat {
            val bb = if (a.dot(b) < 0f) Quat(-b.w, -b.x, -b.y, -b.z) else b
            return Quat(
                a.w + (bb.w - a.w) * t, a.x + (bb.x - a.x) * t,
                a.y + (bb.y - a.y) * t, a.z + (bb.z - a.z) * t
            ).normalized()
        }
    }
}

/** Conversões do referencial do sensor (ENU) para o mundo GL (X=Leste, Y=cima, -Z=Norte). */
object HeadMath {
    private val ENU_TO_GL = Quat.fromAxisAngle(1f, 0f, 0f, (-PI / 2).toFloat())

    /** displayRotation: constantes Surface.ROTATION_* (0..3). */
    fun remap(displayRotation: Int): Quat = when (displayRotation) {
        1 -> Quat.fromAxisAngle(0f, 0f, 1f, (PI / 2).toFloat())
        2 -> Quat.fromAxisAngle(0f, 0f, 1f, PI.toFloat())
        3 -> Quat.fromAxisAngle(0f, 0f, 1f, (-PI / 2).toFloat())
        else -> Quat.IDENTITY
    }

    fun sensorToHead(qSensor: Quat, displayRotation: Int): Quat =
        (ENU_TO_GL * qSensor * remap(displayRotation)).normalized()
}

/** Orientação da cabeça: apenas rotação (3DoF). Não há posição medida. */
class HeadPose {
    @Volatile var raw: Quat = Quat.IDENTITY
    @Volatile var yawFix: Quat = Quat.IDENTITY
    @Volatile var sensitivity: Float = 1f
    @Volatile var enabled: Boolean = true
    /** Constante de tempo da suavização do sensor em ms (0 = sem suavização). */
    @Volatile var smoothingTauMs: Float = 20f

    fun orientation(): Quat {
        if (!enabled) return Quat.IDENTITY
        return (yawFix * raw).normalized().scaleAngle(sensitivity)
    }

    /** Faz a direção atual do olhar virar "frente" (-Z), mantendo o horizonte. */
    fun recenter() {
        val f = raw.rotate(floatArrayOf(0f, 0f, -1f))
        if (abs(f[0]) < 1e-4f && abs(f[2]) < 1e-4f) return
        val yaw0 = atan2(f[0], -f[2])
        yawFix = Quat.fromAxisAngle(0f, 1f, 0f, yaw0)
    }
}
