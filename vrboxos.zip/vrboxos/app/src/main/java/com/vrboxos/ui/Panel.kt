package com.vrboxos.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.RectF

/** Botão clicável de um painel. Coordenadas em pixels da textura do painel. */
class Button(
    val id: String,
    val rect: RectF,
    val enabled: Boolean,
    /** Se não nulo, o botão é uma barra: recebe a posição relativa (0..1) ao pressionar/arrastar. */
    val onScrub: ((Float) -> Unit)?,
    val onClick: () -> Unit
)

/**
 * Janela virtual plana. (ax, ay) é a posição em metros no plano de referência z=-2 m; a posição
 * real é escalada pela distância configurada para manter o mesmo tamanho angular.
 */
class Panel(
    val id: String,
    val baseX: Float, val baseY: Float,
    val baseW: Float, val baseH: Float,
    val texW: Int, val texH: Int,
    /** Altura (px) da faixa superior que arrasta o painel ao ser "agarrada". 0 = sem faixa. */
    val headerPx: Float = 0f
) {
    var ax = baseX
    var ay = baseY
    var userScale = 1f
    var visible = false
    var alpha = 0f
    var dirty = true
    var tex = 0
    var isVideo = false
    val buttons = ArrayList<Button>()
    var drawFn: (Canvas, Panel) -> Unit = { _, _ -> }
    val bitmap: Bitmap = Bitmap.createBitmap(texW, texH, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    fun resetPlacement() { ax = baseX; ay = baseY; userScale = 1f }
}

class Hit(
    val panel: Panel,
    val px: Float, val py: Float,
    val u: Float, val v: Float,
    val button: Button?
)
