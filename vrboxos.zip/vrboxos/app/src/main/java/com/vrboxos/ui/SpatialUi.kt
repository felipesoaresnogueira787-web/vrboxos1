package com.vrboxos.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import com.vrboxos.AppController
import com.vrboxos.Telemetry
import com.vrboxos.hands.HandPipeline
import com.vrboxos.hands.HandTopology
import com.vrboxos.head.HeadPose
import com.vrboxos.input.InputRouter
import com.vrboxos.media.CinemaPlayer
import com.vrboxos.render.EnvMesh
import com.vrboxos.render.Environments
import com.vrboxos.render.GlUtil
import com.vrboxos.settings.Settings
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.exp
import kotlin.math.min

enum class Screen { HOME, CINEMA, SETTINGS, DIAG, TUTORIAL, ENV }

/** Interface espacial: painéis, telas, hit-test e estado de navegação. Roda na thread GL. */
class SpatialUi(
    private val ctx: Context,
    private val settings: Settings,
    private val head: HeadPose,
    private val controller: AppController,
    private val pipeline: HandPipeline,
    private val cinema: CinemaPlayer
) {
    var router: InputRouter? = null

    var screen = Screen.HOME
        private set
    var flatTheater = false
        private set

    private val status = Panel("status", 0f, 0.82f, 1.1f, 0.09f, 1100, 90)
    private val main = Panel("main", 0f, 0.10f, 2.0f, 1.125f, 1280, 720, headerPx = 80f)
    private val dock = Panel("dock", 0f, -0.78f, 1.3f, 0.177f, 1100, 150)
    private val video = Panel("video", 0f, 0.25f, 3.2f, 1.8f, 1280, 720).also { it.isVideo = true }
    private val controls = Panel("controls", 0f, -0.95f, 2.2f, 0.367f, 1200, 200)
    private val all = listOf(video, main, controls, dock, status)          // ordem de desenho
    private val hitOrder = listOf(status, dock, controls, main, video)     // da frente para trás

    private var hoverPanel: Panel? = null
    private var hoverButton: String? = null
    private val notes = ArrayDeque<Pair<String, String>>()
    private val pending = ConcurrentLinkedQueue<String>()
    private val envCache = arrayOfNulls<EnvMesh>(3)
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEE, d MMM", Locale("pt", "BR"))

    private var lastUpdate = 0L
    private var lastSecond = 0L
    private var lastFast = 0L
    private var settingsPage = 0
    private var tutorialPage = 0
    private var confirmResetUntil = 0L

    private class Tile(val id: String, val title: String, val sub: String, val available: Boolean, val action: () -> Unit)
    private class Row(val label: String, val value: () -> String, val dec: () -> Unit, val inc: () -> Unit)

    private val tiles = listOf(
        Tile("cinema", "Cinema VR", "Vídeos locais", true) { goTo(Screen.CINEMA) },
        Tile("env", "Ambientes", "3 ambientes 3D", true) { goTo(Screen.ENV) },
        Tile("settings", "Configurações", "Ajustes do sistema", true) { goTo(Screen.SETTINGS) },
        Tile("diag", "Diagnóstico", "Sensores e mãos", true) { goTo(Screen.DIAG) },
        Tile("tutorial", "Tutorial", "Gestos e navegação", true) { goTo(Screen.TUTORIAL) },
        Tile("browser", "Navegador", "Não implementado", false) {},
        Tile("gallery", "Galeria / 360°", "Não implementado", false) {},
        Tile("stereo", "Imagens estéreo", "Não implementado", false) {}
    )

    private inline fun <reified T : Enum<T>> cyc(v: T, d: Int): T {
        val a = enumValues<T>()
        return a[(v.ordinal + d + a.size) % a.size]
    }

    private fun setEnv(n: Int) { settings.environment = (n + 3) % 3; main.dirty = true }

    private val rows: List<Row> = listOf(
        Row("Ambiente", { Environments.NAMES[settings.environment] }, { setEnv(settings.environment - 1) }, { setEnv(settings.environment + 1) }),
        Row("IPD visual (calibração)", { "%.0f mm".format(settings.ipdMm) }, { settings.ipdMm -= 1f }, { settings.ipdMm += 1f }),
        Row("Campo de visão", { "%.0f°".format(settings.fovDeg) }, { settings.fovDeg -= 2f }, { settings.fovDeg += 2f }),
        Row("Distância dos painéis", { "%.2f m".format(settings.panelDistance) }, { settings.panelDistance -= 0.25f }, { settings.panelDistance += 0.25f }),
        Row("Escala dos painéis", { "%.1fx".format(settings.panelScale) }, { settings.panelScale -= 0.1f }, { settings.panelScale += 0.1f }),
        Row("Distorção da lente (k1)", { "%.2f".format(settings.lensK1) }, { settings.lensK1 -= 0.05f }, { settings.lensK1 += 0.05f }),

        Row("Rastreio da cabeça", { if (settings.headTracking) "Ligado" else "Desligado" },
            { settings.headTracking = !settings.headTracking }, { settings.headTracking = !settings.headTracking }),
        Row("Sensibilidade da cabeça", { "%.1fx".format(settings.headSensitivity) }, { settings.headSensitivity -= 0.1f }, { settings.headSensitivity += 0.1f }),
        Row("Suavização da cabeça", { "%.0f ms".format(settings.headSmoothing * 100f) }, { settings.headSmoothing -= 0.1f }, { settings.headSmoothing += 0.1f }),
        Row("Método de entrada", { settings.inputMode.label }, { settings.inputMode = cyc(settings.inputMode, -1) }, { settings.inputMode = cyc(settings.inputMode, 1) }),
        Row("Tempo de seleção (olhar)", { "%.2f s".format(settings.dwellSec) }, { settings.dwellSec -= 0.25f }, { settings.dwellSec += 0.25f }),
        Row("Ponteiro visível", { if (settings.pointer) "Sim" else "Não" }, { settings.pointer = !settings.pointer }, { settings.pointer = !settings.pointer }),

        Row("Hand tracking", { if (settings.handEnabled) "Ligado" else "Desligado" },
            { controller.setHandTracking(!settings.handEnabled) }, { controller.setHandTracking(!settings.handEnabled) }),
        Row("Fonte de câmera", { settings.camera.label },
            { settings.camera = cyc(settings.camera, -1); if (settings.handEnabled) controller.restartHandSource() },
            { settings.camera = cyc(settings.camera, 1); if (settings.handEnabled) controller.restartHandSource() }),
        Row("Sensibilidade dos gestos", { "%.1fx".format(settings.gestureSens) }, { settings.gestureSens -= 0.1f }, { settings.gestureSens += 0.1f }),
        Row("Punho segurado (1 s)", { settings.fistCommand.label }, { settings.fistCommand = cyc(settings.fistCommand, -1) }, { settings.fistCommand = cyc(settings.fistCommand, 1) }),
        Row("Palma segurada (1,2 s)", { settings.openCommand.label }, { settings.openCommand = cyc(settings.openCommand, -1) }, { settings.openCommand = cyc(settings.openCommand, 1) }),
        Row("Taxa máx. do rastreio", { "${settings.handFpsCap} fps" }, { settings.handFpsCap -= 5 }, { settings.handFpsCap += 5 }),

        Row("Espelhar mãos", { if (settings.mirrorHands) "Sim" else "Não" }, { settings.mirrorHands = !settings.mirrorHands }, { settings.mirrorHands = !settings.mirrorHands }),
        Row("Qualidade gráfica", { settings.quality.label }, { settings.quality = cyc(settings.quality, -1) }, { settings.quality = cyc(settings.quality, 1) }),
        Row("Vinheta de conforto", { if (settings.vignette) "Ligada" else "Desligada" }, { settings.vignette = !settings.vignette }, { settings.vignette = !settings.vignette }),
        Row("Sons de clique", { if (settings.soundOn) "Ligados" else "Desligados" }, { settings.soundOn = !settings.soundOn }, { settings.soundOn = !settings.soundOn })
    )
    private val rowsPerPage = 6
    private val pageCount get() = (rows.size + rowsPerPage - 1) / rowsPerPage

    init {
        status.drawFn = ::drawStatus
        dock.drawFn = ::drawDock
        controls.drawFn = ::drawControls
        video.drawFn = ::drawVideoPlaceholder
        main.drawFn = { c, p ->
            when (screen) {
                Screen.HOME -> drawHome(c, p)
                Screen.SETTINGS -> drawSettings(c, p)
                Screen.DIAG -> drawDiag(c, p)
                Screen.TUTORIAL -> drawTutorial(c, p)
                Screen.ENV -> drawEnv(c, p)
                Screen.CINEMA -> {}
            }
        }
        screen = Screen.HOME
        applyVisibility()
        notify("VR BOX OS iniciado")
    }

    // ------------------------------------------------------------ API

    fun notify(msg: String) { pending.add(msg) }
    fun environment(): EnvMesh = envCache[settings.environment] ?: Environments.build(settings.environment).also { envCache[settings.environment] = it }
    fun drawOrder(): List<Panel> = all
    fun focusPanel(): Panel = if (screen == Screen.CINEMA) video else main

    fun goHome() = goTo(Screen.HOME)
    fun back(): Boolean {
        if (screen == Screen.HOME) return false
        if (screen == Screen.CINEMA) cinema.pause()
        goTo(Screen.HOME)
        return true
    }

    private fun goTo(s: Screen) {
        screen = s
        applyVisibility()
        main.alpha = 0.3f   // transição suave (fade-in)
        main.dirty = true
        controls.dirty = true
    }

    private fun applyVisibility() {
        val cin = screen == Screen.CINEMA
        video.visible = cin; controls.visible = cin
        main.visible = !cin; dock.visible = !cin; status.visible = !cin
        for (p in all) p.dirty = true
    }

    fun geometry(p: Panel): PanelGeo {
        val k = settings.panelDistance / 2f
        val sc = settings.panelScale * p.userScale
        return PanelGeo(p.ax * k, p.ay * k, -2f * k, p.baseW * k * sc, p.baseH * k * sc)
    }

    /** Raio (origem 0, direção dir) contra os painéis visíveis. Preenche outWorld com o ponto atingido. */
    fun hitTest(dir: FloatArray, outWorld: FloatArray): Hit? {
        for (p in hitOrder) {
            if (!p.visible || p.alpha < 0.3f) continue
            val g = geometry(p)
            val uv = PanelGeometry.intersect(dir[0], dir[1], dir[2], g) ?: continue
            val px = uv[0] * p.texW; val py = uv[1] * p.texH
            val b = p.buttons.lastOrNull { it.rect.contains(px, py) }
            val t = g.cz / dir[2]
            outWorld[0] = dir[0] * t; outWorld[1] = dir[1] * t; outWorld[2] = dir[2] * t
            return Hit(p, px, py, uv[0], uv[1], b)
        }
        val d = settings.panelDistance
        outWorld[0] = dir[0] * d; outWorld[1] = dir[1] * d; outWorld[2] = dir[2] * d
        return null
    }

    fun setHover(h: Hit?) {
        val np = h?.panel
        val nb = h?.button?.id
        if (np !== hoverPanel || nb != hoverButton) {
            hoverPanel?.dirty = true
            np?.dirty = true
            hoverPanel = np; hoverButton = nb
        }
    }

    fun beginDrag(p: Panel, dir: FloatArray): FloatArray {
        val g = geometry(p)
        val t = if (dir[2] < -1e-4f) g.cz / dir[2] else 1f
        return floatArrayOf(g.cx - dir[0] * t, g.cy - dir[1] * t)
    }

    fun dragTo(p: Panel, dir: FloatArray, off: FloatArray) {
        if (dir[2] > -1e-4f) return
        val k = settings.panelDistance / 2f
        val t = (-2f * k) / dir[2]
        p.ax = ((dir[0] * t + off[0]) / k).coerceIn(-3f, 3f)
        p.ay = ((dir[1] * t + off[1]) / k).coerceIn(-2f, 2f)
    }

    fun onSwipe(dir: Int) {
        when (screen) {
            Screen.SETTINGS -> { settingsPage = (settingsPage - dir + pageCount) % pageCount; main.dirty = true }
            Screen.TUTORIAL -> { tutorialPage = (tutorialPage - dir + 3) % 3; main.dirty = true }
            Screen.ENV -> setEnv(settings.environment - dir)
            else -> {}
        }
    }

    // ------------------------------------------------------- ciclo

    fun onGlCreated() { for (p in all) { p.tex = 0; p.dirty = true } }

    fun update(now: Long) {
        head.enabled = settings.headTracking
        head.sensitivity = settings.headSensitivity
        head.smoothingTauMs = settings.headSmoothing * 100f

        while (true) {
            val m = pending.poll() ?: break
            notes.addFirst(timeFmt.format(Date()) to m)
            while (notes.size > 4) notes.removeLast()
            if (screen == Screen.HOME) main.dirty = true
        }
        val dt = if (lastUpdate == 0L) 16L else now - lastUpdate
        lastUpdate = now
        val k = 1f - exp(-dt / 80f)
        for (p in all) {
            val target = if (p.visible) 1f else 0f
            p.alpha += (target - p.alpha) * k
        }
        if (now - lastSecond >= 1000) { lastSecond = now; pollDevice(); status.dirty = true }
        if (now - lastFast >= 250) {
            lastFast = now
            if (screen == Screen.DIAG || screen == Screen.TUTORIAL) main.dirty = true
            if (screen == Screen.CINEMA) { controls.dirty = true; video.dirty = true }
        }
        if (confirmResetUntil != 0L && now > confirmResetUntil) { confirmResetUntil = 0L; main.dirty = true }
    }

    fun refreshTextures() {
        for (p in all) {
            if (p.tex == 0) { p.tex = GlUtil.newTexture(); p.dirty = true }
            if (p.dirty && (p.visible || p.alpha > 0.01f)) {
                p.buttons.clear()
                p.canvas.drawColor(0, PorterDuff.Mode.CLEAR)
                p.drawFn(p.canvas, p)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, p.tex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, p.bitmap, 0)
                p.dirty = false
            }
        }
    }

    private fun pollDevice() {
        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                Telemetry.batteryPct = if (level >= 0) level * 100 / scale else -1
                Telemetry.batteryTempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                Telemetry.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            Telemetry.net = when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Móvel"
                else -> "Rede"
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                Telemetry.thermal = pm.currentThermalStatus
                val hot = Telemetry.thermal >= PowerManager.THERMAL_STATUS_SEVERE
                if (hot && !Telemetry.thermalThrottle) notify("Aparelho quente: rastreio de mãos reduzido a 10 fps")
                Telemetry.thermalThrottle = hot
            }
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------ widgets

    private fun btn(
        p: Panel, c: Canvas, id: String, r: RectF, label: String, enabled: Boolean = true,
        accent: Boolean = false, size: Float = 28f, onScrub: ((Float) -> Unit)? = null, onClick: () -> Unit
    ) {
        p.buttons.add(Button(id, RectF(r), enabled, onScrub, onClick))
        val hover = enabled && hoverPanel === p && hoverButton == id
        Gfx.rrect(c, r, 16f, if (hover) Gfx.BTN_HOVER else Gfx.BTN,
            if (hover || accent) Gfx.ACCENT else 0x33FFFFFF, if (hover) 4f else 2f)
        Gfx.text(c, label, r.centerX(), r.centerY() + size * 0.35f, size,
            if (enabled) Gfx.TEXT else Gfx.DISABLED, Paint.Align.CENTER)
    }

    private fun title(c: Canvas, s: String) { Gfx.text(c, s, 64f, 58f, 44f, Gfx.ACCENT, bold = true) }

    // -------------------------------------------------------- telas

    private fun drawStatus(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val bat = if (Telemetry.batteryPct >= 0) "${Telemetry.batteryPct}%${if (Telemetry.charging) " (carregando)" else ""}" else "--"
        Gfx.text(c, timeFmt.format(Date()), 40f, 58f, 34f, Gfx.TEXT, bold = true)
        Gfx.text(c, "Bateria $bat   ${Telemetry.net}", 190f, 56f, 26f, Gfx.DIM)
        val headTxt = if (head.enabled) (if (Telemetry.headRateHz > 0f) "Cabeça OK" else "Cabeça: sem dados") else "Cabeça off"
        Gfx.text(c, "Entrada: ${Telemetry.inputMethod}   $headTxt", 1060f, 56f, 26f, Gfx.ACCENT, Paint.Align.RIGHT)
    }

    private fun drawDock(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val labels = listOf(
            "inicio" to "Início", "cinema" to "Cinema", "config" to "Config.", "diag" to "Diagnóstico",
            "recenter" to "Recentrar", "mode" to (if (controller.isVrMode()) "Modo: VR" else "Modo: Plano"),
            "hand" to (if (settings.handEnabled) "Mãos: ON" else "Mãos: OFF")
        )
        val w = 140f; val gap = 10f
        var x = (p.texW - (labels.size * w + (labels.size - 1) * gap)) / 2f
        for ((id, label) in labels) {
            val r = RectF(x, 28f, x + w, 122f)
            btn(p, c, id, r, label, accent = id == "inicio" && screen == Screen.HOME, size = 24f) {
                when (id) {
                    "inicio" -> goHome()
                    "cinema" -> goTo(Screen.CINEMA)
                    "config" -> goTo(Screen.SETTINGS)
                    "diag" -> goTo(Screen.DIAG)
                    "recenter" -> { controller.recenter(); notify("Visão recentralizada") }
                    "mode" -> controller.setVrMode(!controller.isVrMode())
                    "hand" -> controller.setHandTracking(!settings.handEnabled)
                }
                dock.dirty = true
            }
            x += w + gap
        }
    }

    private fun drawHome(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        Gfx.text(c, "VR BOX OS", 64f, 90f, 56f, Gfx.ACCENT, bold = true)
        Gfx.text(c, dateFmt.format(Date()), 1216f, 88f, 28f, Gfx.DIM, Paint.Align.RIGHT)
        for ((i, t) in tiles.withIndex()) {
            val col = i % 4; val row = i / 4
            val x = 64f + col * (270f + 24f); val y = 130f + row * (190f + 24f)
            val r = RectF(x, y, x + 270f, y + 190f)
            btn(p, c, "tile_${t.id}", r, "", enabled = t.available, onClick = t.action)
            val cc = if (t.available) Gfx.ACCENT else 0x55FFFFFF
            Gfx.circle(c, r.centerX(), y + 62f, 34f, (cc and 0x00FFFFFF) or 0x33000000)
            Gfx.text(c, t.title.take(1), r.centerX(), y + 76f, 40f, cc, Paint.Align.CENTER, bold = true)
            val col2 = if (t.available) Gfx.TEXT else Gfx.DISABLED
            Gfx.text(c, t.title, r.centerX(), y + 135f, 30f, col2, Paint.Align.CENTER)
            Gfx.text(c, t.sub, r.centerX(), y + 168f, 22f, if (t.available) Gfx.DIM else Gfx.WARN, Paint.Align.CENTER)
        }
        Gfx.text(c, "Notificações", 64f, 590f, 26f, Gfx.DIM, bold = true)
        var y = 626f
        for (n in notes) { Gfx.text(c, "${n.first}  ${n.second}", 64f, y, 24f, Gfx.TEXT); y += 30f }
    }

    private fun drawSettings(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Configurações")
        val start = settingsPage * rowsPerPage
        for (i in 0 until rowsPerPage) {
            val idx = start + i
            if (idx >= rows.size) break
            val row = rows[idx]
            val y = 100f + i * 78f
            Gfx.text(c, row.label, 64f, y + 46f, 30f)
            Gfx.rrect(c, RectF(660f, y + 6f, 960f, y + 66f), 14f, 0x33000000)
            Gfx.text(c, row.value(), 810f, y + 46f, 30f, Gfx.ACCENT, Paint.Align.CENTER)
            btn(p, c, "dec$idx", RectF(990f, y + 6f, 1070f, y + 66f), "−", size = 36f) { row.dec(); p.dirty = true }
            btn(p, c, "inc$idx", RectF(1090f, y + 6f, 1170f, y + 66f), "+", size = 36f) { row.inc(); p.dirty = true }
        }
        btn(p, c, "prev", RectF(64f, 596f, 150f, 676f), "<", size = 36f) { settingsPage = (settingsPage - 1 + pageCount) % pageCount; p.dirty = true }
        Gfx.text(c, "${settingsPage + 1}/$pageCount", 205f, 648f, 28f, Gfx.DIM, Paint.Align.CENTER)
        btn(p, c, "next", RectF(260f, 596f, 346f, 676f), ">", size = 36f) { settingsPage = (settingsPage + 1) % pageCount; p.dirty = true }
        btn(p, c, "recenter", RectF(380f, 596f, 640f, 676f), "Recentrar vista", size = 24f) { controller.recenter(); notify("Visão recentralizada") }
        btn(p, c, "resetpos", RectF(660f, 596f, 930f, 676f), "Restaurar painéis", size = 24f) {
            for (q in all) q.resetPlacement(); notify("Painéis restaurados")
        }
        val confirming = confirmResetUntil != 0L
        btn(p, c, "resetall", RectF(950f, 596f, 1216f, 676f), if (confirming) "Confirmar?" else "Padrões…", accent = confirming, size = 24f) {
            if (confirmResetUntil != 0L) {
                confirmResetUntil = 0L
                val hand = settings.handEnabled
                settings.resetDefaults()
                if (hand) controller.setHandTracking(false)
                notify("Configurações restauradas")
            } else confirmResetUntil = SystemClock.elapsedRealtime() + 3000
            p.dirty = true
        }
    }

    private fun drawEnv(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Ambientes")
        for (i in 0 until 3) {
            val x = 64f + i * (380f + 24f)
            val r = RectF(x, 130f, x + 380f, 520f)
            btn(p, c, "env$i", r, "") { settings.environment = i; notify("Ambiente: ${Environments.NAMES[i]}"); p.dirty = true }
            val cur = settings.environment == i
            Gfx.text(c, Environments.NAMES[i], r.centerX(), 230f, 32f, if (cur) Gfx.ACCENT else Gfx.TEXT, Paint.Align.CENTER, bold = true)
            Gfx.paragraph(c, Environments.DESCRIPTIONS[i], x + 30f, 300f, 320f, 26f, Gfx.DIM)
            if (cur) Gfx.text(c, "● Ativo", r.centerX(), 490f, 28f, Gfx.OK, Paint.Align.CENTER)
        }
        Gfx.text(c, "A escolha é salva e mantida entre sessões.", 64f, 600f, 26f, Gfx.DIM)
    }

    private fun drawTutorial(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Tutorial (${tutorialPage + 1}/3)")
        when (tutorialPage) {
            0 -> Gfx.paragraph(c,
                "Olhar: mire num botão e mantenha o olhar até o anel fechar.\n" +
                "Mãos: aponte com o indicador e faça a pinça (polegar + indicador) para clicar.\n" +
                "Segure a pinça na faixa superior de um painel para movê-lo. Com duas mãos em pinça, afaste ou aproxime para redimensionar.\n" +
                "Recentrar: botão na barra inferior, ou segure o punho por 1 s (Menu).\n" +
                "Hand tracking exige uma câmera que enxergue suas mãos (veja o README).", 64f, 120f, 1150f, 32f)
            1 -> Gfx.paragraph(c,
                "1 Mão aberta: mostra a mão virtual.   2 Punho: comando configurável.\n" +
                "3 Indicador: aponta o cursor.   4 Pinça: seleciona/clica.\n" +
                "5 Abrir após pinça: solta.   6 Punho sobre painel: agarra e solta.\n" +
                "7 Deslizar a mão aberta: troca de página.   8 Duas mãos: redimensionar.\n" +
                "9 Punho 1 s: Menu (configurável).   10 Palma 1,2 s: Voltar (configurável).\n" +
                "Gestos que causem falsos positivos podem ser desativados em Configurações.", 64f, 120f, 1150f, 32f)
            else -> {
                val r = router
                val snap = pipeline.tracker.snapshot.get()
                val h = snap?.hands?.firstOrNull()
                Gfx.text(c, "Pratique: faça os gestos e veja a contagem.", 64f, 130f, 32f)
                Gfx.text(c, "Método ativo: ${Telemetry.inputMethod}", 64f, 200f, 30f, Gfx.ACCENT)
                Gfx.text(c, "Gesto atual: ${h?.pose ?: "sem mão"}  (confiança ${"%.2f".format(h?.poseConfidence ?: 0f)})", 64f, 260f, 30f)
                Gfx.text(c, "Pinças: ${r?.pinches ?: 0}    Cliques: ${r?.clicks ?: 0}    Deslizes: ${r?.swipes ?: 0}", 64f, 320f, 30f)
                if (!settings.handEnabled) Gfx.text(c, "Hand tracking desligado: ative em Configurações ou na barra inferior.", 64f, 400f, 26f, Gfx.WARN)
            }
        }
        btn(p, c, "tprev", RectF(64f, 596f, 200f, 676f), "<", size = 36f) { tutorialPage = (tutorialPage + 2) % 3; p.dirty = true }
        btn(p, c, "tnext", RectF(1080f, 596f, 1216f, 676f), ">", size = 36f) { tutorialPage = (tutorialPage + 1) % 3; p.dirty = true }
    }

    private fun drawDiag(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        title(c, "Diagnóstico")
        val box = RectF(40f, 100f, 600f, 460f)
        val snap = pipeline.tracker.snapshot.get()
        val hand = snap?.hands?.firstOrNull()
        val fov = when {
            hand == null -> Gfx.DIM
            (0 until 21).all { hand.lm[it * 3] in 0.03f..0.97f && hand.lm[it * 3 + 1] in 0.03f..0.97f } -> Gfx.OK
            else -> Gfx.WARN
        }
        Gfx.rrect(c, box, 14f, 0x66000000, fov, 5f)
        val bmp = pipeline.tracker.thumbnail
        if (bmp != null && settings.handEnabled) {
            val ar = bmp.width.toFloat() / bmp.height
            val w = min(box.width(), box.height() * ar); val h = w / ar
            val dst = RectF(box.centerX() - w / 2, box.centerY() - h / 2, box.centerX() + w / 2, box.centerY() + h / 2)
            c.drawBitmap(bmp, null, dst, null)
            snap?.hands?.forEach { hs ->
                fun px(i: Int) = dst.left + (if (settings.mirrorHands) 1f - hs.lm[i * 3] else hs.lm[i * 3]) * dst.width()
                fun py(i: Int) = dst.top + hs.lm[i * 3 + 1] * dst.height()
                for (b in HandTopology.BONES) Gfx.line(c, px(b[0]), py(b[0]), px(b[1]), py(b[1]), Gfx.ACCENT, 3f)
                for (i in 0 until 21) Gfx.circle(c, px(i), py(i), 4f, Gfx.TEXT)
            }
        } else {
            Gfx.text(c, "Sem imagem da câmera", box.centerX(), box.centerY(), 28f, Gfx.DIM, Paint.Align.CENTER)
        }
        val fovMsg = when (fov) { Gfx.OK -> "Campo: mão inteira dentro"; Gfx.WARN -> "Campo: mão cortada nas bordas"; else -> "Campo: nenhuma mão" }
        Gfx.text(c, fovMsg, box.left, 490f, 26f, fov)

        val lines = ArrayList<String>()
        lines += "Render ${"%.0f".format(Telemetry.renderFps)} fps   Mãos ${"%.0f".format(Telemetry.handFps)} fps"
        lines += "Latência de inferência: ${"%.0f".format(Telemetry.handLatencyMs)} ms (não é glass-to-glass)"
        lines += "Rastreio: ${Telemetry.handStatus}"
        lines += "Fonte: ${Telemetry.sourceName}"
        lines += "Disponíveis: ${Telemetry.sourcesText}"
        val n = snap?.hands?.size ?: 0
        lines += "Mãos detectadas: $n"
        snap?.hands?.forEachIndexed { i, h ->
            lines += "  [$i] ${h.pose} conf ${"%.2f".format(h.poseConfidence)} pinça ${"%.2f".format(h.pinchRatio)}"
        }
        lines += "Cabeça: ${Telemetry.headStatus} ${"%.0f".format(Telemetry.headRateHz)} Hz"
        lines += "Bateria ${Telemetry.batteryPct}%  ${if (Telemetry.batteryTempC.isNaN()) "" else "%.1f°C".format(Telemetry.batteryTempC)}  térmico ${Telemetry.thermal}"
        lines += "${Build.MANUFACTURER} ${Build.MODEL}  Android ${Build.VERSION.RELEASE}"
        var y = 130f
        for (l in lines) { Gfx.text(c, l, 640f, y, 23f); y += 32f }

        btn(p, c, "toggle", RectF(40f, 530f, 400f, 620f), if (settings.handEnabled) "Parar rastreio" else "Iniciar rastreio", size = 28f) {
            controller.setHandTracking(!settings.handEnabled); p.dirty = true
        }
        btn(p, c, "source", RectF(420f, 530f, 840f, 620f), "Fonte: ${settings.camera.label}", size = 26f) {
            settings.camera = cyc(settings.camera, 1)
            if (settings.handEnabled) controller.restartHandSource()
            p.dirty = true
        }
        btn(p, c, "recenter", RectF(860f, 530f, 1216f, 620f), "Recentrar vista", size = 26f) { controller.recenter() }
    }

    // ------------------------------------------------------ cinema

    private fun mmss(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private fun drawVideoPlaceholder(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val msg = when {
            cinema.error != null -> cinema.error!!
            cinema.hasMedia -> "Carregando vídeo…"
            else -> "Nenhum vídeo selecionado.\nToque em “Vídeo” nos controles (fora do headset) para escolher um arquivo local."
        }
        Gfx.paragraph(c, msg, 120f, 300f, 1040f, 36f, Gfx.TEXT)
    }

    private fun drawControls(c: Canvas, p: Panel) {
        Gfx.glass(c, p.texW, p.texH)
        val bar = RectF(30f, 22f, 1170f, 56f)
        p.buttons.add(Button("seek", RectF(bar), cinema.hasMedia, { u -> cinema.seekFraction(u) }) {})
        Gfx.rrect(c, bar, 17f, 0x55FFFFFF)
        val frac = if (cinema.durationMs > 0) cinema.positionMs.toFloat() / cinema.durationMs else 0f
        Gfx.rrect(c, RectF(bar.left, bar.top, bar.left + bar.width() * frac.coerceIn(0f, 1f), bar.bottom), 17f, Gfx.ACCENT)
        Gfx.text(c, "${mmss(cinema.positionMs)} / ${mmss(cinema.durationMs)}", 30f, 98f, 24f, Gfx.TEXT)
        Gfx.text(c, "Volume ${(cinema.volume * 100).toInt()}%", 1170f, 98f, 24f, Gfx.DIM, Paint.Align.RIGHT)
        val items = listOf(
            "home" to "Início", "b10" to "-10s", "play" to (if (cinema.isPlaying) "Pausar" else "Tocar"), "f10" to "+10s",
            "vm" to "Vol -", "vp" to "Vol +", "sm" to "Tela -", "sp" to "Tela +",
            "flat" to (if (flatTheater) "Sala" else "Plana"), "s3d" to cinema.stereoLabel, "pick" to "Vídeo"
        )
        val w = 98f; val gap = 8f
        var x = (p.texW - (items.size * w + (items.size - 1) * gap)) / 2f
        for ((id, label) in items) {
            val en = cinema.hasMedia || id == "home" || id == "pick" || id == "sm" || id == "sp" || id == "flat" || id == "s3d"
            btn(p, c, id, RectF(x, 122f, x + w, 186f), label, enabled = en, size = 22f) {
                when (id) {
                    "home" -> back()
                    "b10" -> cinema.seekBy(-10_000)
                    "f10" -> cinema.seekBy(10_000)
                    "play" -> cinema.togglePlay()
                    "vm" -> cinema.changeVolume(-0.1f)
                    "vp" -> cinema.changeVolume(0.1f)
                    "sm" -> video.userScale = (video.userScale - 0.1f).coerceAtLeast(0.5f)
                    "sp" -> video.userScale = (video.userScale + 0.1f).coerceAtMost(2.5f)
                    "flat" -> flatTheater = !flatTheater
                    "s3d" -> cinema.cycleStereo()
                    "pick" -> controller.pickVideo()
                }
                p.dirty = true
            }
            x += w + gap
        }
    }
}
