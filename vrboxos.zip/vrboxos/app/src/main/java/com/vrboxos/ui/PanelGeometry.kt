package com.vrboxos.ui

/** Painel plano em z = cz (negativo, na frente do usuário), centro (cx,cy), tamanho (w,h) em metros. */
data class PanelGeo(val cx: Float, val cy: Float, val cz: Float, val w: Float, val h: Float)

object PanelGeometry {
    /**
     * Raio partindo da origem com direção (dx,dy,dz). Retorna (u,v) em [0,1] (v=0 no topo)
     * se atinge o painel; null caso contrário (fora, ou raio apontando para trás).
     */
    fun intersect(dx: Float, dy: Float, dz: Float, g: PanelGeo): FloatArray? {
        if (dz >= -1e-4f) return null
        val t = g.cz / dz
        val hx = dx * t
        val hy = dy * t
        val u = (hx - g.cx) / g.w + 0.5f
        val v = 0.5f - (hy - g.cy) / g.h
        if (u < 0f || u > 1f || v < 0f || v > 1f) return null
        return floatArrayOf(u, v)
    }
}
