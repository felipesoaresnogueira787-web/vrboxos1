package com.vrboxos

import com.vrboxos.hands.*
import org.junit.Assert.*
import org.junit.Test

/** Mãos sintéticas (aspecto 1:1). Testes da lógica; NÃO substituem testes com câmera real. */
class GestureEngineTest {
    private val OPEN = listOf(
        .50f to .80f, .44f to .75f, .40f to .70f, .37f to .65f, .34f to .60f,
        .46f to .60f, .46f to .52f, .46f to .46f, .46f to .40f,
        .50f to .58f, .50f to .49f, .50f to .42f, .50f to .35f,
        .54f to .60f, .54f to .52f, .54f to .46f, .54f to .41f,
        .58f to .63f, .58f to .56f, .58f to .51f, .58f to .47f
    )
    private val FIST = listOf(
        .50f to .80f, .44f to .75f, .42f to .70f, .45f to .66f, .50f to .66f,
        .46f to .60f, .46f to .54f, .47f to .60f, .47f to .67f,
        .50f to .58f, .50f to .53f, .50f to .59f, .50f to .66f,
        .54f to .60f, .54f to .55f, .54f to .61f, .54f to .67f,
        .58f to .63f, .58f to .58f, .58f to .63f, .58f to .68f
    )
    private val POINT = listOf(
        .50f to .80f, .44f to .75f, .42f to .70f, .45f to .66f, .50f to .66f,
        .46f to .60f, .46f to .52f, .46f to .46f, .46f to .40f,
        .50f to .58f, .50f to .53f, .50f to .59f, .50f to .66f,
        .54f to .60f, .54f to .55f, .54f to .61f, .54f to .67f,
        .58f to .63f, .58f to .58f, .58f to .63f, .58f to .68f
    )
    private val PINCH = listOf(
        .50f to .80f, .44f to .75f, .42f to .66f, .43f to .56f, .43f to .47f,
        .46f to .60f, .46f to .53f, .44f to .48f, .42f to .46f,
        .50f to .58f, .50f to .49f, .50f to .42f, .50f to .35f,
        .54f to .60f, .54f to .52f, .54f to .46f, .54f to .41f,
        .58f to .63f, .58f to .56f, .58f to .51f, .58f to .47f
    )

    private fun hand(pose: List<Pair<Float, Float>>, dx: Float = 0f, score: Float = 0.9f): RawHand {
        val a = FloatArray(63)
        pose.forEachIndexed { i, p -> a[i * 3] = p.first + dx; a[i * 3 + 1] = p.second; a[i * 3 + 2] = 0f }
        return RawHand(a, "Right", score)
    }

    private fun run(e: GestureEngine, pose: List<Pair<Float, Float>>, from: Long, frames: Int, dx: Float = 0f): HandSnapshot {
        var snap: HandSnapshot? = null
        for (k in 0 until frames) snap = e.process(from + k * 33L, listOf(hand(pose, dx)), 1f, false, 5f)
        return snap!!
    }

    private fun drain(e: GestureEngine): List<GestureEvent> {
        val l = ArrayList<GestureEvent>()
        while (true) { l.add(e.events.poll() ?: break) }
        return l
    }

    @Test fun openFistPointAreRecognised() {
        val e = GestureEngine()
        assertEquals(Pose.OPEN, run(e, OPEN, 0, 8).hands[0].pose)
        assertEquals(Pose.FIST, run(e, FIST, 300, 8).hands[0].pose)
        assertEquals(Pose.POINT, run(e, POINT, 600, 8).hands[0].pose)
    }

    @Test fun pinchProducesStartAndEnd() {
        val e = GestureEngine()
        run(e, OPEN, 0, 8)
        drain(e)
        val s = run(e, PINCH, 300, 6)
        assertTrue(s.hands[0].pinching)
        val ev = drain(e)
        assertEquals(1, ev.count { it is GestureEvent.PinchStart })
        run(e, OPEN, 600, 6)
        assertEquals(1, drain(e).count { it is GestureEvent.PinchEnd })
    }

    @Test fun fistDoesNotCountAsPinch() {
        val e = GestureEngine()
        run(e, OPEN, 0, 8)
        drain(e)
        run(e, FIST, 300, 10)
        assertEquals(0, drain(e).count { it is GestureEvent.PinchStart })
    }

    @Test fun singleNoisyFrameDoesNotClick() {
        val e = GestureEngine()
        run(e, OPEN, 0, 8)
        drain(e)
        e.process(300, listOf(hand(PINCH)), 1f, false, 5f)   // 1 quadro só
        run(e, OPEN, 333, 6)
        assertEquals(0, drain(e).count { it is GestureEvent.PinchStart })
    }

    @Test fun quickRepinchIsLockedOut() {
        val e = GestureEngine()
        run(e, OPEN, 0, 8); drain(e)
        run(e, PINCH, 300, 5)                 // pinça 1
        run(e, OPEN, 465, 3)                  // solta (~100 ms)
        run(e, PINCH, 565, 3)                 // repinça dentro do bloqueio (250 ms)
        val starts = drain(e).count { it is GestureEvent.PinchStart }
        assertEquals(1, starts)
    }

    @Test fun fistHeldStillEmitsHoldOnce() {
        val e = GestureEngine()
        run(e, FIST, 0, 45)                   // ~1,5 s
        assertEquals(1, drain(e).count { it is GestureEvent.Hold && it.gesture == HoldGesture.FIST })
    }

    @Test fun lostHandIsReportedAfterGrace() {
        val e = GestureEngine()
        run(e, OPEN, 0, 8)
        drain(e)
        val s1 = e.process(400, emptyList(), 1f, false, 0f)   // dentro da tolerância (age 169 ms)
        assertEquals(1, s1.hands.size)
        assertTrue(s1.hands[0].fade < 1f)
        val s2 = e.process(700, emptyList(), 1f, false, 0f)   // além da tolerância
        assertEquals(0, s2.hands.size)
        assertEquals(1, drain(e).count { it is GestureEvent.HandLost })
    }

    @Test fun lowScoreHandIsIgnored() {
        val e = GestureEngine()
        val s = e.process(0, listOf(hand(OPEN, score = 0.2f)), 1f, false, 0f)
        assertEquals(0, s.hands.size)
    }

    @Test fun swipeRightIsDetected() {
        val e = GestureEngine()
        var snap: HandSnapshot
        for (k in 0 until 3) e.process(k * 33L, listOf(hand(OPEN, -0.25f)), 1f, false, 0f)
        drain(e)
        for (k in 3 until 12) snap = e.process(k * 33L, listOf(hand(OPEN, -0.25f + (k - 2) * 0.07f)), 1f, false, 0f)
        assertTrue(drain(e).any { it is GestureEvent.Swipe && it.dirX == 1 })
    }

    @Test fun twoHandsGiveDistance() {
        val e = GestureEngine()
        var s: HandSnapshot? = null
        for (k in 0 until 6) s = e.process(k * 33L, listOf(hand(OPEN, -0.3f), hand(OPEN, 0.3f)), 1f, false, 0f)
        assertEquals(2, s!!.hands.size)
        assertTrue(s.twoHandDistance > 0.5f)
    }

    @Test fun oneEuroReducesJitter() {
        val f = OneEuro(1.5f, 4f)
        var maxRaw = 0f; var maxFilt = 0f
        var prevF = f.filter(0.5f, 0)
        for (k in 1..60) {
            val noise = if (k % 2 == 0) 0.01f else -0.01f
            val out = f.filter(0.5f + noise, k * 33L)
            maxRaw = maxOf(maxRaw, Math.abs(noise))
            maxFilt = maxOf(maxFilt, Math.abs(out - 0.5f))
            prevF = out
        }
        assertTrue(maxFilt < maxRaw)
    }

    @Test fun resetClearsPinchSoNothingStaysStuck() {
        val e = GestureEngine()
        run(e, OPEN, 0, 8); run(e, PINCH, 300, 6)
        assertEquals(1, drain(e).count { it is GestureEvent.PinchStart })
        e.reset()
        assertTrue(e.events.isEmpty())
        // ao retomar, uma mão aberta não pode herdar a pinça antiga
        val s = run(e, OPEN, 10_000, 8)
        assertFalse(s.hands[0].pinching)
        assertEquals(0, drain(e).count { it is GestureEvent.PinchEnd })
        // e uma nova pinça volta a funcionar normalmente (sem trava herdada)
        run(e, PINCH, 10_300, 6)
        assertEquals(1, drain(e).count { it is GestureEvent.PinchStart })
    }
}
