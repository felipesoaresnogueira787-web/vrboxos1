package com.vrboxos

import com.vrboxos.head.*
import com.vrboxos.input.ClickGuard
import com.vrboxos.input.DwellTracker
import com.vrboxos.render.StereoLayout
import com.vrboxos.ui.PanelGeo
import com.vrboxos.ui.PanelGeometry
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI

class CoreLogicTest {
    @Test fun clickGuardBlocksRepeatedClicks() {
        val g = ClickGuard(350)
        assertTrue(g.allow(1000))
        assertFalse(g.allow(1200))
        assertTrue(g.allow(1400))
    }

    @Test fun dwellFiresOnceThenRequiresLeaving() {
        val d = DwellTracker()
        assertFalse(d.update("A", 0, 1500).fired)
        assertFalse(d.update("A", 1400, 1500).fired)
        assertTrue(d.update("A", 1500, 1500).fired)
        assertFalse(d.update("A", 1700, 1500).fired)
        d.update(null, 1800, 1500)
        d.update("A", 1900, 1500)
        assertTrue(d.update("A", 3400, 1500).fired)
    }

    @Test fun panelHitCenterAndMiss() {
        val g = PanelGeo(0f, 0f, -2f, 2f, 1f)
        val hit = PanelGeometry.intersect(0f, 0f, -1f, g)!!
        assertEquals(0.5f, hit[0], 1e-4f); assertEquals(0.5f, hit[1], 1e-4f)
        assertNull(PanelGeometry.intersect(1f, 0f, -1f, g))      // x=2 m: fora
        assertNull(PanelGeometry.intersect(0f, 0f, 1f, g))       // apontando para trás
    }

    @Test fun stereoViewportsAndIpdShift() {
        val l = StereoLayout.eyeViewport(2000, 1000, 0)
        val r = StereoLayout.eyeViewport(2000, 1000, 1)
        assertArrayEquals(intArrayOf(0, 0, 1000, 1000), l)
        assertArrayEquals(intArrayOf(1000, 0, 1000, 1000), r)
        assertEquals(0.0315f, StereoLayout.eyeShiftMeters(63f, 0), 1e-6f)
        assertEquals(-0.0315f, StereoLayout.eyeShiftMeters(63f, 1), 1e-6f)
    }

    @Test fun recenterMakesCurrentForwardTheFront() {
        val p = HeadPose()
        p.raw = Quat.fromAxisAngle(0f, 1f, 0f, (PI / 3).toFloat())    // olhando 60° para o lado
        p.recenter()
        val f = p.orientation().rotate(floatArrayOf(0f, 0f, -1f))
        assertEquals(0f, f[0], 1e-3f); assertEquals(0f, f[1], 1e-3f); assertEquals(-1f, f[2], 1e-3f)
    }

    @Test fun recenterKeepsPitch() {
        val p = HeadPose()
        val yaw = Quat.fromAxisAngle(0f, 1f, 0f, 1.0f)
        val pitch = Quat.fromAxisAngle(1f, 0f, 0f, 0.4f)
        p.raw = yaw * pitch
        p.recenter()
        val f = p.orientation().rotate(floatArrayOf(0f, 0f, -1f))
        assertEquals(0f, f[0], 1e-3f)                 // yaw zerado
        assertTrue(f[1] > 0.3f)                       // pitch preservado (olhando para cima)
    }

    @Test fun disabledHeadTrackingGivesIdentity() {
        val p = HeadPose()
        p.raw = Quat.fromAxisAngle(0f, 1f, 0f, 1f)
        p.enabled = false
        assertEquals(Quat.IDENTITY, p.orientation())
    }

    @Test fun zeroSensitivityFreezesView() {
        val p = HeadPose()
        p.raw = Quat.fromAxisAngle(0f, 1f, 0f, 1f)
        p.sensitivity = 0f
        val f = p.orientation().rotate(floatArrayOf(0f, 0f, -1f))
        assertEquals(-1f, f[2], 1e-3f)
    }

    @Test fun phoneFacingNorthLooksAlongMinusZ() {
        // Celular em paisagem (ROTATION_90), em pé, tela voltada para o rosto, olhando para o Norte.
        // Eixo -Z do aparelho (para dentro da tela) = Norte (ENU +Y). Rotação sensor: x_dev->?; construímos q.
        // Aparelho em pé e girado 90° (paisagem): eixos do aparelho em ENU: X=Norte? usamos verificação indireta:
        val qSensor = Quat.fromAxisAngle(1f, 0f, 0f, (PI / 2).toFloat())   // topo do aparelho para cima, tela para Sul
        val q = HeadMath.sensorToHead(qSensor, 0)
        val f = q.rotate(floatArrayOf(0f, 0f, -1f))
        // Olhar horizontal para o Norte => -Z do mundo GL
        assertEquals(0f, f[0], 1e-3f); assertEquals(0f, f[1], 1e-3f); assertEquals(-1f, f[2], 1e-3f)
    }
}
