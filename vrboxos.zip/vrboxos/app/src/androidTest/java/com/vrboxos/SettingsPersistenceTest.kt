package com.vrboxos

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import com.vrboxos.settings.CameraKind
import com.vrboxos.settings.Settings
import org.junit.Assert.assertEquals
import org.junit.Test

/** Teste instrumentado (precisa de emulador/aparelho; NÃO roda no GitHub Actions padrão). */
class SettingsPersistenceTest {
    @Test fun valuesSurviveANewInstance() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        ctx.getSharedPreferences("vrboxos_settings", Context.MODE_PRIVATE).edit().clear().commit()
        val a = Settings(ctx)
        a.ipdMm = 66f; a.environment = 2; a.camera = CameraKind.EXTERNAL
        val b = Settings(ctx)
        assertEquals(66f, b.ipdMm, 1e-6f)
        assertEquals(2, b.environment)
        assertEquals(CameraKind.EXTERNAL, b.camera)
    }

    @Test fun outOfRangeValuesAreClamped() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val s = Settings(ctx)
        s.ipdMm = 500f
        assertEquals(75f, s.ipdMm, 1e-6f)
    }
}
