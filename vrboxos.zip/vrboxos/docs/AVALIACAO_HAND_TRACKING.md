# Avaliação do hand tracking em aparelho real

Nada aqui foi executado ainda. Este é o protocolo; **não declare o reconhecimento "bom" sem preencher a tabela.**

## Preparação
Aparelho, Android, câmera usada, resolução, fps (ver *Diagnóstico*), modelo `hand_landmarker.task` (float16).

## Condições (cada combinação por 60 s, depois 20 repetições de cada gesto)

| Variável | Valores |
|---|---|
| Iluminação | luz do dia, luz amarela fraca, contraluz |
| Distância da mão à câmera | 25 cm, 40 cm, 60 cm |
| Orientação | palma para a câmera, de lado, 45° |
| Mãos visíveis | 1, 2 |

## Métricas

1. **Taxa de detecção:** quadros com mão detectada / quadros com mão visível (anotação manual de 60 s de vídeo).
2. **Acerto por gesto:** de 20 execuções (aberta, punho, apontar, pinça), quantas foram classificadas certo.
3. **Falsos positivos:** comandos (clique, Menu, Voltar, deslize) por minuto com a mão em repouso/gesticulando à toa. Meta sugerida: 0 cliques e < 1 comando/min.
4. **Precisão do clique:** pinçar em alvos de 60 px; % de acertos no botão correto (20 tentativas).
5. **Tremor:** desvio padrão do cursor com a mão parada 10 s (leia na tela Diagnóstico / grave a tela).
6. **Latência de inferência:** valor exibido no Diagnóstico (não inclui captura nem renderização).
7. **Estabilidade térmica:** fps e latência no minuto 1 e no minuto 15; temperatura da bateria.

## Ajustes se os resultados forem ruins
Sensibilidade dos gestos (Config.), taxa máxima do rastreio, espelhar mãos, desativar o comando de
punho/palma que gerar falso positivo, melhorar a iluminação. Limiares estão em `GestureConfig`.
