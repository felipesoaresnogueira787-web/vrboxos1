# Como a câmera enxerga suas mãos dentro do VR Box

**Não presumimos que a câmera veja as mãos.** Com o celular dentro do headset:

| Configuração | Funciona? |
|---|---|
| Câmera frontal | Aponta para o seu rosto. **Não** vê as mãos de forma útil. |
| Câmera traseira | Normalmente bloqueada pelo headset ou apontando para a tampa. Só serve se o seu VR Box tiver abertura/espelho para ela. |
| Câmera USB externa (OTG) presa na frente do headset | **Melhor opção**, mas depende do aparelho (abaixo). |
| Câmera do celular fora do headset (modo de desenvolvimento) | Funciona para testar o reconhecimento, não para uso real. |

## USB: o que o app suporta e o que não suporta

* **Suportado:** câmeras que o Android expõe como **câmera externa via Camera2**
  (`LENS_FACING_EXTERNAL`) — normalmente Android 10+ e fabricantes que habilitam isso. O app lista em
  *Diagnóstico → Disponíveis* se "Externa: sim/não".
* **Não implementado:** câmeras UVC "genéricas" que exigem biblioteca própria (libuvc/UVCCamera).
  O ponto de extensão existe (`VideoSource`), mas ninguém escreveu essa implementação ainda.
* **Não é garantido:** USB OTG funcionar, a câmera funcionar sem hub alimentado, e o consumo de
  bateria. Muitos celulares não alimentam bem periféricos USB por muito tempo; considere hub com energia.
* **Permissões:** `CAMERA` (pedida só ao ligar o hand tracking, com explicação). Nenhuma permissão extra
  de USB é usada na rota Camera2.

## Se nenhuma câmera enxergar as mãos

O app **não** finge rastreio: a fonte indisponível gera aviso ("Fonte indisponível…"), o hand tracking
desliga e a entrada passa para olhar. A tela de Diagnóstico mostra imagem, pontos e se a mão está
inteira no campo de visão.
