# Arquitetura e decisões

**Android nativo em Kotlin + OpenGL ES 2.0** (GLSurfaceView), uma única Activity.

* **Por que nativo e não WebView/Three.js/WebXR:** WebXR não é garantido em WebView e a ponte
  câmera→JS→GL adicionaria latência. Um único processo com thread GL, thread de câmera e thread de sensor
  é mais simples de medir e depurar.
* **Estéreo:** cena desenhada duas vezes em um FBO (viewport esquerdo/direito), depois passada de
  distorção por olho na tela. Escala de renderização = qualidade gráfica (60/80/100 %).
* **Cabeça:** `TYPE_GAME_ROTATION_VECTOR` (fallback `ROTATION_VECTOR`), 200 Hz, suavização exponencial
  (constante de tempo 0–100 ms). Só rotação; **não há posição**. Recentralizar zera a guinada e mantém a inclinação.
* **Interface:** painéis planos com textura desenhada em `Canvas` (vidro escuro), posicionados em z=-2 m
  escalados pela distância configurada (mesmo tamanho angular). Hit-test por interseção raio-plano.
* **Mãos:** MediaPipe **Hand Landmarker** (21 pontos × 2 mãos). Não usamos o *Gesture Recognizer* pronto
  porque ele não tem pinça/agarrar nem controle de limiares; a classificação é geométrica, própria
  (`GestureEngine`), em Kotlin puro e testável.
  * Dedo estendido: razão `dist(ponta, pulso) / dist(PIP, pulso) > 1,15`; dobrado `< 1,05`.
  * Pinça: `dist(polegar, indicador) / tamanho da palma` com histerese (engata 0,28×sens, solta 0,45×sens),
    confirmação de 50 ms, trava de 250 ms entre pinças e exigência de indicador não dobrado (punho ≠ pinça).
  * O ponto de clique é lido ~120 ms **antes** da pinça fechar (a ponta do dedo se move ao pinçar).
  * Cursor filtrado com One Euro.
  * Os pontos são 2D da imagem; o `z` não participa de nenhuma decisão.
* **Threads:** análise de imagem em executor próprio (`STRATEGY_KEEP_ONLY_LATEST` descarta quadros velhos),
  resultado publicado em `AtomicReference`, eventos em `ConcurrentLinkedQueue`, consumidos na thread GL.
  A inferência nunca roda na thread de renderização.
* **Fonte de vídeo:** interface `VideoSource`; trocar de câmera não exige mexer em MediaPipe/gestos.
* **Cinema:** Media3 ExoPlayer → `SurfaceTexture` → textura externa. O player só é tocado na thread principal.
