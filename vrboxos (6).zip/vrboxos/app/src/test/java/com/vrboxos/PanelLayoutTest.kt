package com.vrboxos

import com.vrboxos.settings.Settings
import com.vrboxos.ui.PanelGeo
import com.vrboxos.ui.PanelLayout
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs
import kotlin.math.atan

class PanelLayoutTest {
    private val dist = Settings.DEFAULT_PANEL_DISTANCE
    private val scale = Settings.DEFAULT_PANEL_SCALE

    private fun deg(x: Float, z: Float) = Math.toDegrees(atan(abs(x / z).toDouble()))

    /** Painéis como definidos em SpatialUi: (ax, ay, largura, altura, layoutFactor). */
    private val menu = mapOf(
        "main" to floatArrayOf(0f, 0.10f, 2.0f, 1.125f, 1f), "status" to floatArrayOf(0f, 0.82f, 1.1f, 0.09f, 1f),
        "dock" to floatArrayOf(0f, -0.78f, 1.3f, 0.177f, 1f)
    )
    private val others = mapOf(
        "webview" to floatArrayOf(0f, -0.05f, 2.4f, 1.35f, 0.8f), "webbar" to floatArrayOf(0f, 0.84f, 2.4f, 0.375f, 0.8f),
        "kbd" to floatArrayOf(0f, -1.3f, 2.4f, 0.806f, 0.8f), "video" to floatArrayOf(0f, 0.25f, 3.2f, 1.8f, 0.75f),
        "controls" to floatArrayOf(0f, -0.95f, 2.2f, 0.367f, 0.75f), "camview" to floatArrayOf(0f, 0.28f, 1.8f, 1.35f, 1f),
        "cambar" to floatArrayOf(0f, -0.95f, 2.2f, 0.367f, 1f)
    )

    private fun geo(s: FloatArray, d: Float = dist, sc: Float = scale) =
        PanelLayout.geo(s[0], s[1], s[2], s[3], 1f, d, sc, s[4])

    @Test fun menuIsRealCloserThanBefore() {
        val before = PanelLayout.geo(0f, 0.10f, 2f, 1.125f, 1f, 2f, 1f, 1f)   // padrões antigos: 2,0 m, escala 1
        val now = geo(menu["main"]!!)
        assertEquals(-2f, before.cz, 1e-6f)
        assertEquals(-1.25f, now.cz, 1e-6f)                          // posição z REAL mudou
        assertTrue(abs(now.cz) in 0.8f..1.5f)                        // perto, mas não desconfortável (>= 0,8 m)
    }

    @Test fun menuLooksConsiderablyLargerThroughTheLenses() {
        val before = PanelLayout.geo(0f, 0.10f, 2f, 1.125f, 1f, 2f, 1f, 1f)
        val now = geo(menu["main"]!!)
        val angBefore = 2 * deg(before.w / 2, before.cz)
        val angNow = 2 * deg(now.w / 2, now.cz)
        assertTrue("antes %.1f°, agora %.1f°".format(angBefore, angNow), angNow > angBefore * 1.2)
    }

    @Test fun menuIsCenteredAndFitsInTheFieldOfView() {
        var top = -9f; var bottom = 9f
        for ((name, s) in menu) {
            val g = geo(s)
            assertEquals("$name centrado na horizontal", 0f, g.cx, 1e-6f)
            assertTrue("$name largura", deg(abs(g.cx) + g.w / 2, g.cz) < 38.0)
            top = maxOf(top, g.cy + g.h / 2); bottom = minOf(bottom, g.cy - g.h / 2)
        }
        val z = geo(menu["main"]!!).cz
        assertTrue("topo", deg(top, z) < 38.0); assertTrue("base", deg(bottom, z) < 38.0)
        assertEquals("menu equilibrado em torno do centro", 0.0, deg(top, z) - deg(-bottom, z), 3.0)
    }

    @Test fun otherScreensStayInsideTheView() {
        for ((name, s) in others) {
            val g = geo(s)
            assertTrue("$name horizontal", deg(abs(g.cx) + g.w / 2, g.cz) < 41.0)
            assertTrue("$name topo", deg(g.cy + g.h / 2, g.cz) < 44.0)
            assertTrue("$name base", deg(g.cy - g.h / 2, g.cz) < 44.0)
        }
    }

    @Test fun bothEyesSeeTheSamePlaneAndOnlyShiftByIpd() {
        // O painel é um plano único em z fixo: cada olho só desloca a câmera em ±IPD/2 (alinhamento preservado).
        val g = geo(menu["main"]!!)
        val ipd = 0.063f
        val left = g.cx + ipd / 2; val right = g.cx - ipd / 2
        assertEquals(ipd, left - right, 1e-6f)
        assertEquals(g.cz, geo(menu["main"]!!).cz, 0f)
    }

    @Test fun layoutScaleMovesPositionsAndSizesTogether() {
        val a = PanelLayout.geo(0.5f, 0.4f, 2f, 1f, 1f, 1.25f, 1f, 1f)
        val b = PanelLayout.geo(0.5f, 0.4f, 2f, 1f, 1f, 1.25f, 2f, 1f)
        assertEquals(a.cx * 2, b.cx, 1e-6f); assertEquals(a.cy * 2, b.cy, 1e-6f)
        assertEquals(a.w * 2, b.w, 1e-6f); assertEquals(a.h * 2, b.h, 1e-6f)
    }

    @Test fun cameraErrorClassification() {
        for (c in 1..3) assertTrue(com.vrboxos.hands.CameraErrors.isRecoverable(c))
        for (c in 4..7) assertTrue(com.vrboxos.hands.CameraErrors.isCritical(c))
        assertTrue(com.vrboxos.hands.CameraErrors.isCritical(99))
        assertEquals("câmera em uso por outro app", com.vrboxos.hands.CameraErrors.name(2))
    }
}
