package com.vrboxos

import com.vrboxos.input.HandMapping
import com.vrboxos.input.HoldSelector
import com.vrboxos.render.Environments
import com.vrboxos.render.StereoLayout
import com.vrboxos.ui.PanelLayout
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.atan
import kotlin.math.tan

class HandInteractionTest {
    @After fun cleanup() { HandMapping.passthrough = null }

    // ---------------- seleção por permanência do dedo (5 s) ----------------
    private val hold = 5000L

    /** Simula quadros de 50 ms. Retorna o instante do disparo (ms) ou -1. */
    private fun run(s: HoldSelector, from: Long, to: Long, hit: String?, sticky: Boolean = false): Long {
        var t = from
        while (t <= to) {
            val r = s.update(hit, sticky, t, hold)
            if (r.fired) return t
            t += 50
        }
        return -1
    }

    @Test fun firesOnlyAfterFiveContinuousSeconds() {
        val s = HoldSelector()
        assertEquals(-1, run(s, 0, 4950, "a:b"))          // ainda não
        val r = s.update("a:b", false, 5000, hold)
        assertTrue(r.fired); assertEquals(1f, r.progress, 0f)
    }

    @Test fun progressGrowsLinearlyForTheRing() {
        val s = HoldSelector()
        s.update("a:b", false, 0, hold)
        assertEquals(0.5f, s.update("a:b", false, 2500, hold).progress, 1e-3f)
        assertEquals(0.9f, s.update("a:b", false, 4500, hold).progress, 1e-3f)
    }

    @Test fun leavingCancelsAndRestartsFromZero() {
        val s = HoldSelector()
        run(s, 0, 3000, "a:b")
        run(s, 3050, 3500, null)                           // saiu (> tolerância de 250 ms)
        assertNull(s.currentKey)
        assertEquals(0f, s.update(null, false, 3550, hold).progress, 0f)
        s.update("a:b", false, 3600, hold)                 // voltou: contagem nova
        assertEquals(-1, run(s, 3650, 8500, "a:b"))        // 4,9 s depois ainda não
        assertTrue(s.update("a:b", false, 8600, hold).fired)
    }

    @Test fun pointingAtAnotherButtonRestarts() {
        val s = HoldSelector()
        run(s, 0, 4000, "a:b")
        s.update("a:c", false, 4050, hold)                 // outro botão
        assertEquals("a:c", s.currentKey)
        assertEquals(-1, run(s, 4100, 9000, "a:c"))        // 4,95 s depois do novo botão
        assertTrue(s.update("a:c", false, 9050, hold).fired)
    }

    @Test fun jitterOnTheEdgeDoesNotResetTheCount() {
        val s = HoldSelector()
        s.update("a:b", false, 0, hold)
        // 3 s com o ponto fora do botão mas dentro da área ampliada (tremor): a contagem continua
        assertEquals(-1, run(s, 50, 3000, null, sticky = true))
        assertEquals("a:b", s.currentKey)
        assertTrue(s.update("a:b", false, 5000, hold).fired)    // dispara no instante original
    }

    @Test fun shortExitIsForgiven() {
        val s = HoldSelector()
        s.update("a:b", false, 0, hold)
        assertEquals(-1, run(s, 50, 950, "a:b"))           // apontando o botão normalmente
        assertEquals(-1, run(s, 1000, 1200, null))         // saída de 200 ms (< 250): perdoada
        assertEquals("a:b", s.currentKey)
        assertEquals(-1, run(s, 1250, 4950, "a:b"))
        assertTrue(s.update("a:b", false, 5000, hold).fired)   // dispara no instante original
    }

    @Test fun longExitIsNotForgiven() {
        val s = HoldSelector()
        s.update("a:b", false, 0, hold)
        run(s, 50, 950, "a:b")
        run(s, 1000, 1400, null)                           // 400 ms fora (> 250): cancela
        assertNull(s.currentKey)
    }

    @Test fun doesNotRepeatWhileStayingThenRearmsAfterLeaving() {
        val s = HoldSelector()
        assertTrue(run(s, 0, 5000, "a:b") >= 0)
        assertEquals(-1, run(s, 5050, 20000, "a:b"))       // parado sobre o mesmo botão: não repete
        run(s, 20050, 20500, null)                          // sai
        s.update("a:b", false, 20550, hold)                 // entra de novo
        assertTrue(s.update("a:b", false, 25550, hold).fired)
    }

    // ---------------- ponto na ponta do dedo alinhado à imagem da câmera ----------------
    private fun pt(zoom: Float = 1f, view: Float = 1.1111f, fov: Float = 90f) = HandMapping.Passthrough(view, zoom, fov)

    @Test fun fingertipAtImageCenterPointsStraightAhead() {
        val out = FloatArray(2)
        HandMapping.passthroughSpace(0.5f, 0.5f, 4f / 3f, pt(), out)
        assertEquals(0f, out[0], 1e-6f); assertEquals(0f, out[1], 1e-6f)
    }

    @Test fun fingertipAtImageEdgeMapsToWhereTheImageEdgeIsDrawn() {
        val view = 1.1111f; val img = 4f / 3f
        val out = FloatArray(2)
        HandMapping.passthroughSpace(1f, 0.5f, img, pt(view = view), out)    // borda direita: preenche a largura
        val tanY = tan(Math.toRadians(45.0)).toFloat()
        assertEquals(tanY * view, out[0], 1e-4f)                            // = borda direita da tela do olho
        HandMapping.passthroughSpace(0.5f, 0f, img, pt(view = view), out)   // topo: imagem é mais baixa que a tela
        assertEquals(tanY * (view / img), out[1], 1e-4f)
    }

    @Test fun projectingTheDirectionReproducesTheDrawnImagePosition() {
        // Mesmo caminho do renderizador: NDC = direção / tan(meio FOV). Deve igualar o NDC em que a imagem é desenhada.
        val view = 1.1111f; val img = 4f / 3f; val zoom = 1.2f
        val sx = 1f * zoom; val sy = (view / img) * zoom
        val out = FloatArray(2)
        for ((nx, ny) in listOf(0.2f to 0.3f, 0.8f to 0.9f, 0.5f to 0.1f)) {
            HandMapping.passthroughSpace(nx, ny, img, pt(zoom = zoom, view = view), out)
            val tanY = tan(Math.toRadians(StereoLayout.verticalFovDeg(90f, view) / 2.0)).toFloat()
            assertEquals((nx - 0.5f) * 2f * sx, out[0] / (tanY * view), 1e-5f)
            assertEquals(-(ny - 0.5f) * 2f * sy, out[1] / tanY, 1e-5f)
        }
    }

    @Test fun withoutPassthroughTheOldMappingIsUsed() {
        val out = FloatArray(2)
        HandMapping.passthrough = null
        HandMapping.headSpace(0.5f, 0.5f, 4f / 3f, out)
        assertEquals(0f, out[0], 1e-6f); assertEquals(0f, out[1], 1e-6f)
        HandMapping.passthrough = pt()
        HandMapping.headSpace(1f, 0.5f, 4f / 3f, out)
        assertTrue(out[0] > 0.9f)                                             // agora usa o enquadramento da imagem
    }

    // ---------------- alcance do menu agarrado ----------------
    @Test fun grabbedMenuNeverLeavesTheComfortCone() {
        for (layout in listOf(0.6f, 1.0f, 1.3f, 1.8f)) {
            val ax = PanelLayout.maxAx(layout); val ay = PanelLayout.maxAy(layout)
            assertEquals(45.0, Math.toDegrees(atan((ax * layout / 2f).toDouble())), 0.01)
            assertEquals(35.0, Math.toDegrees(atan((ay * layout / 2f).toDouble())), 0.1)
        }
    }

    @Test fun menuCanBePlacedLeftRightUpAndDown() {
        val layout = 1.3f
        // padrão (centro) e os quatro extremos continuam dentro do campo de visão
        for ((ax, ay) in listOf(0f to 0.1f, -PanelLayout.maxAx(layout) to 0f, PanelLayout.maxAx(layout) to 0f,
            0f to PanelLayout.maxAy(layout), 0f to -PanelLayout.maxAy(layout))) {
            val g = PanelLayout.geo(ax, ay, 2f, 1.125f, 1f, 1.25f, 1.3f, 1f)
            assertEquals(-1.25f, g.cz, 1e-6f)                                  // distância constante e confortável
            assertTrue(Math.toDegrees(atan((Math.abs(g.cx) / 1.25f).toDouble())) <= 45.01)
            assertTrue(Math.toDegrees(atan((Math.abs(g.cy) / 1.25f).toDouble())) <= 35.1)
        }
    }

    // ---------------- ambiente Minha Casa ----------------
    @Test fun homeEnvironmentExistsAndIsLast() {
        assertEquals("Minha Casa", Environments.NAMES[Environments.HOME_INDEX])
        assertEquals(4, Environments.NAMES.size); assertEquals(4, Environments.DESCRIPTIONS.size)
        val env = Environments.build(Environments.HOME_INDEX)
        assertEquals(0, env.triCount)                       // sem geometria própria: o fundo é a câmera
        assertTrue(env.lineCount > 0)                       // grade tênue só enquanto a câmera não chega
    }
}
