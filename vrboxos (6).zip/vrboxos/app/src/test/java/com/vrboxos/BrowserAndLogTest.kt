package com.vrboxos

import com.vrboxos.web.UrlInput
import org.junit.Assert.*
import org.junit.Test

class BrowserAndLogTest {
    @Test fun emptyInputGoesHome() {
        assertEquals(UrlInput.HOME, UrlInput.normalize(""))
        assertEquals(UrlInput.HOME, UrlInput.normalize("   "))
    }

    @Test fun hostsBecomeHttps() {
        assertEquals("https://example.com", UrlInput.normalize("example.com"))
        assertEquals("https://example.com", UrlInput.normalize("  example.com  "))
        assertEquals("https://sub.site.com.br/x?y=1", UrlInput.normalize("sub.site.com.br/x?y=1"))
    }

    @Test fun httpIsUpgradedAndHttpsKept() {
        assertEquals("https://example.com/a", UrlInput.normalize("http://example.com/a"))
        assertEquals("https://example.com/a", UrlInput.normalize("https://example.com/a"))
        assertEquals("https://example.com", UrlInput.normalize("HTTP://example.com").replace("HTTPS", "https"))
    }

    @Test fun plainTextBecomesASearch() {
        assertEquals(UrlInput.SEARCH + "gatos+fofos", UrlInput.normalize("gatos fofos"))
        assertTrue(UrlInput.normalize("clima hoje").startsWith(UrlInput.SEARCH))
        assertTrue(UrlInput.normalize("localhost").startsWith(UrlInput.SEARCH))      // sem ponto: não é host
        assertTrue(UrlInput.normalize("meu site.com").startsWith(UrlInput.SEARCH))   // espaço: pesquisa
        assertTrue(UrlInput.normalize("ola.").startsWith(UrlInput.SEARCH))
    }

    @Test fun dangerousSchemesNeverNavigate() {
        for (s in listOf("javascript:alert(1)", "file:///sdcard/a.html", "data:text/html,<b>x</b>", "intent://x#Intent;end",
            "content://a/b", "ftp://x.com", "mailto:a@b.com", "view-source:https://x.com", "JAVASCRIPT:1")) {
            val r = UrlInput.normalize(s)
            assertTrue("$s -> $r", r.startsWith(UrlInput.SEARCH))
        }
    }

    @Test fun logKeepsOrderAndIsBounded() {
        VrLog.clear()
        VrLog.i("t", "primeira"); VrLog.w("t", "segunda"); VrLog.e("t", "terceira")
        val last = VrLog.last(2)
        assertEquals(2, last.size)
        assertTrue(last[0].contains("W/t: segunda")); assertTrue(last[1].contains("E/t: terceira"))
        repeat(400) { VrLog.i("x", "linha $it") }
        assertEquals(300, VrLog.dump().lines().size)       // buffer circular
        assertTrue(VrLog.dump().contains("linha 399"))
        VrLog.clear()
        assertEquals("", VrLog.dump())
    }
}
