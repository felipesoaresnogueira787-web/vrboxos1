package com.vrboxos

import com.vrboxos.media.VideoFormat
import com.vrboxos.render.SphereMesh
import com.vrboxos.render.StereoLayout
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.atan
import kotlin.math.sqrt
import kotlin.math.tan

class StereoCalibrationTest {
    @Test fun defaultCalibrationFillsEachEyeExactly() {
        for (eye in 0..1) {
            assertArrayEquals(
                StereoLayout.eyeViewport(2000, 1000, eye),
                StereoLayout.calibratedViewport(2000, 1000, eye, 0f, 1f)
            )
        }
    }

    @Test fun eyesAreSideBySideNotStacked() {
        val l = StereoLayout.eyeViewport(2400, 1080, 0)
        val r = StereoLayout.eyeViewport(2400, 1080, 1)
        assertEquals(0, l[0]); assertEquals(1200, r[0])          // esquerda | direita
        assertEquals(l[1], r[1]); assertEquals(1080, l[3])        // mesma altura e mesmo y
        assertEquals(l[2], r[2])
    }

    @Test fun alignmentShiftsBothImagesTheSameWay() {
        val l = StereoLayout.calibratedViewport(2000, 1000, 0, 0.1f, 1f)
        val r = StereoLayout.calibratedViewport(2000, 1000, 1, 0.1f, 1f)
        assertEquals(100, l[0]); assertEquals(1100, r[0])
    }

    @Test fun scaleKeepsCenterAndAspect() {
        val l = StereoLayout.calibratedViewport(2400, 1080, 0, 0f, 0.5f)
        val r = StereoLayout.calibratedViewport(2400, 1080, 1, 0f, 0.5f)
        assertEquals(600, l[2]); assertEquals(540, l[3])
        assertEquals(300, l[0]); assertEquals(270, l[1])          // centrado na metade esquerda
        assertEquals(1500, r[0])                                  // centrado na metade direita
        assertEquals((1200f / 1080f), l[2].toFloat() / l[3], 0.01f) // sem esticar
    }

    @Test fun portraitScreensKeepRequestedHorizontalFov() {
        assertEquals(90f, StereoLayout.verticalFovDeg(90f, 1.78f), 1e-4f)   // paisagem: inalterado
        val fovY = StereoLayout.verticalFovDeg(90f, 0.5f)
        val horizontal = Math.toDegrees(2.0 * atan(tan(Math.toRadians(fovY / 2.0)) * 0.5))
        assertEquals(90.0, horizontal, 0.01)
    }

    private fun uv(m: FloatArray, u: Float, v: Float) = floatArrayOf(m[0] * u + m[12], m[5] * v + m[13])

    @Test fun flatVideoShowsTheSameWholeImageInBothEyes() {
        val m = FloatArray(16)
        for (eye in 0..1) {
            VideoFormat.FLAT.eyeUvMatrix(eye, m)
            assertArrayEquals(floatArrayOf(0f, 0f), uv(m, 0f, 0f), 1e-6f)
            assertArrayEquals(floatArrayOf(1f, 1f), uv(m, 1f, 1f), 1e-6f)
        }
    }

    @Test fun sideBySideGivesEachEyeItsHalf() {
        val m = FloatArray(16)
        VideoFormat.SBS.eyeUvMatrix(0, m)
        assertArrayEquals(floatArrayOf(0f, 0f), uv(m, 0f, 0f), 1e-6f)
        assertArrayEquals(floatArrayOf(0.5f, 1f), uv(m, 1f, 1f), 1e-6f)
        VideoFormat.SBS.eyeUvMatrix(1, m)
        assertArrayEquals(floatArrayOf(0.5f, 0f), uv(m, 0f, 0f), 1e-6f)
        assertArrayEquals(floatArrayOf(1f, 1f), uv(m, 1f, 1f), 1e-6f)
    }

    @Test fun topBottomGivesTopToLeftEye() {
        val m = FloatArray(16)
        VideoFormat.TB.eyeUvMatrix(0, m)      // v para cima: topo = v em [0,5..1]
        assertEquals(0.5f, uv(m, 0f, 0f)[1], 1e-6f); assertEquals(1f, uv(m, 1f, 1f)[1], 1e-6f)
        VideoFormat.TB.eyeUvMatrix(1, m)
        assertEquals(0f, uv(m, 0f, 0f)[1], 1e-6f); assertEquals(0.5f, uv(m, 1f, 1f)[1], 1e-6f)
    }

    @Test fun formatIsNeverAssumedAndCyclesThroughAll() {
        assertFalse(VideoFormat.FLAT.is360)
        assertTrue(VideoFormat.EQ360.is360); assertTrue(VideoFormat.EQ360_TB.is360)
        var f = VideoFormat.FLAT
        val seen = HashSet<VideoFormat>()
        repeat(5) { seen.add(f); f = f.next() }
        assertEquals(5, seen.size); assertEquals(VideoFormat.FLAT, f)
        assertEquals(VideoFormat.EQ360_TB, VideoFormat.FLAT.prev())
        assertEquals(0.5f, VideoFormat.SBS.aspectFactor, 0f); assertEquals(2f, VideoFormat.TB.aspectFactor, 0f)
    }

    @Test fun sphereMeshIsConsistent() {
        val rings = 24; val sectors = 48; val r = 10f
        val m = SphereMesh.build(rings, sectors, r)
        val n = (rings + 1) * (sectors + 1)
        assertEquals(n * 5, m.vertices.size)
        assertEquals(rings * sectors * 6, m.indices.size)
        assertTrue(m.indices.all { it >= 0 && it < n })
        for (i in 0 until n) {
            val x = m.vertices[i * 5]; val y = m.vertices[i * 5 + 1]; val z = m.vertices[i * 5 + 2]
            assertEquals(r, sqrt(x * x + y * y + z * z), 1e-3f)
        }
        // centro da imagem (u=v=0,5) fica à frente (-Z)
        val c = (rings / 2) * (sectors + 1) + sectors / 2
        assertEquals(0f, m.vertices[c * 5], 1e-4f); assertEquals(0f, m.vertices[c * 5 + 1], 1e-4f)
        assertEquals(-r, m.vertices[c * 5 + 2], 1e-3f)
        assertEquals(0.5f, m.vertices[c * 5 + 3], 1e-6f); assertEquals(0.5f, m.vertices[c * 5 + 4], 1e-6f)
        // lado direito da imagem (u>0,5) fica à direita (+X): sem espelhamento
        val right = (rings / 2) * (sectors + 1) + sectors * 3 / 4
        assertTrue(m.vertices[right * 5 + 3] > 0.5f && m.vertices[right * 5] > 0f)
    }
}
