package com.vrboxos

import com.vrboxos.hands.CameraState
import com.vrboxos.head.HeadMath
import com.vrboxos.head.Quat
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI

class HeadTrackingTest {
    private fun fwd(q: Quat) = q.rotate(floatArrayOf(0f, 0f, -1f))
    private val quarter = (PI / 2).toFloat()

    @Test fun gyroYawTurnsTheViewLeft() {
        var q = Quat.IDENTITY
        repeat(10) { q = HeadMath.integrateGyro(q, 0f, quarter, 0f, 0.1f, 0) }   // 90°/s por 1 s
        val f = fwd(q)
        assertEquals(-1f, f[0], 1e-3f); assertEquals(0f, f[1], 1e-3f); assertEquals(0f, f[2], 1e-3f)
    }

    @Test fun gyroAtRestKeepsOrientation() {
        val q = Quat.fromAxisAngle(0f, 1f, 0f, 0.5f)
        assertEquals(q, HeadMath.integrateGyro(q, 0f, 0f, 0f, 0.01f, 0))
        assertEquals(q, HeadMath.integrateGyro(q, 1f, 1f, 1f, 0f, 0))     // dt=0: nada muda
    }

    @Test fun gyroAxesFollowTheDisplayRotation() {
        // ROTATION_90: topo do aparelho à esquerda, eixo X do aparelho = "para cima". Girar em torno dele
        // (positivo) é girar em torno da vertical no sentido anti-horário visto de cima: a visão vai para a esquerda.
        var q = Quat.IDENTITY
        repeat(10) { q = HeadMath.integrateGyro(q, quarter, 0f, 0f, 0.1f, 1) }
        val f = fwd(q)
        assertEquals(-1f, f[0], 1e-3f); assertEquals(0f, f[2], 1e-3f)
    }

    @Test fun gyroKeepsAUnitQuaternion() {
        var q = Quat.IDENTITY
        repeat(2000) { q = HeadMath.integrateGyro(q, 0.3f, -0.2f, 0.5f, 0.005f, 3) }
        assertEquals(1f, q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z, 1e-3f)
    }

    @Test fun cameraIsOnlyFreshWithRecentFrames() {
        Telemetry.lastFrameMs = 0L
        assertFalse(Telemetry.cameraFresh(1000))            // nunca chegou quadro
        Telemetry.lastFrameMs = 900L
        assertTrue(Telemetry.cameraFresh(1000))
        assertFalse(Telemetry.cameraFresh(3000))            // parou de chegar
        Telemetry.lastFrameMs = 0L
    }

    @Test fun cameraStatesAreTheFiveRequested() {
        val labels = CameraState.values().map { it.label }
        assertEquals(5, labels.size); assertEquals(5, labels.toSet().size)
        assertEquals(CameraState.OFF, CameraState.values().first())
        assertTrue("Ativa" in labels && "Inicializando" in labels && "Aguardando permissão" in labels)
    }

    // --- poses físicas reais (usuário olhando ao Norte; ENU: E=(1,0,0) N=(0,1,0) Up=(0,0,1)) ---
    private fun quatFromColumns(x: FloatArray, y: FloatArray, z: FloatArray): Quat {
        val m00 = x[0]; val m10 = x[1]; val m20 = x[2]
        val m01 = y[0]; val m11 = y[1]; val m21 = y[2]
        val m02 = z[0]; val m12 = z[1]; val m22 = z[2]
        val tr = m00 + m11 + m22
        return if (tr > 0f) { val s = Math.sqrt((tr + 1f).toDouble()).toFloat() * 2f; Quat(0.25f * s, (m21 - m12) / s, (m02 - m20) / s, (m10 - m01) / s) }
        else if (m00 > m11 && m00 > m22) { val s = Math.sqrt((1f + m00 - m11 - m22).toDouble()).toFloat() * 2f; Quat((m21 - m12) / s, 0.25f * s, (m01 + m10) / s, (m02 + m20) / s) }
        else if (m11 > m22) { val s = Math.sqrt((1f + m11 - m00 - m22).toDouble()).toFloat() * 2f; Quat((m02 - m20) / s, (m01 + m10) / s, 0.25f * s, (m12 + m21) / s) }
        else { val s = Math.sqrt((1f + m22 - m00 - m11).toDouble()).toFloat() * 2f; Quat((m10 - m01) / s, (m02 + m20) / s, (m12 + m21) / s, 0.25f * s) }
    }

    private val E = floatArrayOf(1f, 0f, 0f); private val U = floatArrayOf(0f, 0f, 1f)
    private val S = floatArrayOf(0f, -1f, 0f)   // direção "para o usuário" (ele olha ao Norte)
    private fun neg(v: FloatArray) = floatArrayOf(-v[0], -v[1], -v[2])

    /** Eixos X,Y,Z do aparelho em ENU para cada rotação do display (tela voltada ao usuário, em pé). */
    private fun pose(rot: Int): Triple<FloatArray, FloatArray, FloatArray> = when (rot) {
        0 -> Triple(E, U, S)                 // retrato
        1 -> Triple(U, neg(E), S)            // paisagem, topo à ESQUERDA (anti-horário)
        2 -> Triple(neg(E), neg(U), S)       // retrato de cabeça para baixo
        else -> Triple(neg(U), E, S)         // paisagem, topo à DIREITA (horário)
    }

    private fun assertUpright(rot: Int) {
        val (x, y, z) = pose(rot)
        val q = HeadMath.sensorToHead(quatFromColumns(x, y, z), rot)
        val f = q.rotate(floatArrayOf(0f, 0f, -1f)); val u = q.rotate(floatArrayOf(0f, 1f, 0f)); val r = q.rotate(floatArrayOf(1f, 0f, 0f))
        assertEquals("frente (rot $rot)", -1f, f[2], 1e-3f); assertEquals(0f, f[0], 1e-3f); assertEquals(0f, f[1], 1e-3f)
        assertEquals("cima (rot $rot)", 1f, u[1], 1e-3f)       // NÃO de cabeça para baixo
        assertEquals("direita (rot $rot)", 1f, r[0], 1e-3f)    // NÃO espelhado
    }

    @Test fun headIsUprightInEveryDisplayRotation() { for (rot in 0..3) assertUpright(rot) }

    @Test fun landscapeWithTheOldSignWouldBeUpsideDown() {
        // Regressão: com o sinal antigo (+1) as duas paisagens saíam giradas 180°.
        for (rot in intArrayOf(1, 3)) {
            val (x, y, z) = pose(rot)
            val q = HeadMath.sensorToHead(quatFromColumns(x, y, z), rot, +1)
            assertEquals(-1f, q.rotate(floatArrayOf(0f, 1f, 0f))[1], 1e-3f)
        }
    }

    @Test fun gravityConfirmsOrCorrectsTheSign() {
        val g = 9.8f
        assertEquals(-1, HeadMath.chooseRemapSign(floatArrayOf(g, 0f, 0f), 1))     // paisagem esquerda
        assertEquals(-1, HeadMath.chooseRemapSign(floatArrayOf(-g, 0f, 0f), 3))    // paisagem direita
        assertNull(HeadMath.chooseRemapSign(floatArrayOf(0f, g, 0f), 0))            // retrato: ambos iguais
        assertNull(HeadMath.chooseRemapSign(floatArrayOf(0f, 0f, g), 1))            // deitado na mesa: indeciso
        assertNull(HeadMath.chooseRemapSign(floatArrayOf(0.5f, 0f, 0f), 1))         // leitura fraca
    }
}
