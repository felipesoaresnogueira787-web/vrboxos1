package com.vrboxos

import com.vrboxos.ar.ArMath
import com.vrboxos.ar.YuvConverter
import com.vrboxos.head.Quat
import com.vrboxos.ui.PanelGroup
import com.vrboxos.ui.PanelPoseMath
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI

class SpatialTrackingTest {
    private val O = floatArrayOf(0f, 0f, 0f)
    private val fb = floatArrayOf(0f, 0f, -1f)
    private fun face(pos: FloatArray, eye: FloatArray = O) = PanelPoseMath.faceTowards(pos, eye, fb)
    private fun normal(q: Quat) = q.rotate(floatArrayOf(0f, 0f, 1f))

    // ---------------- a tela como objeto no espaço ----------------
    @Test fun defaultPanelInFrontFacesTheUser() {
        val q = face(floatArrayOf(0f, 0f, -2f))
        assertEquals(1f, normal(q)[2], 1e-4f)
        val r = PanelPoseMath.intersect(O, floatArrayOf(0f, 0f, -1f), floatArrayOf(0f, 0f, -2f), q, 2f, 1f)!!
        assertEquals(0.5f, r[0], 1e-4f); assertEquals(0.5f, r[1], 1e-4f); assertEquals(2f, r[2], 1e-4f)
    }

    @Test fun panelsCanSitToTheSidesBehindAboveAndBelow() {
        data class C(val pos: FloatArray, val dir: FloatArray)
        val cases = listOf(
            C(floatArrayOf(2f, 0f, 0f), floatArrayOf(1f, 0f, 0f)),            // direita
            C(floatArrayOf(-2f, 0f, 0f), floatArrayOf(-1f, 0f, 0f)),          // esquerda
            C(floatArrayOf(0f, 0f, 2f), floatArrayOf(0f, 0f, 1f)),            // atrás
            C(floatArrayOf(0f, 2f, 0f), floatArrayOf(0f, 1f, 0f)),            // teto
            C(floatArrayOf(0f, -1.5f, -1f), floatArrayOf(0f, -1.5f, -1f))     // perto do chão
        )
        for (c in cases) {
            val q = face(c.pos)
            val n = c.dir.let { d -> val l = Math.sqrt((d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).toDouble()).toFloat(); floatArrayOf(d[0] / l, d[1] / l, d[2] / l) }
            val r = PanelPoseMath.intersect(O, n, c.pos, q, 1f, 1f)
            assertNotNull("deve acertar a face voltada ao usuário em ${c.pos.toList()}", r)
            assertEquals(0.5f, r!![0], 1e-3f); assertEquals(0.5f, r[1], 1e-3f)
            // a normal aponta para os olhos
            val toEye = floatArrayOf(-c.pos[0], -c.pos[1], -c.pos[2])
            val len = Math.sqrt((toEye[0] * toEye[0] + toEye[1] * toEye[1] + toEye[2] * toEye[2]).toDouble()).toFloat()
            val nn = normal(q)
            assertEquals(1f, (nn[0] * toEye[0] + nn[1] * toEye[1] + nn[2] * toEye[2]) / len, 1e-3f)
        }
    }

    @Test fun theBackOfAPanelIsNotHit() {
        val pos = floatArrayOf(2f, 0f, 0f)
        val q = face(pos)
        // raio vindo de trás do painel (de x = 4 para -X) não atinge a face
        assertNull(PanelPoseMath.intersect(floatArrayOf(4f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), pos, q, 1f, 1f))
    }

    @Test fun walkingTowardAFixedPanelMakesItCloserWithoutMovingIt() {
        val panel = floatArrayOf(0f, 0f, -2f)                      // posição no mundo: NÃO muda
        val head = Quat.IDENTITY
        assertEquals(-2f, PanelPoseMath.toView(head, floatArrayOf(0f, 0f, 0f), panel)[2], 1e-5f)
        assertEquals(-1f, PanelPoseMath.toView(head, floatArrayOf(0f, 0f, -1f), panel)[2], 1e-5f)   // andou 1 m para a frente
        assertEquals(-3f, PanelPoseMath.toView(head, floatArrayOf(0f, 0f, 1f), panel)[2], 1e-5f)    // andou 1 m para trás
        assertArrayEquals(floatArrayOf(0f, 0f, -2f), panel, 0f)
    }

    @Test fun viewDistanceDoesNotDependOnHeadRotation() {
        val panel = floatArrayOf(1f, 0.5f, -2f); val eye = floatArrayOf(0.3f, 0f, -0.4f)
        val d = PanelPoseMath.distance(eye, panel)
        for (a in listOf(0f, 0.8f, 2.5f, -1.7f)) {
            val v = PanelPoseMath.toView(Quat.fromAxisAngle(0f, 1f, 0f, a), eye, panel)
            assertEquals(d, Math.sqrt((v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).toDouble()).toFloat(), 1e-4f)
        }
    }

    @Test fun pointingRayStartsAtTheEyesAndSeesTheCloserPanelAtTheSamePlace() {
        val pos = floatArrayOf(0f, 0f, -2f); val q = face(pos)
        val near = floatArrayOf(0f, 0f, -1f)                       // o usuário andou 1 m para a frente
        val r = PanelPoseMath.intersect(near, floatArrayOf(0f, 0f, -1f), pos, q, 2f, 1f)!!
        assertEquals(1f, r[2], 1e-4f)                              // agora a 1 m (antes 2 m)
        assertEquals(0.5f, r[0], 1e-4f)
    }

    @Test fun panelGroupFollowsTheTargetSmoothlyAndStays() {
        val g = PanelGroup()
        assertFalse(g.placed)
        g.setTarget(floatArrayOf(1f, 2f, -3f), Quat.fromAxisAngle(0f, 1f, 0f, 1f))
        assertEquals(0f, g.p[0], 0f)                               // ainda não se moveu
        repeat(40) { g.step(0.3f) }
        assertEquals(1f, g.p[0], 1e-3f); assertEquals(2f, g.p[1], 1e-3f); assertEquals(-3f, g.p[2], 1e-3f)
        assertEquals(1f, Quat.fromAxisAngle(0f, 1f, 0f, 1f).dot(g.q), 1e-3f)
        val before = g.p.copyOf()
        repeat(100) { g.step(0.3f) }                               // sem novo alvo: permanece
        assertArrayEquals(before, g.p, 1e-4f)
    }

    // ---------------- alinhamento ARCore x giroscópio ----------------
    @Test fun yawAlignmentRecoversTheRotationBetweenWorlds() {
        val fAr = floatArrayOf(0.3f, 0.1f, -0.9f).let { v -> val l = Math.sqrt((v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).toDouble()).toFloat(); floatArrayOf(v[0] / l, v[1] / l, v[2] / l) }
        for (psi in listOf(0.7f, -2.5f, 3.0f, 1.2f, 0f)) {
            val fGl = Quat.fromAxisAngle(0f, 1f, 0f, psi).rotate(fAr)
            assertEquals(psi.toDouble(), ArMath.measureYaw(fAr, fGl).toDouble(), 1e-3)
        }
    }

    @Test fun wrapAndSmoothingAreCircular() {
        assertEquals(-3.0, ArMath.wrapPi(2f * PI.toFloat() - 3f).toDouble(), 1e-4)
        // atravessando ±π o ajuste vai pelo caminho curto, sem dar a volta
        val v = ArMath.updateYaw(3.1f, -3.1f, 0.5f, false)
        assertTrue(Math.abs(Math.abs(v) - PI) < 0.1)
        assertEquals(1.0, ArMath.updateYaw(0f, 1f, 0.05f, true).toDouble(), 0.0)    // primeira medida entra inteira
        assertFalse(ArMath.usable(floatArrayOf(0f, 0.95f, -0.3f)))                  // olhando para cima: guinada indefinida
        assertTrue(ArMath.usable(floatArrayOf(0f, 0.2f, -1f)))
    }

    @Test fun positionsRoundTripBetweenArAndRenderWorlds() {
        val q = Quat.fromAxisAngle(0f, 1f, 0f, 0.4f) * ArMath.yawQuat(0.7f)
        val origin = floatArrayOf(1f, 2f, 3f); val pa = floatArrayOf(4f, 1f, -2f)
        val back = ArMath.toAr(ArMath.toRender(pa, origin, q), origin, q)
        assertArrayEquals(pa, back, 1e-4f)
        val qa = Quat.fromAxisAngle(1f, 0f, 0f, 0.3f)
        assertEquals(1f, qa.dot(ArMath.quatToAr(ArMath.quatToRender(qa, q), q)), 1e-4f)
        // a origem do ARCore vira a origem do mundo de renderização
        assertArrayEquals(floatArrayOf(0f, 0f, 0f), ArMath.toRender(origin, origin, q), 1e-6f)
    }

    @Test fun cpuImageRotationFollowsSensorAndDisplay() {
        assertEquals(90, ArMath.imageRotation(90, 0, 0))
        assertEquals(0, ArMath.imageRotation(90, 1, 0))          // paisagem: a imagem já está em pé
        assertEquals(270, ArMath.imageRotation(90, 2, 0))
        assertEquals(180, ArMath.imageRotation(90, 3, 0))        // paisagem invertida
        assertEquals(90, ArMath.imageRotation(90, 1, 1))         // ajuste manual +90°
    }

    // ---------------- YUV -> ARGB girado ----------------
    private fun gray(v: Int) = (0xFF shl 24) or (v shl 16) or (v shl 8) or v

    private fun run(rot: Int): IntArray {
        val w = 4; val h = 2
        val y = ByteArray(8) { (it * 10).toByte() }
        val c = ByteArray(2) { 128.toByte() }
        val out = IntArray(w * h)
        YuvConverter.toArgb(w, h, y, 4, c, 2, 1, c, 2, 1, rot, out)
        return out
    }

    @Test fun grayImageKeepsLumaAndRotatesClockwise() {
        val a = run(0); for (i in 0 until 8) assertEquals(gray(i * 10), a[i])
        val b = run(90)                                         // saída 2x4
        assertEquals(gray(40), b[0]); assertEquals(gray(0), b[1]); assertEquals(gray(30), b[7]); assertEquals(gray(70), b[6])
        val c = run(180); assertEquals(gray(70), c[0]); assertEquals(gray(0), c[7])
        val d = run(270); assertEquals(gray(30), d[0]); assertEquals(gray(70), d[1]); assertEquals(gray(0), d[6]); assertEquals(gray(40), d[7])
        assertEquals(2, YuvConverter.outW(4, 2, 90)); assertEquals(4, YuvConverter.outH(4, 2, 90))
        assertEquals(4, YuvConverter.outW(4, 2, 180))
    }

    @Test fun colorsAreConvertedAndInterleavedChromaIsRead() {
        // 2x2, um único par U/V intercalado (pixelStride 2, como no Android)
        val y = ByteArray(4) { 76 }
        val uv = byteArrayOf(84.toByte(), 255.toByte())          // U, V (vermelho)
        val v = uv.copyOfRange(1, 2)
        val out = IntArray(4)
        YuvConverter.toArgb(2, 2, y, 2, uv, 2, 2, v, 2, 2, 0, out)
        for (p in out) {
            assertEquals(0xFF, p ushr 24)
            assertEquals(254.0, ((p shr 16) and 0xFF).toDouble(), 3.0)
            assertEquals(1.0, ((p shr 8) and 0xFF).toDouble(), 3.0)
            assertEquals(0.0, (p and 0xFF).toDouble(), 3.0)
        }
        // branco
        val w = IntArray(4)
        YuvConverter.toArgb(2, 2, ByteArray(4) { 255.toByte() }, 2, byteArrayOf(128.toByte()), 1, 1, byteArrayOf(128.toByte()), 1, 1, 0, w)
        for (p in w) assertEquals(gray(255), p)
    }
}
