package com.vrboxos.ui

import com.vrboxos.head.Quat
import kotlin.math.abs
import kotlin.math.sqrt

/** Painel plano em z = cz (negativo, na frente do usuário), centro (cx,cy), tamanho (w,h) em metros. */
data class PanelGeo(val cx: Float, val cy: Float, val cz: Float, val w: Float, val h: Float)

/** Posição/tamanho reais (em metros) de um painel no ambiente 3D, a partir do layout base e dos ajustes. */
object PanelLayout {
    /** Plano de referência (m) em que as posições base (ax, ay) dos painéis foram desenhadas. */
    const val REFERENCE_DISTANCE = 2f

    /**
     * [distance]: distância real do painel ao usuário (z = -distance).
     * [panelScale] * [layoutFactor]: escala do LAYOUT inteiro (posições e tamanhos juntos, para painéis
     * maiores não se sobreporem). [userScale]: escala individual (duas mãos / botões de tamanho).
     */
    /**
     * Limites do CENTRO de um painel (coordenadas base) para que ele nunca saia de um cone confortável em
     * volta da frente: 45° na horizontal e 35° na vertical. Como tan(ângulo) = ax * layout / 2, o menu não
     * pode ser jogado para fora do alcance nem desaparecer.
     */
    fun maxAx(layout: Float) = 2f * 1.0f / layout
    fun maxAy(layout: Float) = 2f * 0.70f / layout

    fun geo(
        ax: Float, ay: Float, baseW: Float, baseH: Float, userScale: Float,
        distance: Float, panelScale: Float, layoutFactor: Float
    ): PanelGeo {
        val k = distance / REFERENCE_DISTANCE
        val layout = panelScale * layoutFactor
        val sc = layout * userScale
        return PanelGeo(ax * k * layout, ay * k * layout, -REFERENCE_DISTANCE * k, baseW * k * sc, baseH * k * sc)
    }
}

object PanelGeometry {
    /**
     * Raio partindo da origem com direção (dx,dy,dz). Retorna (u,v) em [0,1] (v=0 no topo)
     * se atinge o painel; null caso contrário (fora, ou raio apontando para trás).
     */
    fun intersect(dx: Float, dy: Float, dz: Float, g: PanelGeo): FloatArray? {
        if (dz >= -1e-4f) return null
        val t = g.cz / dz
        val hx = dx * t
        val hy = dy * t
        val u = (hx - g.cx) / g.w + 0.5f
        val v = 0.5f - (hy - g.cy) / g.h
        if (u < 0f || u > 1f || v < 0f || v > 1f) return null
        return floatArrayOf(u, v)
    }
}

/** Pose de um painel no mundo de renderização: centro [c], orientação [q] (normal = +Z local) e tamanho em metros. */
class PanelPose(val c: FloatArray, val q: Quat, val w: Float, val h: Float) {
    /** Ponto do painel em coordenadas locais (lx, ly no plano; lz para fora, em direção ao observador). */
    fun at(lx: Float, ly: Float, lz: Float): FloatArray {
        val v = q.rotate(floatArrayOf(lx, ly, lz))
        return floatArrayOf(c[0] + v[0], c[1] + v[1], c[2] + v[2])
    }
}

/** Matemática do painel como OBJETO NO ESPAÇO (independente do cubo/ambiente e da cabeça). Pura. */
object PanelPoseMath {
    fun distance(a: FloatArray, b: FloatArray): Float {
        val x = a[0] - b[0]; val y = a[1] - b[1]; val z = a[2] - b[2]
        return sqrt(x * x + y * y + z * z)
    }

    private fun cross(a: FloatArray, b: FloatArray) =
        floatArrayOf(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])

    private fun norm(v: FloatArray): FloatArray {
        val n = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
        return if (n < 1e-6f) floatArrayOf(0f, 0f, 0f) else floatArrayOf(v[0] / n, v[1] / n, v[2] / n)
    }

    /**
     * Raio (origem [o], direção [d]) contra o painel de centro [c], orientação [q] e tamanho w×h.
     * Retorna [u, v, t] (u,v em 0..1 com v=0 no topo; t = distância ao longo do raio) ou null.
     * Só acerta a face voltada para o observador.
     */
    fun intersect(o: FloatArray, d: FloatArray, c: FloatArray, q: Quat, w: Float, h: Float): FloatArray? {
        val inv = q.conjugate()
        val lo = inv.rotate(floatArrayOf(o[0] - c[0], o[1] - c[1], o[2] - c[2]))
        val ld = inv.rotate(d)
        if (ld[2] >= -1e-4f) return null
        val t = -lo[2] / ld[2]
        if (t <= 0f) return null
        val hx = lo[0] + ld[0] * t
        val hy = lo[1] + ld[1] * t
        val u = hx / w + 0.5f
        val v = 0.5f - hy / h
        if (u < 0f || u > 1f || v < 0f || v > 1f) return null
        return floatArrayOf(u, v, t)
    }

    /**
     * Orientação de um painel em [pos] com a face voltada para [eye], mantendo o "cima" do mundo.
     * Funciona em qualquer altura (chão, laterais, atrás, teto); quando o observador está quase na vertical
     * do painel usa [fallbackUp] para evitar a indefinição do "cima".
     */
    fun faceTowards(pos: FloatArray, eye: FloatArray, fallbackUp: FloatArray): Quat {
        val z = norm(floatArrayOf(eye[0] - pos[0], eye[1] - pos[1], eye[2] - pos[2]))
        if (z[0] == 0f && z[1] == 0f && z[2] == 0f) return Quat.IDENTITY
        val up = if (abs(z[1]) > 0.98f) fallbackUp else floatArrayOf(0f, 1f, 0f)
        var x = norm(cross(up, z))
        if (x[0] == 0f && x[1] == 0f && x[2] == 0f) x = floatArrayOf(1f, 0f, 0f)
        val y = cross(z, x)
        return Quat.fromAxes(x, y, z)
    }

    /** Posição de um ponto do mundo no referencial da cabeça (o que a matriz de visão faz). */
    fun toView(headQ: Quat, eye: FloatArray, p: FloatArray): FloatArray =
        headQ.conjugate().rotate(floatArrayOf(p[0] - eye[0], p[1] - eye[1], p[2] - eye[2]))
}
