package com.vrboxos

import android.util.Log
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Registro de eventos do app: vai para o logcat (tag VRBOX-*) e para um buffer circular visível no
 * app (Diagnóstico > Log), que pode ser compartilhado. Serve para achar QUAL componente altera a
 * orientação, a câmera ou o rastreio quando algo dá errado.
 */
object VrLog {
    private val buf = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private const val MAX = 300

    @Synchronized
    fun add(level: Char, tag: String, msg: String, t: Throwable? = null) {
        val line = "${fmt.format(Date())} $level/$tag: $msg" + (if (t != null) " [${t.javaClass.simpleName}: ${t.message}]" else "")
        buf.addLast(line)
        while (buf.size > MAX) buf.removeFirst()
        try {
            when (level) {
                'E' -> Log.e("VRBOX-$tag", msg, t)
                'W' -> Log.w("VRBOX-$tag", msg, t)
                else -> Log.i("VRBOX-$tag", msg)
            }
        } catch (_: Throwable) { /* testes JVM sem Android */ }
    }

    fun i(tag: String, msg: String) = add('I', tag, msg)
    fun w(tag: String, msg: String, t: Throwable? = null) = add('W', tag, msg, t)
    fun e(tag: String, msg: String, t: Throwable? = null) = add('E', tag, msg, t)

    @Synchronized fun last(n: Int): List<String> = buf.toList().takeLast(n)
    @Synchronized fun dump(): String = buf.joinToString("\n")
    @Synchronized fun clear() = buf.clear()
}
