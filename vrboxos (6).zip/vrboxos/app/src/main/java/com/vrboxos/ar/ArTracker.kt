package com.vrboxos.ar

import android.content.Context
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.Image
import android.os.SystemClock
import androidx.activity.ComponentActivity
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingFailureReason
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.vrboxos.Telemetry
import com.vrboxos.VrLog
import com.vrboxos.head.HeadPose
import com.vrboxos.head.Quat
import com.vrboxos.settings.Settings
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Rastreamento ESPACIAL real (posição + orientação do aparelho, pontos de referência, superfícies e âncoras)
 * pelo ARCore. Todo o uso da API do ARCore fica neste arquivo.
 *
 * Papel de cada sensor:
 *  - ORIENTAÇÃO da visão: continua vindo do giroscópio (taxa alta, baixa latência).
 *  - POSIÇÃO da cabeça: vem do ARCore (visual-inercial, em metros). Os dois referenciais são alinhados pela
 *    guinada medida entre as duas orientações (ArMath).
 *  - ÂNCORAS: mantêm a tela no ponto físico onde foi solta; o ARCore as corrige quando refina o mapa.
 *
 * O ARCore ocupa a câmera: no modo espacial os quadros do reconhecimento de mãos e da imagem de "Minha Casa"
 * vêm daqui (imagem de CPU convertida em segundo plano), não do CameraX.
 *
 * Limites: precisa de aparelho compatível e do "Google Play Services for AR"; usa a câmera TRASEIRA (que o
 * headset pode tampar); exige ambiente iluminado e com textura; a posição é relativa ao início da sessão.
 */
class ArTracker(private val activity: ComponentActivity, private val settings: Settings) {
    enum class Availability { SUPPORTED, NEEDS_INSTALL, UNSUPPORTED, UNKNOWN }
    class AnchorHandle(val anchor: Anchor)

    private val lock = Any()
    private var session: Session? = null
    @Volatile var running = false
        private set

    private var texId = 0
    private var texDirty = true
    private var geomW = 0
    private var geomH = 0
    private var geomRot = -1
    private var lastFrameTs = 0L
    private var originAr: FloatArray? = null
    private var psi = 0f
    private var psiInit = false
    @Volatile private var qAr2R: Quat = Quat.IDENTITY
    private var lastStatsMs = 0L
    private var sensorOrientation = 90

    /** Recebe imagens verticais para o reconhecimento de mãos (ligado pelo HandPipeline). */
    @Volatile var sink: ((Bitmap, Long) -> Unit)? = null

    private val convWorker = Executors.newSingleThreadExecutor { r -> Thread(r, "vrbox-ar-yuv") }
    private val converting = AtomicBoolean(false)
    private val pool = arrayOfNulls<Bitmap>(4)
    private var poolIdx = 0

    // ------------------------------------------------------------------ disponibilidade / instalação

    fun availability(): Availability = try {
        val a = ArCoreApk.getInstance().checkAvailability(activity)
        when {
            a.isTransient -> Availability.UNKNOWN
            a == ArCoreApk.Availability.SUPPORTED_INSTALLED -> Availability.SUPPORTED
            a == ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD || a == ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED -> Availability.NEEDS_INSTALL
            else -> Availability.UNSUPPORTED
        }
    } catch (e: Exception) {
        VrLog.w("ar", "checkAvailability falhou", e)
        Availability.UNKNOWN
    }

    /** Pede a instalação/atualização do "Google Play Services for AR". true se já está instalado. */
    fun requestInstall(): Boolean = try {
        ArCoreApk.getInstance().requestInstall(activity, true) == ArCoreApk.InstallStatus.INSTALLED
    } catch (e: Exception) {
        VrLog.w("ar", "requestInstall falhou", e)
        false
    }

    // ------------------------------------------------------------------ ciclo de vida (thread principal)

    private fun configure(s: Session) {
        val c = Config(s)
        c.setUpdateMode(Config.UpdateMode.LATEST_CAMERA_IMAGE)           // update() NÃO bloqueia a renderização
        c.setPlaneFindingMode(Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL)
        c.setLightEstimationMode(Config.LightEstimationMode.DISABLED)
        c.setFocusMode(Config.FocusMode.AUTO)
        s.configure(c)
    }

    /** Cria/retoma a sessão. A câmera passa a pertencer ao ARCore. */
    fun start(onError: (String) -> Unit): Boolean = synchronized(lock) {
        try {
            val s = session ?: Session(activity).also { session = it; configure(it) }
            s.resume()
            readSensorOrientation(s)
            running = true
            texDirty = true
            geomRot = -1
            lastFrameTs = 0L
            Telemetry.arStatus = "Iniciando"
            VrLog.i("ar", "sessão retomada; sensor=$sensorOrientation")
            true
        } catch (e: Exception) {
            running = false
            VrLog.e("ar", "não foi possível iniciar o ARCore", e)
            Telemetry.arStatus = "Erro: ${e.javaClass.simpleName}"
            onError("ARCore: ${e.javaClass.simpleName} ${e.message ?: ""}".trim())
            false
        }
    }

    fun pause() {
        synchronized(lock) {
            running = false
            Telemetry.arTracking = false
            try { session?.pause() } catch (e: Exception) { VrLog.w("ar", "pause falhou", e) }
            if (Telemetry.arStatus != "Desligado") Telemetry.arStatus = "Pausado"
        }
    }

    /** Desliga de vez (também zera a origem: uma nova sessão começa em um mundo novo). */
    fun close() {
        synchronized(lock) {
            running = false
            Telemetry.arTracking = false
            try { session?.close() } catch (e: Exception) { VrLog.w("ar", "close falhou", e) }
            session = null
            originAr = null; psiInit = false
            Telemetry.arStatus = "Desligado"
        }
    }

    private fun readSensorOrientation(s: Session) {
        try {
            val id = s.cameraConfig.cameraId
            val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            sensorOrientation = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        } catch (e: Exception) {
            VrLog.w("ar", "não li SENSOR_ORIENTATION; usando 90", e)
            sensorOrientation = 90
        }
    }

    /** Textura OES (criada na thread GL) onde o ARCore escreve a imagem da câmera. */
    fun setTexture(id: Int) { texId = id; texDirty = true }

    // ------------------------------------------------------------------ por quadro (thread GL)

    /**
     * Atualiza a posição da cabeça em [head] e entrega a imagem da câmera ao reconhecimento.
     * [displayRotation]: Surface.ROTATION_* (0..3); [viewW]/[viewH]: tamanho da vista de um olho.
     */
    fun update(head: HeadPose, displayRotation: Int, viewW: Int, viewH: Int) {
        if (!running || texId == 0) return
        synchronized(lock) { updateLocked(head, displayRotation, viewW, viewH) }
    }

    private fun updateLocked(head: HeadPose, displayRotation: Int, viewW: Int, viewH: Int) {
        val s = session
        if (s == null || !running) return
        try {
            if (texDirty) { s.setCameraTextureName(texId); texDirty = false }
            if (displayRotation != geomRot || viewW != geomW || viewH != geomH) {
                s.setDisplayGeometry(displayRotation, viewW, viewH)
                geomRot = displayRotation; geomW = viewW; geomH = viewH
            }
            handleFrame(s, s.update(), head, displayRotation)
        } catch (e: CameraNotAvailableException) {
            running = false
            Telemetry.arStatus = "Câmera indisponível"
            VrLog.e("ar", "câmera indisponível para o ARCore", e)
        } catch (e: Exception) {
            Telemetry.arStatus = "Erro: ${e.javaClass.simpleName}"
            VrLog.e("ar", "update falhou", e)
        }
    }

    private fun reasonText(r: TrackingFailureReason) = when (r.name) {
        "INSUFFICIENT_LIGHT" -> "pouca luz"
        "EXCESSIVE_MOTION" -> "movimento rápido demais"
        "INSUFFICIENT_FEATURES" -> "pouca textura visível"
        "CAMERA_UNAVAILABLE" -> "câmera indisponível"
        "BAD_STATE" -> "estado inválido"
        else -> "aguardando"
    }

    private fun handleFrame(s: Session, frame: Frame, head: HeadPose, displayRotation: Int) {
        val cam = frame.camera
        val state = cam.trackingState
        val tracking = state == TrackingState.TRACKING
        Telemetry.arTracking = tracking
        Telemetry.arStatus = when {
            tracking -> "Rastreando (posição + rotação)"
            state == TrackingState.PAUSED -> "Perdido: ${reasonText(cam.trackingFailureReason)}"
            else -> "Parado"
        }
        if (tracking) updatePose(cam.displayOrientedPose, head)

        if (frame.timestamp != lastFrameTs) {
            lastFrameTs = frame.timestamp
            acquireImage(frame, displayRotation)
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastStatsMs > 500) {
            lastStatsMs = now
            try {
                Telemetry.arPlanes = s.getAllTrackables(Plane::class.java)
                    .count { it.trackingState == TrackingState.TRACKING && it.subsumedBy == null }
            } catch (_: Exception) {}
            try {
                val pc = frame.acquirePointCloud()
                Telemetry.arPoints = pc.points.remaining() / 4
                pc.release()
            } catch (_: Exception) {}
        }
    }

    private fun updatePose(pose: Pose, head: HeadPose) {
        val t = floatArrayOf(pose.tx(), pose.ty(), pose.tz())
        val qa = Quat(pose.qw(), pose.qx(), pose.qy(), pose.qz())
        val origin = originAr ?: t.copyOf().also { originAr = it }

        // Alinhamento de guinada entre o giroscópio e o ARCore (ambos têm a gravidade como "cima").
        val fAr = qa.rotate(floatArrayOf(0f, 0f, -1f))
        val fGl = head.raw.rotate(floatArrayOf(0f, 0f, -1f))
        if (ArMath.usable(fAr) && ArMath.usable(fGl)) {
            psi = ArMath.updateYaw(psi, ArMath.measureYaw(fAr, fGl), 0.05f, !psiInit)
            psiInit = true
        }
        if (!psiInit) return                                       // sem alinhamento ainda: não publica posição
        val q = (head.yawFix * ArMath.yawQuat(psi)).normalized()
        qAr2R = q
        val cam = ArMath.toRender(t, origin, q)
        // Os olhos ficam um pouco atrás da câmera (em direção ao rosto): estimativa fixa, não calibrada.
        val back = head.worldOrientation().rotate(floatArrayOf(0f, 0f, EYE_BACK_M))
        val p = floatArrayOf(cam[0] + back[0], cam[1] + back[1], cam[2] + back[2])
        head.position = p
        Telemetry.arX = p[0]; Telemetry.arY = p[1]; Telemetry.arZ = p[2]
    }

    // ------------------------------------------------------------------ imagem para o reconhecimento

    private fun acquireImage(frame: Frame, displayRotation: Int) {
        val cb = sink ?: return
        if (!converting.compareAndSet(false, true)) return       // conversor ocupado: pula, só o quadro mais novo importa
        val img: Image = try {
            frame.acquireCameraImage()
        } catch (e: Exception) {                                  // ainda não disponível nos primeiros quadros
            converting.set(false)
            return
        }
        val ts = SystemClock.elapsedRealtime()
        val rot = ArMath.imageRotation(sensorOrientation, displayRotation, settings.arRotOffset)
        Telemetry.arImageRotation = rot
        convWorker.execute {
            try {
                convert(img, rot, ts, cb)
            } catch (e: Exception) {
                VrLog.e("ar", "conversão YUV falhou", e)
            } finally {
                try { img.close() } catch (_: Exception) {}
                converting.set(false)
            }
        }
    }

    private fun nextBitmap(w: Int, h: Int): Bitmap {
        val i = poolIdx
        poolIdx = (poolIdx + 1) % pool.size
        val b = pool[i]
        if (b != null && !b.isRecycled && b.width == w && b.height == h) return b
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        pool[i] = nb
        return nb
    }

    private fun convert(img: Image, rot: Int, ts: Long, cb: (Bitmap, Long) -> Unit) {
        val w = img.width
        val h = img.height
        val pl = img.planes
        fun bytes(i: Int): ByteArray { val b = pl[i].buffer; val a = ByteArray(b.remaining()); b.get(a); return a }
        val y = bytes(0); val u = bytes(1); val v = bytes(2)
        val ow = YuvConverter.outW(w, h, rot)
        val oh = YuvConverter.outH(w, h, rot)
        val out = IntArray(ow * oh)
        YuvConverter.toArgb(w, h, y, pl[0].rowStride, u, pl[1].rowStride, pl[1].pixelStride, v, pl[2].rowStride, pl[2].pixelStride, rot, out)
        val bmp = nextBitmap(ow, oh)
        bmp.setPixels(out, 0, ow, 0, 0, ow, oh)
        cb(bmp, ts)
    }

    // ------------------------------------------------------------------ âncoras

    /** Cria uma âncora no ponto/orientação (referencial de renderização). null se não está rastreando. */
    fun createAnchor(posR: FloatArray, qR: Quat): AnchorHandle? = synchronized(lock) {
        val s = session
        val o = originAr
        if (s == null || o == null || !Telemetry.arTracking) null
        else try {
            val q = qAr2R
            val pa = ArMath.toAr(posR, o, q)
            val qa = ArMath.quatToAr(qR, q)
            val h = AnchorHandle(s.createAnchor(Pose(pa, floatArrayOf(qa.x, qa.y, qa.z, qa.w))))
            Telemetry.arAnchors++
            h
        } catch (e: Exception) {
            VrLog.w("ar", "não foi possível criar a âncora", e)
            null
        }
    }

    /** Pose atual da âncora (referencial de renderização), ou null se ela não está sendo rastreada. */
    fun anchorPoseR(h: AnchorHandle): Pair<FloatArray, Quat>? = synchronized(lock) {
        val o = originAr
        if (o == null || h.anchor.trackingState != TrackingState.TRACKING) null
        else {
            val p = h.anchor.pose
            val q = qAr2R
            Pair(
                ArMath.toRender(floatArrayOf(p.tx(), p.ty(), p.tz()), o, q),
                ArMath.quatToRender(Quat(p.qw(), p.qx(), p.qy(), p.qz()), q)
            )
        }
    }

    fun detach(h: AnchorHandle) {
        try { h.anchor.detach(); if (Telemetry.arAnchors > 0) Telemetry.arAnchors-- } catch (_: Exception) {}
    }

    companion object {
        /** Distância estimada da câmera traseira aos olhos (m). Não calibrada. */
        const val EYE_BACK_M = 0.07f
    }
}
