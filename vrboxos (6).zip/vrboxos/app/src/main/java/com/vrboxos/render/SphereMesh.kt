package com.vrboxos.render

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Esfera para vídeo 360° equiretangular, vista de dentro. O centro da imagem (u=0,5 v=0,5) fica
 * à frente (-Z); u cresce para a direita; v cresce para cima.
 * Vértices: x,y,z,u,v (5 floats).
 */
object SphereMesh {
    class Mesh(val vertices: FloatArray, val indices: ShortArray)

    fun build(rings: Int = 24, sectors: Int = 48, radius: Float = 10f): Mesh {
        val v = FloatArray((rings + 1) * (sectors + 1) * 5)
        var o = 0
        for (i in 0..rings) {
            val lat = (i.toFloat() / rings - 0.5f) * PI.toFloat()          // -90°..+90°
            for (j in 0..sectors) {
                val lon = (j.toFloat() / sectors - 0.5f) * 2f * PI.toFloat() // -180°..+180°
                v[o++] = radius * cos(lat) * sin(lon)
                v[o++] = radius * sin(lat)
                v[o++] = -radius * cos(lat) * cos(lon)
                v[o++] = j.toFloat() / sectors
                v[o++] = i.toFloat() / rings
            }
        }
        val idx = ShortArray(rings * sectors * 6)
        var k = 0
        for (i in 0 until rings) for (j in 0 until sectors) {
            val a = (i * (sectors + 1) + j).toShort()
            val b = (a + sectors + 1).toShort()
            idx[k++] = a; idx[k++] = b; idx[k++] = (a + 1).toShort()
            idx[k++] = (a + 1).toShort(); idx[k++] = b; idx[k++] = (b + 1).toShort()
        }
        return Mesh(v, idx)
    }
}
