package com.vrboxos.web

import java.net.URLEncoder

/** Converte o que o usuário digitou em uma URL HTTPS ou em uma pesquisa. Puro: testável na JVM. */
object UrlInput {
    const val HOME = "https://duckduckgo.com/"
    const val SEARCH = "https://duckduckgo.com/?q="

    /** Esquemas que nunca devem virar navegação (viram texto de pesquisa). */
    private val blocked = Regex("^(javascript|file|data|intent|content|blob|about|view-source|ftp|mailto|tel|sms):", RegexOption.IGNORE_CASE)

    fun normalize(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return HOME
        if (blocked.containsMatchIn(t)) return SEARCH + enc(t)
        if (t.startsWith("https://", ignoreCase = true)) return t
        if (t.startsWith("http://", ignoreCase = true)) return "https://" + t.substring(7)   // só HTTPS
        val looksLikeHost = t.none { it.isWhitespace() } && t.contains('.') && !t.startsWith(".") && !t.endsWith(".")
        return if (looksLikeHost) "https://$t" else SEARCH + enc(t)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
