package com.vrboxos.render

/** Geometria estereoscópica lado a lado (esquerdo = 0, direito = 1). */
object StereoLayout {
    /** Retorna [x, y, largura, altura] do olho. */
    fun eyeViewport(totalW: Int, totalH: Int, eye: Int): IntArray {
        val half = totalW / 2
        return intArrayOf(if (eye == 0) 0 else half, 0, half, totalH)
    }

    /**
     * Retângulo onde a imagem de cada olho é desenhada na tela, depois da calibração:
     * [alignX] desloca as duas imagens juntas (fração da largura do olho) e [scale] reduz o
     * tamanho mantendo o centro. O recorte (scissor) continua sendo [eyeViewport], então uma
     * imagem deslocada nunca invade o outro olho. Retorna [x, y, largura, altura].
     */
    fun calibratedViewport(totalW: Int, totalH: Int, eye: Int, alignX: Float, scale: Float): IntArray {
        val half = totalW / 2
        val ex = if (eye == 0) 0 else half
        val w = Math.round(half * scale)
        val h = Math.round(totalH * scale)
        val cx = ex + half / 2f + alignX * half
        return intArrayOf(Math.round(cx - w / 2f), Math.round((totalH - h) / 2f), w, h)
    }

    /** Campo de visão vertical que garante o campo horizontal pedido em telas em pé (aspecto < 1). */
    fun verticalFovDeg(fovDeg: Float, aspect: Float): Float {
        if (aspect >= 1f) return fovDeg
        val t = Math.tan(Math.toRadians(fovDeg / 2.0)) / aspect
        return Math.toDegrees(2.0 * Math.atan(t)).toFloat()
    }

    /**
     * Deslocamento lateral aplicado ao mundo para cada olho, em metros.
     * Olho esquerdo fica em -IPD/2, então o mundo desloca +IPD/2 (e o inverso no direito).
     */
    fun eyeShiftMeters(ipdMm: Float, eye: Int): Float = (if (eye == 0) 1f else -1f) * ipdMm / 2000f
}
