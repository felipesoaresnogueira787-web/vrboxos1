package com.vrboxos.ui

import com.vrboxos.head.Quat

/**
 * Pose (posição + orientação) COMPARTILHADA por todos os painéis ("a tela virtual"): menu, câmera, navegador e
 * cinema aparecem onde a tela foi deixada. A posição renderizada segue a posição-alvo com suavização.
 * Pura (sem Android): testável na JVM.
 */
class PanelGroup {
    val p = FloatArray(3)
    val tp = FloatArray(3)
    var q: Quat = Quat.IDENTITY
    var tq: Quat = Quat.IDENTITY
    /** false = posição padrão (acompanha as configurações); true = o usuário a escolheu (fica onde está). */
    var placed = false
    /** Âncora espacial (ARCore) que mantém a tela no lugar físico; null sem rastreamento espacial. */
    var anchor: Any? = null

    fun setTarget(pos: FloatArray, rot: Quat) {
        tp[0] = pos[0]; tp[1] = pos[1]; tp[2] = pos[2]
        tq = rot
    }

    fun snap() {
        p[0] = tp[0]; p[1] = tp[1]; p[2] = tp[2]
        q = tq
    }

    /** k em 0..1: fração do caminho até o alvo neste passo. */
    fun step(k: Float) {
        for (i in 0..2) p[i] += (tp[i] - p[i]) * k
        q = Quat.nlerp(q, tq, k)
    }
}
