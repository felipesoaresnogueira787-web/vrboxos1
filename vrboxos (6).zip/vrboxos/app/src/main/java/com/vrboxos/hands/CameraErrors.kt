package com.vrboxos.hands

/**
 * Classificação dos códigos de erro do CameraX (`CameraState.StateError.code`), sem depender de constantes
 * da biblioteca. Códigos documentados: 1 limite de câmeras abertas, 2 câmera em uso, 3 erro recuperável
 * (o CameraX tenta de novo sozinho); 4 configuração de stream, 5 desativada por política, 6 erro fatal,
 * 7 modo Não Perturbe (críticos).
 */
object CameraErrors {
    /** true para erros que o CameraX resolve sozinho (não devem derrubar a câmera). */
    fun isRecoverable(code: Int) = code in 1..3

    fun isCritical(code: Int) = !isRecoverable(code)

    fun name(code: Int) = when (code) {
        1 -> "limite de câmeras abertas atingido"
        2 -> "câmera em uso por outro app"
        3 -> "erro recuperável"
        4 -> "configuração de stream não suportada"
        5 -> "câmera desativada por política do aparelho"
        6 -> "erro fatal da câmera"
        7 -> "bloqueada pelo modo Não Perturbe"
        else -> "código $code"
    }
}
