package com.vrboxos

/** Ações que a interface espacial pede ao Activity. */
interface AppController {
    fun pickVideo()
    fun setHandTracking(enable: Boolean)
    fun restartHandSource()
    fun setVrMode(vr: Boolean)
    fun isVrMode(): Boolean
    fun recenter()
    /** Aplica a orientação escolhida (automática/paisagem/invertida) à Activity. */
    fun applyOrientation()
    /** Liga/desliga o registro dos sensores conforme a configuração e o modo (VR ou plano). */
    fun applyHeadTracking()
    /** Liga/desliga o rastreamento espacial (posição) pelo ARCore; sem ele, só rotação. */
    fun setSpatialTracking(enable: Boolean)
    /** Caixa de texto com o teclado do Android (só faz sentido fora do VR: o teclado quebraria a tela dividida). */
    fun promptText(title: String, initial: String, onResult: (String) -> Unit)
    /** Compartilha o log do app (para diagnosticar câmera/orientação). */
    fun shareLog()
    fun exitApp()
}
