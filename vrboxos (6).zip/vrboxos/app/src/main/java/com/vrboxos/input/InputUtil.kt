package com.vrboxos.input

/** Impede cliques repetidos: só libera um novo clique após [lockoutMs]. */
class ClickGuard(private val lockoutMs: Long) {
    private var last = Long.MIN_VALUE / 2
    fun allow(now: Long): Boolean {
        if (now - last < lockoutMs) return false
        last = now
        return true
    }
}

/** Seleção por permanência do olhar. Depois de disparar, exige sair do alvo para rearmar. */
class DwellTracker {
    data class Result(val progress: Float, val fired: Boolean)

    private var target: String? = null
    private var since = 0L
    private var armed = true

    fun update(t: String?, now: Long, dwellMs: Long): Result {
        if (t != target) { target = t; since = now; armed = true }
        if (t == null) return Result(0f, false)
        if (!armed) return Result(1f, false)
        val p = ((now - since).toFloat() / dwellMs).coerceIn(0f, 1f)
        if (p >= 1f) { armed = false; return Result(1f, true) }
        return Result(p, false)
    }

    fun reset() { target = null; armed = true }
}

/**
 * Seleção por permanência para o dedo indicador (ex.: 5 s). Diferente do [DwellTracker] do olhar, tolera o
 * tremor natural da mão:
 *  - enquanto o ponto está na área AMPLIADA do botão atual ([stickyInside]) a contagem continua;
 *  - uma saída de até [graceMs] não cancela;
 *  - apontar para OUTRO botão reinicia a contagem para o novo;
 *  - depois de selecionar, só dispara de novo após SAIR do botão.
 */
class HoldSelector(private val graceMs: Long = 250L) {
    data class Result(val progress: Float, val fired: Boolean, val key: String?)

    private var key: String? = null
    private var since = 0L
    private var lastInside = 0L
    private var armed = true

    val currentKey: String? get() = key

    /** [hitKey]: botão exatamente sob o ponto (ou null). [stickyInside]: ponto ainda dentro da área ampliada de [currentKey]. */
    fun update(hitKey: String?, stickyInside: Boolean, now: Long, holdMs: Long): Result {
        when {
            hitKey != null && hitKey == key -> lastInside = now
            hitKey != null -> { key = hitKey; since = now; lastInside = now; armed = true }   // outro botão: reinicia
            key != null && stickyInside -> lastInside = now                                    // tremor na borda
            key != null && now - lastInside <= graceMs -> {}                                   // saída momentânea
            else -> { key = null; armed = true }                                               // saiu: cancela e rearma
        }
        val k = key ?: return Result(0f, false, null)
        if (!armed) return Result(1f, false, k)
        val p = ((now - since).toFloat() / holdMs).coerceIn(0f, 1f)
        if (p >= 1f) { armed = false; return Result(1f, true, k) }
        return Result(p, false, k)
    }

    fun reset() { key = null; armed = true }
}
