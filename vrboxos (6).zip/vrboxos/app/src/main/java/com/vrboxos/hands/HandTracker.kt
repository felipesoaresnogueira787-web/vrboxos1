package com.vrboxos.hands

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.vrboxos.Telemetry
import com.vrboxos.VrLog
import java.util.concurrent.Executors
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Dois fluxos INDEPENDENTES a partir dos mesmos quadros da câmera:
 *  1. EXIBIÇÃO ([onCameraFrame], thread de captura): contabiliza o quadro, publica-o para a GPU sem cópia
 *     e retorna. Nunca espera o MediaPipe: a fluidez da imagem depende só da câmera.
 *  2. RECONHECIMENTO (thread própria "vrbox-hands"): recebe por uma caixa de correio de UM lugar apenas o
 *     quadro MAIS NOVO (os antigos são descartados, nunca acumulam), faz uma cópia privada e roda o MediaPipe
 *     Hand Landmarker + GestureEngine. A inferência lenta só reduz a taxa de reconhecimento, não a do vídeo.
 *
 * O landmarker e o GestureEngine são usados somente pela thread de reconhecimento (necessário também para o
 * delegate de GPU, que exige a mesma thread de criação).
 */
class HandTracker(private val context: Context, private val engine: GestureEngine) {
    val snapshot = AtomicReference<HandSnapshot?>(null)
    @Volatile var error: String? = null
        private set
    @Volatile var wantThumbnail = false
    @Volatile var thumbnail: Bitmap? = null
        private set

    /** Quando true, cada quadro da câmera é publicado (sem cópia) em [previewBitmap]. */
    @Volatile var wantPreview = false
    val previewBitmap = AtomicReference<Bitmap?>(null)
    val previewSeq = AtomicInteger(0)
    /** Instante (elapsedRealtime) em que o quadro de [previewBitmap] chegou: base da medida de atraso da imagem. */
    @Volatile var previewTs = 0L

    @Volatile var recognitionEnabled = true
    @Volatile var recoFpsCap = 20
    @Volatile var useGpu = false

    private class Frame(val bmp: Bitmap, val ts: Long, val mirror: Boolean)

    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "vrbox-hands") }
    private val mailbox = AtomicReference<Frame?>(null)
    private val scheduled = AtomicBoolean(false)

    // ---- somente a thread de reconhecimento
    private var landmarker: HandLandmarker? = null
    private var loadedGpu = false
    private var work: Bitmap? = null
    private var workCanvas: Canvas? = null
    private var lastTsWorker = 0L
    private var latencyEma = 0f
    private var e2eEma = 0f
    private var resultCount = 0
    private var resultStart = 0L
    private var inferFails = 0
    private var thumbCount = 0

    // ---- somente a thread de captura
    private var camFrames = 0
    private var camStart = 0L
    private var lumaCount = 0
    private var darkStreak = 0
    private var lastSubmit = 0L

    /** Carrega o modelo NA thread de reconhecimento. Bloqueia quem chama (thread de fundo do pipeline). */
    fun init(): Boolean {
        val task = FutureTask<Boolean> { initOnWorker() }
        return try {
            worker.execute(task)
            task.get(30, TimeUnit.SECONDS)
        } catch (e: Exception) {
            error = "Modelo não carregou ($MODEL_ASSET): ${e.message}"
            VrLog.e("hands", "init do MediaPipe falhou/expirou", e)
            false
        }
    }

    private fun build(gpu: Boolean): HandLandmarker {
        val base = BaseOptions.builder().setModelAssetPath(MODEL_ASSET)
            .setDelegate(if (gpu) Delegate.GPU else Delegate.CPU).build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.VIDEO)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
        return HandLandmarker.createFromOptions(context, opts)
    }

    private fun initOnWorker(): Boolean {
        val wantGpu = useGpu
        if (landmarker != null && loadedGpu == wantGpu) return true
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        try {
            landmarker = build(wantGpu)
            loadedGpu = wantGpu
            Telemetry.handDelegate = if (wantGpu) "GPU" else "CPU"
            error = null
            return true
        } catch (e: Exception) {
            if (wantGpu) {
                // GPU é opcional e experimental: se falhar, volta ao CPU (o caminho validado) e avisa.
                VrLog.w("hands", "delegate GPU falhou; usando CPU", e)
                try {
                    landmarker = build(false)
                    loadedGpu = false
                    Telemetry.handDelegate = "CPU (GPU indisponível)"
                    error = null
                    return true
                } catch (e2: Exception) {
                    error = "Modelo não carregou ($MODEL_ASSET): ${e2.message}"
                    VrLog.e("hands", "init do MediaPipe falhou", e2)
                    return false
                }
            }
            error = "Modelo não carregou ($MODEL_ASSET): ${e.message}"
            VrLog.e("hands", "init do MediaPipe falhou", e)
            return false
        }
    }

    // ================================================================ 1) EXIBIÇÃO (thread de captura)

    /**
     * Um quadro VÁLIDO da câmera, já vertical (e espelhado se for a frontal). Retorna rápido: apenas
     * contabiliza, publica para a GPU e entrega ao reconhecimento sem esperar por ele.
     */
    fun onCameraFrame(bitmap: Bitmap, tsMs: Long, mirrorHands: Boolean) {
        camFrames++
        if (camStart == 0L) camStart = tsMs
        if (tsMs - camStart >= 1000) {
            Telemetry.cameraFps = camFrames * 1000f / (tsMs - camStart)
            camFrames = 0; camStart = tsMs
        }
        Telemetry.framesReceived++
        Telemetry.lastFrameMs = SystemClock.elapsedRealtime()
        if (Telemetry.cameraState == CameraState.INITIALIZING && Telemetry.framesReceived >= 3) {
            Telemetry.cameraState = CameraState.ACTIVE
            Telemetry.cameraError = null
            VrLog.i("camera", "ATIVA: ${Telemetry.framesReceived} quadros ${bitmap.width}x${bitmap.height}")
        }
        if (wantPreview) {                      // o MESMO bitmap vai para a GPU: sem cópia
            previewBitmap.set(bitmap)
            previewTs = tsMs
            previewSeq.incrementAndGet()
        }
        checkDark(bitmap)
        if (recognitionEnabled) submit(bitmap, tsMs, mirrorHands)
    }

    /** Câmera bloqueada? Mede o brilho médio de uma miniatura 8x8 a cada 8 quadros. */
    private fun checkDark(bitmap: Bitmap) {
        if (++lumaCount % 8 != 0) return
        val tiny = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
        var sum = 0f
        for (yy in 0 until 8) for (xx in 0 until 8) {
            val px = tiny.getPixel(xx, yy)
            sum += 0.299f * ((px shr 16) and 0xFF) + 0.587f * ((px shr 8) and 0xFF) + 0.114f * (px and 0xFF)
        }
        if (tiny !== bitmap) tiny.recycle()
        if (sum / 64f < 12f) { darkStreak++; if (darkStreak >= 3) Telemetry.cameraObstructed = true }
        else { darkStreak = 0; Telemetry.cameraObstructed = false }
    }

    // ================================================================ 2) RECONHECIMENTO (thread própria)

    private fun submit(bitmap: Bitmap, ts: Long, mirror: Boolean) {
        val minInterval = 1000L / recoFpsCap.coerceAtLeast(1)
        if (ts - lastSubmit < minInterval - 2) return          // taxa máxima do reconhecimento
        lastSubmit = ts
        // Caixa de correio de UM lugar: se o quadro anterior ainda não foi pego, ele é DESCARTADO.
        if (mailbox.getAndSet(Frame(bitmap, ts, mirror)) != null) Telemetry.recoDropped++
        schedule()
    }

    private fun schedule() {
        if (!scheduled.compareAndSet(false, true)) return
        try { worker.execute { drain() } } catch (_: Exception) { scheduled.set(false) }
    }

    private fun drain() {
        try {
            while (true) {
                val f = mailbox.getAndSet(null) ?: break
                recognize(f)
            }
        } finally {
            scheduled.set(false)
            if (mailbox.get() != null) schedule()
        }
    }

    private fun ensureWork(w: Int, h: Int): Bitmap {
        val cur = work
        if (cur != null && cur.width == w && cur.height == h && !cur.isRecycled) return cur
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        work = nb; workCanvas = Canvas(nb)
        return nb
    }

    private fun recognize(f: Frame) {
        val l = landmarker ?: return
        if (!recognitionEnabled) return
        val ts = if (f.ts <= lastTsWorker) lastTsWorker + 1 else f.ts
        lastTsWorker = ts
        // Cópia privada: o quadro da fila pertence ao pool da câmera e pode ser reutilizado.
        val w = ensureWork(f.bmp.width, f.bmp.height)
        workCanvas?.drawBitmap(f.bmp, 0f, 0f, null)
        val aspect = w.width.toFloat() / w.height.toFloat()
        val raw = ArrayList<RawHand>(2)
        val t0 = SystemClock.elapsedRealtime()
        try {
            val res = l.detectForVideo(BitmapImageBuilder(w).build(), ts)
            val lms = res.landmarks()
            val hands = res.handedness()
            for (i in lms.indices) {
                val a = FloatArray(63)
                for (k in 0 until 21) {
                    val p = lms[i][k]
                    a[k * 3] = p.x(); a[k * 3 + 1] = p.y(); a[k * 3 + 2] = p.z()
                }
                val cat = hands.getOrNull(i)?.firstOrNull()
                raw.add(RawHand(a, cat?.categoryName() ?: "?", cat?.score() ?: 0.5f))
            }
        } catch (e: Exception) {
            error = "Inferência falhou: ${e.message}"
            Telemetry.handsError = "inferência falhou"
            Telemetry.handStatus = "Erro: ${e.message}"
            if (++inferFails <= 3) VrLog.e("hands", "detectForVideo falhou", e)
            return
        }
        val now = SystemClock.elapsedRealtime()
        val lat = (now - t0).toFloat()
        val e2e = (now - f.ts).toFloat()          // do quadro chegar até o resultado pronto (inclui fila + cópia + inferência)
        latencyEma = if (latencyEma == 0f) lat else latencyEma * 0.9f + lat * 0.1f
        e2eEma = if (e2eEma == 0f) e2e else e2eEma * 0.9f + e2e * 0.1f
        snapshot.set(engine.process(ts, raw, aspect, f.mirror, latencyEma))
        Telemetry.handLatencyMs = latencyEma
        Telemetry.handE2eMs = e2eEma
        Telemetry.handStatus = "Rodando"
        Telemetry.handsError = null

        resultCount++
        if (resultStart == 0L) resultStart = now
        if (now - resultStart >= 1000) {
            Telemetry.handFps = resultCount * 1000f / (now - resultStart)
            resultCount = 0; resultStart = now
        }
        if (wantThumbnail && ++thumbCount % 3 == 0) {
            thumbnail = Bitmap.createScaledBitmap(w, 160, (160f / aspect).toInt().coerceAtLeast(1), true)
        }
    }

    /** Zera gestos e snapshot (a engine só é tocada pela thread de reconhecimento). */
    fun reset() {
        snapshot.set(null)
        mailbox.set(null)
        previewBitmap.set(null)
        darkStreak = 0
        Telemetry.cameraObstructed = false
        try { worker.execute { engine.reset() } } catch (_: Exception) {}
    }

    fun close() {
        mailbox.set(null)
        snapshot.set(null)
        try {
            worker.execute {
                try { landmarker?.close() } catch (_: Exception) {}
                landmarker = null
            }
            worker.shutdown()
        } catch (_: Exception) {}
    }

    companion object { const val MODEL_ASSET = "hand_landmarker.task" }
}
