package com.vrboxos.hands

/** Estado real da câmera. ACTIVE só depois de receber quadros válidos. */
enum class CameraState(val label: String) {
    OFF("Desligada"),
    WAITING_PERMISSION("Aguardando permissão"),
    INITIALIZING("Inicializando"),
    ACTIVE("Ativa"),
    UNAVAILABLE("Indisponível")
}
