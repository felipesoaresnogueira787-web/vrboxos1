package com.vrboxos.render

import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Malhas estáticas (linhas, triângulos, pontos) de um ambiente. Leves de propósito. */
class EnvMesh(
    val name: String,
    val clear: FloatArray,
    private val lines: MeshBuilder,
    private val tris: MeshBuilder,
    private val points: MeshBuilder,
    val pointSize: Float
) {
    val lineBuf: FloatBuffer = lines.buffer()
    val lineCount = lines.count
    val triBuf: FloatBuffer = tris.buffer()
    val triCount = tris.count
    val pointBuf: FloatBuffer = points.buffer()
    val pointCount = points.count
}

object Environments {
    val NAMES = arrayOf("Sala futurista", "Espaço minimalista", "Cinema imersivo", "Minha Casa")
    /** Índice do ambiente de passthrough (câmera ao vivo). */
    const val HOME_INDEX = 3
    val DESCRIPTIONS = arrayOf(
        "Grade luminosa, pilares e partículas.",
        "Poucos elementos, máxima legibilidade.",
        "Sala escura com assentos laterais.",
        "Câmera traseira ao vivo (2D) com o menu por cima."
    )

    fun build(id: Int): EnvMesh = when (id) {
        3 -> passthrough()
        1 -> minimal()
        2 -> cinema()
        else -> futuristic()
    }

    private fun futuristic(): EnvMesh {
        val lines = MeshBuilder(); val tris = MeshBuilder(); val pts = MeshBuilder()
        val grid = floatArrayOf(0.1f, 0.8f, 1f, 0.35f)
        val gridDim = floatArrayOf(0.1f, 0.6f, 1f, 0.15f)
        for (i in -12..12) {
            lines.line(i.toFloat(), -1.6f, -12f, i.toFloat(), -1.6f, 12f, grid)
            lines.line(-12f, -1.6f, i.toFloat(), 12f, -1.6f, i.toFloat(), grid)
        }
        for (i in -12..12 step 2) {
            lines.line(i.toFloat(), 3.2f, -12f, i.toFloat(), 3.2f, 12f, gridDim)
            lines.line(-12f, 3.2f, i.toFloat(), 12f, 3.2f, i.toFloat(), gridDim)
        }
        val body = floatArrayOf(0.05f, 0.08f, 0.15f, 1f)
        val strip = floatArrayOf(0.2f, 0.9f, 1f, 0.9f)
        for (k in 0 until 10) {
            val a = (2 * PI * k / 10).toFloat()
            val px = 7f * sin(a); val pz = -7f * cos(a)
            tris.box(px, 0.8f, pz, 0.4f, 4.8f, 0.4f, body)
            lines.line(px, -1.6f, pz + 0.21f, px, 3.2f, pz + 0.21f, strip)
        }
        val r = Random(7)
        for (i in 0 until 120) {
            val th = r.nextFloat() * 2f * PI.toFloat(); val ph = (r.nextFloat() - 0.5f) * PI.toFloat()
            val rad = 6f + r.nextFloat() * 6f
            pts.v(rad * cos(ph) * sin(th), rad * sin(ph), -rad * cos(ph) * cos(th), 0.7f, 0.95f, 1f, 0.8f)
        }
        return EnvMesh(NAMES[0], floatArrayOf(0.02f, 0.03f, 0.07f), lines, tris, pts, 3f)
    }

    /**
     * "Minha Casa": sem geometria própria, o fundo é a imagem real da câmera (desenhada pelo renderizador).
     * Só se a câmera ainda não estiver entregando imagens aparece um fundo escuro com uma grade tênue.
     */
    private fun passthrough(): EnvMesh {
        val lines = MeshBuilder(); val tris = MeshBuilder(); val pts = MeshBuilder()
        val c = floatArrayOf(0.5f, 0.6f, 0.8f, 0.12f)
        for (i in -6..6) {
            lines.line(i.toFloat(), -1.6f, -8f, i.toFloat(), -1.6f, 8f, c)
            lines.line(-6f, -1.6f, i.toFloat(), 6f, -1.6f, i.toFloat(), c)
        }
        return EnvMesh(NAMES[3], floatArrayOf(0.01f, 0.01f, 0.02f), lines, tris, pts, 1f)
    }

    private fun minimal(): EnvMesh {
        val lines = MeshBuilder(); val tris = MeshBuilder(); val pts = MeshBuilder()
        val c = floatArrayOf(0.8f, 0.85f, 1f, 0.18f)
        for (rad in 1..10) {
            val n = 64
            for (s in 0 until n) {
                val a0 = (2 * PI * s / n).toFloat(); val a1 = (2 * PI * (s + 1) / n).toFloat()
                lines.line(rad * sin(a0), -1.6f, -rad * cos(a0), rad * sin(a1), -1.6f, -rad * cos(a1), c)
            }
        }
        for (s in 0 until 12) {
            val a = (2 * PI * s / 12).toFloat()
            lines.line(0f, -1.6f, 0f, 10f * sin(a), -1.6f, -10f * cos(a), c)
        }
        return EnvMesh(NAMES[1], floatArrayOf(0.07f, 0.08f, 0.10f), lines, tris, pts, 1f)
    }

    private fun cinema(): EnvMesh {
        val lines = MeshBuilder(); val tris = MeshBuilder(); val pts = MeshBuilder()
        // piso escuro
        tris.quad(-8f, -1.6f, 8f, 8f, -1.6f, 8f, 8f, -1.6f, -12f, -8f, -1.6f, -12f, floatArrayOf(0.04f, 0.02f, 0.02f, 1f))
        val seat = floatArrayOf(0.35f, 0.04f, 0.06f, 1f)
        for (side in intArrayOf(-1, 1)) {
            for (col in 0 until 2) {
                for (row in 0 until 3) {
                    val x = side * (2.3f + col * 1.0f)
                    val z = 0.4f - row * 0.9f
                    tris.box(x, -1.3f, z, 0.7f, 0.5f, 0.7f, seat)          // assento
                    tris.box(x, -0.8f, z + 0.3f, 0.7f, 0.9f, 0.12f, seat)  // encosto
                }
            }
        }
        val amber = floatArrayOf(1f, 0.7f, 0.3f, 0.9f)
        for (zi in 0..14) {
            pts.v(-1.3f, -1.58f, 3f - zi, amber[0], amber[1], amber[2], amber[3])
            pts.v(1.3f, -1.58f, 3f - zi, amber[0], amber[1], amber[2], amber[3])
        }
        val wall = floatArrayOf(0.5f, 0.2f, 0.2f, 0.18f)
        for (zi in -12..4 step 2) {
            lines.line(-6f, -1.6f, zi.toFloat(), -6f, 3f, zi.toFloat(), wall)
            lines.line(6f, -1.6f, zi.toFloat(), 6f, 3f, zi.toFloat(), wall)
        }
        return EnvMesh(NAMES[2], floatArrayOf(0.005f, 0.005f, 0.01f), lines, tris, pts, 4f)
    }
}
