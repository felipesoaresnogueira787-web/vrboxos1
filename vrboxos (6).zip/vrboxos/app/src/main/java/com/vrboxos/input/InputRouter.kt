package com.vrboxos.input

import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import com.vrboxos.AppController
import com.vrboxos.Feedback
import com.vrboxos.VrLog
import com.vrboxos.Telemetry
import com.vrboxos.hands.GestureEvent
import com.vrboxos.hands.HandPipeline
import com.vrboxos.hands.HandState
import com.vrboxos.hands.HoldGesture
import com.vrboxos.hands.Pose
import com.vrboxos.head.Quat
import com.vrboxos.render.StereoLayout
import com.vrboxos.settings.GestureCommand
import com.vrboxos.settings.InputMode
import com.vrboxos.settings.Settings
import com.vrboxos.ui.Button
import com.vrboxos.ui.Hit
import com.vrboxos.ui.Panel
import com.vrboxos.ui.SpatialUi
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.math.tan

private const val HOLD_MARGIN = 18f   // tolerância (px da textura) em volta do botão para o tremor da mão

/** Converte posição 2D da mão na imagem em direção no espaço da cabeça. */
object HandMapping {
    const val HFOV_DEG = 80.0   // campo horizontal da câmera assumido (estimativa, não calibrado)
    const val GAIN = 1.3f       // amplifica o alcance para não precisar chegar às bordas da imagem

    /** Enquadramento da imagem da câmera desenhada como fundo (o renderizador atualiza a cada quadro). */
    class Passthrough(val viewAspect: Float, val zoom: Float, val fovDeg: Float)
    @Volatile var passthrough: Passthrough? = null

    /**
     * Escreve (dx, dy) em unidades de tangente (direção = (dx, dy, -1) normalizada).
     * Em "Minha Casa" usa EXATAMENTE o enquadramento da imagem: o ponto aparece onde o dedo aparece na tela.
     */
    fun headSpace(nx: Float, ny: Float, aspect: Float, out: FloatArray) {
        val pt = passthrough
        if (pt != null) { passthroughSpace(nx, ny, aspect, pt, out); return }
        val span = 2f * tan(Math.toRadians(HFOV_DEG / 2)).toFloat() * GAIN
        out[0] = (nx - 0.5f) * span
        out[1] = -(ny - 0.5f) * span / aspect
    }

    /** Inverso do desenho do fundo: ponto (nx,ny) da imagem -> direção no espaço da cabeça. */
    fun passthroughSpace(nx: Float, ny: Float, imageAspect: Float, pt: Passthrough, out: FloatArray) {
        val sx: Float; val sy: Float
        if (imageAspect > pt.viewAspect) { sx = 1f; sy = pt.viewAspect / imageAspect } else { sx = imageAspect / pt.viewAspect; sy = 1f }
        val ndcX = (nx - 0.5f) * 2f * sx * pt.zoom
        val ndcY = -(ny - 0.5f) * 2f * sy * pt.zoom
        val tanY = tan(Math.toRadians(StereoLayout.verticalFovDeg(pt.fovDeg, pt.viewAspect) / 2.0)).toFloat()
        out[0] = ndcX * tanY * pt.viewAspect
        out[1] = ndcY * tanY
    }
}

/**
 * Decide qual método de entrada está ativo (mãos > olhar > toque) e transforma gestos,
 * permanência do olhar e toques em ações sobre os painéis. Roda na thread GL.
 */
class InputRouter(
    private val ui: SpatialUi,
    private val settings: Settings,
    private val feedback: Feedback,
    private val pipeline: HandPipeline,
    private val controller: AppController
) {
    enum class Method(val label: String) { HAND("Mãos"), GAZE("Olhar"), TOUCH("Toque") }

    @Volatile var method = Method.GAZE
        private set
    var hasPointer = false
        private set
    val pointerWorld = FloatArray(3)
    var dwellProgress = 0f
        private set
    var pressed = false
        private set
    var clicks = 0; private set
    var swipes = 0; private set
    var pinches = 0; private set

    private val guard = ClickGuard(350)
    private val dwell = DwellTracker()
    private val dirHead = FloatArray(3)
    private val dirWorld = FloatArray(3)
    private val tmp2 = FloatArray(2)
    private val tmpWorld = FloatArray(3)

    private var pressHit: Hit? = null
    private var dragPanel: Panel? = null
    private var dragOff: SpatialUi.DragState? = null
    private var eyePos = FloatArray(3)
    private var scalePanel: Panel? = null
    private var scaleD0 = 0f
    private var scaleS0 = 1f
    private var lastNote = 0L
    private var lastHit: Hit? = null
    // toque repassado ao WebView do navegador
    private var webDown = false
    private var webU = 0f
    private var webV = 0f
    // seleção por permanência do dedo e menu agarrado com a pinça
    private val holdSel = HoldSelector()
    private var pointingUntil = 0L
    private var grabPending: Panel? = null
    private var grabStart = 0L
    private val grabDir0 = FloatArray(3)
    /** Painel (menu) que está sendo segurado agora, ou null. */
    val grabbed: Panel? get() = dragPanel

    private var touchDown = false
    private var touchPress = false
    private var touchRelease = false
    private var touchX = 0f
    private var touchY = 0f

    /** Chamado na thread GL (via queueEvent). */
    fun touch(x: Float, y: Float, action: Int) {
        touchX = x; touchY = y
        when (action) {
            MotionEvent.ACTION_DOWN -> { touchDown = true; touchPress = true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { touchDown = false; touchRelease = true }
        }
    }

    /** Controle Bluetooth / teclas. Chamado na thread GL. */
    fun onKey(code: Int): Boolean = when (code) {
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
            val h = lastHit
            val b = h?.button
            if (guard.allow(SystemClock.elapsedRealtime())) {
                if (b != null && b.enabled) activate(b)
                else if (h != null && h.panel.isWeb) {   // clique na página do navegador
                    ui.webTouch(MotionEvent.ACTION_DOWN, h.u, h.v); ui.webTouch(MotionEvent.ACTION_UP, h.u, h.v); feedback.click()
                }
            }
            true
        }
        KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK -> { if (!ui.back()) ui.notify("Você já está no início"); true }
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_MENU -> { runCommand(GestureCommand.MENU); true }
        else -> false
    }

    fun update(now: Long, q: Quat, vr: Boolean, aspect: Float, sw: Int, sh: Int, eye: FloatArray) {
        eyePos = eye   // posição dos olhos no mundo: origem de TODOS os raios de apontar
        val snap = pipeline.tracker.snapshot.get()
        val fresh = snap != null && now - snap.timestampMs < 400
        val hands: List<HandState> =
            if (fresh && settings.handEnabled) snap!!.hands.filter { it.fade > 0.3f } else emptyList()
        val handAspect = snap?.imageAspect ?: 1.33f
        val handOk = hands.isNotEmpty()

        val newMethod = when {
            !vr -> if (handOk) Method.HAND else Method.TOUCH
            settings.inputMode == InputMode.GAZE -> Method.GAZE
            else -> if (handOk) Method.HAND else Method.GAZE
        }
        if (newMethod != method) {
            method = newMethod
            Telemetry.inputMethod = method.label
            cancelInteractions()
            if (now - lastNote > 2000) { lastNote = now; ui.notify("Entrada ativa: ${method.label}") }
        }

        // Eventos de gesto: sempre esvaziados (evita acúmulo), só agem no método Mãos.
        while (true) {
            val e = pipeline.engine.events.poll() ?: break
            when (e) {
                is GestureEvent.PinchStart -> pinches++
                is GestureEvent.Swipe -> swipes++
                else -> {}
            }
            if (method == Method.HAND) handleEvent(e, now, q, handAspect)
        }

        // Ponteiro
        hasPointer = false
        when (method) {
            Method.HAND -> {
                val h = hands.firstOrNull { it.pose == Pose.PINCH || it.pose == Pose.POINT }
                    ?: hands.maxByOrNull { it.fade }
                if (h != null) {
                    HandMapping.headSpace(h.cursorX, h.cursorY, handAspect, tmp2)
                    setDirHead(tmp2[0], tmp2[1]); hasPointer = true
                    if (h.pose == Pose.POINT) pointingUntil = now + 300L   // histerese: a pose pode oscilar entre quadros
                }
            }
            Method.GAZE -> { dirHead[0] = 0f; dirHead[1] = 0f; dirHead[2] = -1f; hasPointer = true }
            Method.TOUCH -> if (touchDown || touchRelease) {
                val ty = tan(Math.toRadians(com.vrboxos.render.StereoLayout.verticalFovDeg(settings.fovDeg, aspect) / 2.0)).toFloat()
                setDirHead((touchX / sw * 2f - 1f) * ty * aspect, (1f - touchY / sh * 2f) * ty)
                hasPointer = true
            }
        }
        var hit: Hit? = null
        if (hasPointer) {
            q.rotate(dirHead, dirWorld)
            hit = ui.hitTest(eyePos, dirWorld, pointerWorld)
        }
        lastHit = hit ?: lastHit.takeIf { method == Method.GAZE }
        ui.setHover(hit)

        // Olhar: seleção por permanência
        if (method == Method.GAZE) {
            val b = hit?.button?.takeIf { it.enabled }
            val onWeb = b == null && hit != null && hit.button == null && hit.panel.isWeb
            val key = when {
                b != null && hit != null -> "${hit.panel.id}:${b.id}"
                onWeb -> "web"
                else -> null
            }
            val r = dwell.update(key, now, (settings.dwellSec * 1000).toLong())
            dwellProgress = r.progress
            if (r.fired && guard.allow(now)) {
                if (b != null) activate(b)
                else if (onWeb && hit != null) {   // olhar parado na página = toque naquele ponto
                    ui.webTouch(MotionEvent.ACTION_DOWN, hit.u, hit.v); ui.webTouch(MotionEvent.ACTION_UP, hit.u, hit.v); feedback.click()
                }
            }
        } else if (method == Method.HAND) {
            handHold(hit, now)
        } else {
            dwell.reset(); dwellProgress = 0f; holdSel.reset()
        }

        // Toque (modo plano)
        if (method == Method.TOUCH) {
            if (touchPress) { touchPress = false; pressAt(hit, now) }
            if (touchRelease) { touchRelease = false; releaseAt(hit, now) }
        } else { touchPress = false; touchRelease = false }

        // Arrasto e barras (mãos/toque)
        if (method != Method.GAZE && hasPointer) {
            dragPanel?.let { p -> dragOff?.let { st -> ui.dragTo(p, eyePos, dirWorld, st) } }
            val gp = grabPending
            if (gp != null && pressed && dragPanel == null && method == Method.HAND) {
                val held = now - grabStart
                val cos = dirWorld[0] * grabDir0[0] + dirWorld[1] * grabDir0[1] + dirWorld[2] * grabDir0[2]
                // Pinça segurada + movimento (> ~2,5°) = pegou o menu. Segurar parado 0,7 s também pega.
                if ((held >= 250 && cos < 0.9990f) || held >= 700) {
                    dragPanel = gp; dragOff = ui.beginDrag(gp, eyePos, dirWorld); grabPending = null
                    feedback.tick(); VrLog.i("input", "menu agarrado: ${gp.id}")
                }
            }
            if (webDown && hit != null && hit.panel.isWeb && (abs(hit.u - webU) > 0.002f || abs(hit.v - webV) > 0.002f)) {
                webU = hit.u; webV = hit.v
                ui.webTouch(MotionEvent.ACTION_MOVE, hit.u, hit.v)   // arrastar = rolar a página
            }
            val ph = pressHit
            val b = ph?.button
            if (pressed && b?.onScrub != null && hit != null && hit.button?.id == b.id) scrub(b, hit)
        }

        // Duas mãos agarrando: redimensiona o painel em foco
        if (method == Method.HAND && snap != null && hands.size == 2 && snap.twoHandDistance > 0f &&
            hands.all { it.pinching || it.pose == Pose.FIST }
        ) {
            val target = scalePanel ?: dragPanel ?: hit?.panel ?: ui.focusPanel()
            if (scalePanel == null) { scalePanel = target; scaleD0 = snap.twoHandDistance; scaleS0 = target.userScale }
            else scalePanel?.userScale = (scaleS0 * snap.twoHandDistance / scaleD0).coerceIn(0.5f, 2.5f)
        } else scalePanel = null
    }

    private fun setDirHead(dx: Float, dy: Float) {
        val n = sqrt(dx * dx + dy * dy + 1f)
        dirHead[0] = dx / n; dirHead[1] = dy / n; dirHead[2] = -1f / n
    }

    private fun rayFromCursor(x: Float, y: Float, aspect: Float, q: Quat) {
        HandMapping.headSpace(x, y, aspect, tmp2)
        setDirHead(tmp2[0], tmp2[1])
        q.rotate(dirHead, dirWorld)
    }

    private fun handleEvent(e: GestureEvent, now: Long, q: Quat, aspect: Float) {
        when (e) {
            is GestureEvent.PinchStart -> {
                rayFromCursor(e.x, e.y, aspect, q)
                pressAt(ui.hitTest(eyePos, dirWorld, tmpWorld), now)
            }
            is GestureEvent.PinchEnd -> releaseAt(lastHit.takeIf { hasPointer } ?: ui.hitTest(eyePos, dirWorld, tmpWorld), now)
            is GestureEvent.GrabStart -> {
                rayFromCursor(e.x, e.y, aspect, q)
                val h = ui.hitTest(eyePos, dirWorld, tmpWorld)
                if (h != null) { dragPanel = h.panel; dragOff = ui.beginDrag(h.panel, eyePos, dirWorld); pressed = true; feedback.tick() }
            }
            is GestureEvent.GrabEnd -> { stopDrag(); pressed = false }
            is GestureEvent.Swipe -> ui.onSwipe(e.dirX)
            is GestureEvent.Hold -> if (dragPanel == null && !pressed) {
                runCommand(if (e.gesture == HoldGesture.FIST) settings.fistCommand else settings.openCommand)
            }
            is GestureEvent.HandLost -> cancelInteractions()
            is GestureEvent.HandFound -> {}
        }
    }

    private fun pressAt(h: Hit?, now: Long) {
        pressHit = h
        pressed = h != null
        if (h == null) return
        val b = h.button
        if (h.panel.isWeb && b == null) {
            webDown = true; webU = h.u; webV = h.v
            ui.webTouch(MotionEvent.ACTION_DOWN, h.u, h.v)
            feedback.tick()
            return
        }
        if (b?.onScrub != null) scrub(b, h)
        else if (b == null && h.panel.headerPx > 0f && h.py <= h.panel.headerPx) {
            dragPanel = h.panel
            dragOff = ui.beginDrag(h.panel, eyePos, dirWorld)
        }
        if (method == Method.HAND && h.panel.group != 0 && dragPanel == null) {
            grabPending = h.panel; grabStart = now; System.arraycopy(dirWorld, 0, grabDir0, 0, 3)
        }
        feedback.tick()
    }

    private fun releaseAt(h: Hit?, now: Long) {
        val ph = pressHit
        pressHit = null
        pressed = false
        grabPending = null
        if (webDown) {
            webDown = false
            val wh = h?.takeIf { it.panel.isWeb }
            ui.webTouch(MotionEvent.ACTION_UP, wh?.u ?: webU, wh?.v ?: webV)
            return
        }
        if (dragPanel != null) { stopDrag(); return }
        if (ph == null) return
        val pb = ph.button ?: return
        if (pb.onScrub == null && pb.enabled && h != null && h.button?.id == pb.id &&
            h.panel === ph.panel && guard.allow(now)
        ) {
            activate(pb)
        }
    }

    private fun scrub(b: Button, h: Hit) {
        val u = ((h.px - b.rect.left) / b.rect.width()).coerceIn(0f, 1f)
        b.onScrub?.invoke(u)
    }

    private fun activate(b: Button) {
        feedback.click()
        clicks++
        b.onClick()
    }

    private fun runCommand(c: GestureCommand) {
        when (c) {
            GestureCommand.MENU -> { ui.goHome(); controller.recenter(); ui.resetPlacements() }
            GestureCommand.BACK -> if (!ui.back()) ui.notify("Você já está no início")
            GestureCommand.NONE -> return
        }
        feedback.click()
    }

    /** Solta a tela: ela fica ancorada onde está. */
    private fun stopDrag() {
        dragPanel?.let { ui.endDrag(it) }
        dragPanel = null; dragOff = null
    }

    private fun cancelInteractions() {
        if (webDown) { webDown = false; ui.webTouch(MotionEvent.ACTION_UP, webU, webV) }   // não deixar o toque preso
        pressHit = null; stopDrag(); scalePanel = null; pressed = false; dwell.reset(); dwellProgress = 0f
        grabPending = null; holdSel.reset()
    }

    /** Seleção por permanência da mão: indicador apontando sobre o MESMO botão por [Settings.handDwellSec] (5 s). */
    private fun handHold(hit: Hit?, now: Long) {
        val pointing = now <= pointingUntil && !pressed && dragPanel == null
        if (!pointing) { holdSel.reset(); dwellProgress = 0f; return }
        val b = hit?.button?.takeIf { it.enabled }
        val hitKey = if (b != null && hit != null) "${hit.panel.id}:${b.id}" else null
        // tolerância a tremor: continua no botão atual enquanto o ponto estiver na sua área ampliada
        var sticky = false
        val cur = holdSel.currentKey
        if (cur != null && hit != null) {
            val parts = cur.split(":", limit = 2)
            val r = ui.findButton(parts[0], parts[1])?.rect
            sticky = hit.panel.id == parts[0] && r != null &&
                hit.px >= r.left - HOLD_MARGIN && hit.px <= r.right + HOLD_MARGIN &&
                hit.py >= r.top - HOLD_MARGIN && hit.py <= r.bottom + HOLD_MARGIN
        }
        val res = holdSel.update(hitKey, sticky, now, (settings.handDwellSec * 1000).toLong())
        dwellProgress = res.progress
        if (res.fired && guard.allow(now)) {
            val parts = res.key?.split(":", limit = 2)
            val btn = if (parts != null) ui.findButton(parts[0], parts[1]) else null
            if (btn != null && btn.enabled) activate(btn)
        }
    }
}
