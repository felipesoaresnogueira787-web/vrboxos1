package com.vrboxos.render

import android.opengl.GLES11Ext
import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** Quadrado unitário (-0.5..0.5) texturizado. oes=true usa textura externa (vídeo). */
class QuadRenderer(private val oes: Boolean) {
    private val prog = GlUtil.program(Shaders.TEX_VS, if (oes) Shaders.OES_FS else Shaders.TEX_FS)
    private val aPos = GLES20.glGetAttribLocation(prog, "aPos")
    private val aUv = GLES20.glGetAttribLocation(prog, "aUv")
    private val uMvp = GLES20.glGetUniformLocation(prog, "uMvp")
    private val uUv = GLES20.glGetUniformLocation(prog, "uUv")
    private val uTint = GLES20.glGetUniformLocation(prog, "uTint")
    private val uTex = GLES20.glGetUniformLocation(prog, "uTex")
    private val identity = FloatArray(16).also { it[0] = 1f; it[5] = 1f; it[10] = 1f; it[15] = 1f }

    // Bitmap: v=0 no topo. Vídeo (OES): v para cima.
    private val verts: FloatBuffer = GlUtil.floatBuffer(
        if (oes) floatArrayOf(
            -.5f, -.5f, 0f, 0f, 0f, .5f, -.5f, 0f, 1f, 0f, -.5f, .5f, 0f, 0f, 1f, .5f, .5f, 0f, 1f, 1f
        ) else floatArrayOf(
            -.5f, -.5f, 0f, 0f, 1f, .5f, -.5f, 0f, 1f, 1f, -.5f, .5f, 0f, 0f, 0f, .5f, .5f, 0f, 1f, 0f
        )
    )

    fun draw(tex: Int, mvp: FloatArray, tint: FloatArray, uvMat: FloatArray? = null) {
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(if (oes) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uUv, 1, false, uvMat ?: identity, 0)
        GLES20.glUniform4fv(uTint, 1, tint, 0)
        verts.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, verts)
        GLES20.glEnableVertexAttribArray(aPos)
        verts.position(3)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 20, verts)
        GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }
}

/** Geometria colorida (pos3 + rgba4 por vértice, 7 floats). */
class ColorRenderer {
    private val prog = GlUtil.program(Shaders.COLOR_VS, Shaders.COLOR_FS)
    private val aPos = GLES20.glGetAttribLocation(prog, "aPos")
    private val aColor = GLES20.glGetAttribLocation(prog, "aColor")
    private val uMvp = GLES20.glGetUniformLocation(prog, "uMvp")
    private val uPoint = GLES20.glGetUniformLocation(prog, "uPoint")

    fun draw(buf: FloatBuffer, vertexCount: Int, mode: Int, mvp: FloatArray, pointSize: Float = 1f) {
        if (vertexCount <= 0) return
        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniform1f(uPoint, pointSize)
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 28, buf)
        GLES20.glEnableVertexAttribArray(aPos)
        buf.position(3)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_FLOAT, false, 28, buf)
        GLES20.glEnableVertexAttribArray(aColor)
        GLES20.glDrawArrays(mode, 0, vertexCount)
    }
}

/** Acumula vértices (pos+cor) e entrega um FloatBuffer direto reutilizável. */
class MeshBuilder(initialVertices: Int = 2048) {
    private var a = FloatArray(initialVertices * 7)
    var count = 0
        private set
    private var direct: FloatBuffer? = null

    fun clear() { count = 0 }

    fun v(x: Float, y: Float, z: Float, r: Float, g: Float, b: Float, al: Float) {
        if ((count + 1) * 7 > a.size) a = a.copyOf(a.size * 2)
        val o = count * 7
        a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = r; a[o + 4] = g; a[o + 5] = b; a[o + 6] = al
        count++
    }

    fun line(x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float, c: FloatArray) {
        v(x1, y1, z1, c[0], c[1], c[2], c[3]); v(x2, y2, z2, c[0], c[1], c[2], c[3])
    }

    fun tri(
        x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float, c: FloatArray
    ) {
        v(x1, y1, z1, c[0], c[1], c[2], c[3]); v(x2, y2, z2, c[0], c[1], c[2], c[3]); v(x3, y3, z3, c[0], c[1], c[2], c[3])
    }

    /** Quad (4 cantos em ordem) como 2 triângulos. */
    fun quad(
        x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float, x4: Float, y4: Float, z4: Float, c: FloatArray
    ) {
        tri(x1, y1, z1, x2, y2, z2, x3, y3, z3, c)
        tri(x1, y1, z1, x3, y3, z3, x4, y4, z4, c)
    }

    /** Caixa preenchida com sombreamento fixo por face. */
    fun box(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, base: FloatArray) {
        val x0 = cx - sx / 2; val x1 = cx + sx / 2
        val y0 = cy - sy / 2; val y1 = cy + sy / 2
        val z0 = cz - sz / 2; val z1 = cz + sz / 2
        fun shade(f: Float) = floatArrayOf(base[0] * f, base[1] * f, base[2] * f, base[3])
        quad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, shade(1.0f))   // frente
        quad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, shade(0.6f))   // trás
        quad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, shade(0.75f))  // esquerda
        quad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, shade(0.75f))  // direita
        quad(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, shade(1.25f))  // topo
    }

    fun buffer(): FloatBuffer {
        val need = count * 7
        var d = direct
        if (d == null || d.capacity() < need) {
            d = ByteBuffer.allocateDirect(maxOf(need, 7 * 256) * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            direct = d
        }
        d!!.clear()
        d.put(a, 0, need)
        d.position(0)
        return d
    }
}

/** Desenha a esfera 360° com a textura externa do vídeo. */
class SphereRenderer {
    private val prog = GlUtil.program(Shaders.TEX_VS, Shaders.OES_FS)
    private val aPos = GLES20.glGetAttribLocation(prog, "aPos")
    private val aUv = GLES20.glGetAttribLocation(prog, "aUv")
    private val uMvp = GLES20.glGetUniformLocation(prog, "uMvp")
    private val uUv = GLES20.glGetUniformLocation(prog, "uUv")
    private val uTint = GLES20.glGetUniformLocation(prog, "uTint")
    private val uTex = GLES20.glGetUniformLocation(prog, "uTex")
    private val mesh = SphereMesh.build()
    private val verts: FloatBuffer = GlUtil.floatBuffer(mesh.vertices)
    private val indices: java.nio.ShortBuffer =
        ByteBuffer.allocateDirect(mesh.indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            .also { it.put(mesh.indices); it.position(0) }

    fun draw(tex: Int, mvp: FloatArray, uvMat: FloatArray) {
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uUv, 1, false, uvMat, 0)
        GLES20.glUniform4f(uTint, 1f, 1f, 1f, 1f)
        verts.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, verts)
        GLES20.glEnableVertexAttribArray(aPos)
        verts.position(3)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 20, verts)
        GLES20.glEnableVertexAttribArray(aUv)
        indices.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, mesh.indices.size, GLES20.GL_UNSIGNED_SHORT, indices)
    }
}
