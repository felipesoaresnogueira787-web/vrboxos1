package com.vrboxos.hands

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.vrboxos.Telemetry
import com.vrboxos.VrLog
import com.vrboxos.settings.CameraKind
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Câmera via CameraX. FRONT/BACK são as câmeras do celular. EXTERNAL só funciona se o Android expõe a
 * câmera USB pela API Camera2 (LENS_FACING_EXTERNAL) — nem todo aparelho faz isso.
 * Se a câmera pedida não existe, tenta as outras e avisa qual foi usada.
 */
class CameraXSource(
    private val activity: ComponentActivity,
    private val kind: CameraKind,
    private val fpsCap: () -> Int
) : VideoSource {
    @Volatile private var usedKind = kind
    override val name get() = "CameraX/${usedKind.label}"
    override val mirrored get() = usedKind == CameraKind.FRONT

    /** Avisos para o usuário (ex.: "câmera X indisponível, usando Y"). */
    var onNotice: ((String) -> Unit)? = null

    private var provider: ProcessCameraProvider? = null
    private var executor: ExecutorService? = null
    @Volatile private var lastTs = 0L
    @Volatile private var stopped = false
    private var displayListener: DisplayManager.DisplayListener? = null
    private var lastRot = -1
    private var failStreak = 0
    // Pool de quadros verticais reutilizados (sem alocar um Bitmap novo por quadro).
    private val pool = arrayOfNulls<Bitmap>(4)
    private val poolCanvas = arrayOfNulls<Canvas>(4)
    private var poolIdx = 0
    private val drawM = Matrix()

    @Suppress("DEPRECATION")
    private fun currentRotation() = activity.windowManager.defaultDisplay.rotation

    private fun facing(k: CameraKind) = when (k) {
        CameraKind.FRONT -> CameraSelector.LENS_FACING_FRONT
        CameraKind.BACK -> CameraSelector.LENS_FACING_BACK
        CameraKind.EXTERNAL -> CameraSelector.LENS_FACING_EXTERNAL
    }

    private fun selector(k: CameraKind) = CameraSelector.Builder().requireLensFacing(facing(k)).build()

    private fun has(p: ProcessCameraProvider, k: CameraKind) =
        try { p.hasCamera(selector(k)) } catch (e: Exception) { VrLog.w("camera", "hasCamera(${k.label}) falhou", e); false }

    override fun start(onFrame: (Bitmap, Long) -> Unit, onError: (String) -> Unit) {
        stopped = false
        failStreak = 0
        val exec = Executors.newSingleThreadExecutor().also { executor = it }
        VrLog.i("camera", "abrindo ${kind.label}; display=${currentRotation() * 90}°")
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val order = listOf(kind) + CameraKind.values().filter { it != kind }
                val chosen = order.firstOrNull { has(p, it) }
                if (chosen == null) {
                    onError("Este aparelho não expõe nenhuma câmera (frontal, traseira ou externa)")
                    return@addListener
                }
                if (chosen != kind) {
                    VrLog.w("camera", "${kind.label} indisponível; usando ${chosen.label}")
                    onNotice?.invoke("Câmera ${kind.label} indisponível; usando ${chosen.label}")
                }
                usedKind = chosen
                @Suppress("DEPRECATION")
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST) // descarta quadros velhos
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy ->
                    try {
                        if (!stopped) handle(proxy, onFrame)
                        failStreak = 0
                    } catch (t: Throwable) {
                        VrLog.e("camera", "falha ao processar quadro", t)
                        if (++failStreak >= 5) onError("falha repetida ao processar quadros: ${t.message}")
                    } finally {
                        proxy.close()
                    }
                }
                p.unbindAll()
                val cam = p.bindToLifecycle(activity, selector(chosen), analysis)
                // O CameraX só ajusta a rotação da imagem para a rotação do display informada.
                analysis.targetRotation = currentRotation()
                val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                val l = object : DisplayManager.DisplayListener {
                    override fun onDisplayAdded(displayId: Int) {}
                    override fun onDisplayRemoved(displayId: Int) {}
                    override fun onDisplayChanged(displayId: Int) {
                        val r = currentRotation()
                        if (analysis.targetRotation != r) {
                            VrLog.i("camera", "display mudou: targetRotation ${analysis.targetRotation} -> $r")
                            analysis.targetRotation = r
                        }
                    }
                }
                dm.registerDisplayListener(l, Handler(Looper.getMainLooper()))
                displayListener = l
                VrLog.i("camera", "vinculada: ${chosen.label}, espelhada=$mirrored")
                cam.cameraInfo.cameraState.observe(activity) { st ->
                    val err = st.error
                    VrLog.i("camera", "estado do CameraX: ${st.type}" + (err?.let { " erro=${it.code} (${CameraErrors.name(it.code)})" } ?: ""))
                    if (err != null) {
                        // Erros recuperáveis (ex.: câmera em uso) o CameraX tenta de novo sozinho: não derrubar.
                        if (CameraErrors.isCritical(err.code)) onError("Erro crítico da câmera: ${CameraErrors.name(err.code)}")
                        else onNotice?.invoke("Câmera: ${CameraErrors.name(err.code)} (tentando de novo)")
                    }
                }
            } catch (e: Exception) {
                VrLog.e("camera", "falha ao abrir a câmera", e)
                onError("${e.javaClass.simpleName}: ${e.message ?: "erro ao abrir a câmera"}")
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    private fun nextSlot(w: Int, h: Int): Int {
        val i = poolIdx
        poolIdx = (poolIdx + 1) % pool.size
        val b = pool[i]
        if (b == null || b.isRecycled || b.width != w || b.height != h) {
            val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            pool[i] = nb; poolCanvas[i] = Canvas(nb)
        }
        return i
    }

    private fun handle(proxy: ImageProxy, onFrame: (Bitmap, Long) -> Unit) {
        val now = SystemClock.elapsedRealtime()
        val minInterval = 1000L / fpsCap().coerceAtLeast(1)
        if (now - lastTs < minInterval - 2) return      // -2 ms: o relógio do analisador tem jitter
        lastTs = now
        val rot = proxy.imageInfo.rotationDegrees
        if (rot != lastRot) {
            // Registra QUALQUER mudança de rotação aplicada à imagem: mostra quem a alterou e quando.
            VrLog.i("camera", "quadro ${proxy.width}x${proxy.height} rotationDegrees $lastRot -> $rot (display=${currentRotation() * 90}°, espelhado=$mirrored)")
            lastRot = rot
        }
        // Atraso sensor -> app (só vale se o carimbo do CameraX usa o mesmo relógio; senão é ignorado).
        val lagMs = (SystemClock.elapsedRealtimeNanos() - proxy.imageInfo.timestamp) / 1_000_000f
        if (lagMs in 0f..500f) {
            val prev = Telemetry.captureToAnalyzerMs
            Telemetry.captureToAnalyzerMs = if (prev == 0f) lagMs else prev * 0.9f + lagMs * 0.1f
        }
        val src = proxy.toBitmap()                       // única conversão de formato por quadro
        val swap = rot % 180 != 0
        val ow = if (swap) src.height else src.width
        val oh = if (swap) src.width else src.height
        val slot = nextSlot(ow, oh)
        // Gira (e espelha, se frontal) NUMA passada, direto no bitmap reutilizado: sem segunda alocação.
        drawM.reset()
        drawM.postTranslate(-src.width / 2f, -src.height / 2f)
        drawM.postRotate(rot.toFloat())
        if (mirrored) drawM.postScale(-1f, 1f)
        drawM.postTranslate(ow / 2f, oh / 2f)
        poolCanvas[slot]?.drawBitmap(src, drawM, null)
        src.recycle()
        onFrame(pool[slot]!!, now)
    }

    override fun stop() {
        stopped = true
        displayListener?.let {
            try { (activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(it) } catch (_: Exception) {}
        }
        displayListener = null
        try { provider?.unbindAll() } catch (_: Exception) {}
        executor?.shutdown()
        executor = null
        VrLog.i("camera", "fechada")
    }

    companion object {
        /** Descobre quais fontes o aparelho oferece (para a tela de diagnóstico). */
        fun probe(activity: ComponentActivity) {
            val future = ProcessCameraProvider.getInstance(activity)
            future.addListener({
                try {
                    val p = future.get()
                    fun has(k: Int) = try {
                        p.hasCamera(CameraSelector.Builder().requireLensFacing(k).build())
                    } catch (_: Exception) { false }
                    fun s(b: Boolean) = if (b) "sim" else "não"
                    Telemetry.sourcesText = "Frontal ${s(has(CameraSelector.LENS_FACING_FRONT))} / " +
                        "Traseira ${s(has(CameraSelector.LENS_FACING_BACK))} / " +
                        "Externa ${s(has(CameraSelector.LENS_FACING_EXTERNAL))}"
                } catch (e: Exception) {
                    Telemetry.sourcesText = "indisponível"
                    VrLog.w("camera", "probe falhou", e)
                }
            }, ContextCompat.getMainExecutor(activity))
        }
    }
}
