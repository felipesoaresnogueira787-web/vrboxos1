package com.vrboxos.media

/**
 * Formato do vídeo, escolhido manualmente pelo usuário. O app NUNCA adivinha: um arquivo 2D
 * comum só vira 360°/3D se o usuário disser que ele é.
 */
enum class VideoFormat(val label: String, val is360: Boolean, val aspectFactor: Float) {
    FLAT("2D", false, 1f),            // mesma imagem nos dois olhos
    SBS("3D lado a lado", false, 0.5f),   // metade esquerda = olho esquerdo
    TB("3D cima/baixo", false, 2f),       // metade de cima = olho esquerdo
    EQ360("360°", true, 1f),              // equiretangular mono
    EQ360_TB("360° cima/baixo", true, 1f); // equiretangular estéreo (cima = olho esquerdo)

    fun next() = values()[(ordinal + 1) % values().size]
    fun prev() = values()[(ordinal + values().size - 1) % values().size]

    /**
     * Matriz 4x4 (colunas) aplicada às coordenadas de textura (v para cima, como na textura externa)
     * para que cada olho veja só a sua metade. Identidade para formatos não divididos.
     */
    fun eyeUvMatrix(eye: Int, out: FloatArray) {
        for (i in 0 until 16) out[i] = 0f
        out[0] = 1f; out[5] = 1f; out[10] = 1f; out[15] = 1f
        when (this) {
            SBS -> { out[0] = 0.5f; out[12] = if (eye == 0) 0f else 0.5f }
            TB, EQ360_TB -> { out[5] = 0.5f; out[13] = if (eye == 0) 0.5f else 0f }
            else -> {}
        }
    }
}
