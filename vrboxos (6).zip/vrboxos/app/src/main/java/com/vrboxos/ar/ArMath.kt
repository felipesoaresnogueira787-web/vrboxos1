package com.vrboxos.ar

import com.vrboxos.head.Quat
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2

/**
 * Alinhamento entre o mundo do ARCore (A: Y para cima, guinada arbitrária, origem no início da sessão) e o
 * mundo de renderização (R: o do giroscópio, com a guinada recentralizada). Ambos têm a gravidade como
 * "para cima", então só diferem por uma guinada (rotação em torno de Y) e pela origem. Pura (JVM).
 *
 *   x_R = Q * (x_A - origem),  com  Q = yawFix * Ry(psi)
 */
object ArMath {
    fun wrapPi(a: Float): Float {
        var x = a
        val twoPi = (2 * PI).toFloat()
        while (x > PI) x -= twoPi
        while (x < -PI) x += twoPi
        return x
    }

    /** Guinada de uma direção horizontal (mesma convenção de HeadPose.recenter: atan2(x, -z)). */
    fun yawOf(f: FloatArray): Float = atan2(f[0], -f[2])

    /** psi tal que Ry(psi) leva a direção do ARCore [fAr] para a do giroscópio [fGl]. */
    fun measureYaw(fAr: FloatArray, fGl: FloatArray): Float = wrapPi(yawOf(fAr) - yawOf(fGl))

    /** A guinada só é confiável com a câmera apontada perto do horizonte. */
    fun usable(f: FloatArray) = abs(f[1]) < 0.8f

    /** Média circular suave. [first] adota a primeira medida de uma vez. */
    fun updateYaw(prev: Float, measured: Float, alpha: Float, first: Boolean): Float =
        if (first) measured else wrapPi(prev + wrapPi(measured - prev) * alpha)

    fun yawQuat(psi: Float) = Quat.fromAxisAngle(0f, 1f, 0f, psi)

    fun toRender(posAr: FloatArray, origin: FloatArray, q: Quat): FloatArray =
        q.rotate(floatArrayOf(posAr[0] - origin[0], posAr[1] - origin[1], posAr[2] - origin[2]))

    fun toAr(posR: FloatArray, origin: FloatArray, q: Quat): FloatArray {
        val v = q.conjugate().rotate(posR)
        return floatArrayOf(v[0] + origin[0], v[1] + origin[1], v[2] + origin[2])
    }

    fun quatToRender(qAr: Quat, q: Quat): Quat = (q * qAr).normalized()
    fun quatToAr(qR: Quat, q: Quat): Quat = (q.conjugate() * qR).normalized()

    /** Rotação (horária, em graus) a aplicar à imagem de CPU do ARCore (orientação do sensor) para ficar vertical. */
    fun imageRotation(sensorOrientation: Int, displayRotation: Int, userOffsetQuarter: Int): Int =
        ((sensorOrientation - displayRotation * 90 + 360) % 360 + userOffsetQuarter * 90) % 360
}
