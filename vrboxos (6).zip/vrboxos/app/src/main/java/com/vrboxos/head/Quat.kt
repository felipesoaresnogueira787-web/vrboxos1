package com.vrboxos.head

import kotlin.math.*

/** Quaternion (w,x,y,z). Matemática pura: testável na JVM. */
data class Quat(val w: Float, val x: Float, val y: Float, val z: Float) {
    operator fun times(o: Quat) = Quat(
        w * o.w - x * o.x - y * o.y - z * o.z,
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w
    )

    fun conjugate() = Quat(w, -x, -y, -z)
    fun dot(o: Quat) = w * o.w + x * o.x + y * o.y + z * o.z
    fun normalized(): Quat {
        val n = sqrt(w * w + x * x + y * y + z * z)
        return if (n < 1e-6f) IDENTITY else Quat(w / n, x / n, y / n, z / n)
    }

    /** Gira o vetor v (3 floats). */
    fun rotate(v: FloatArray, out: FloatArray = FloatArray(3)): FloatArray {
        val tx = 2f * (y * v[2] - z * v[1])
        val ty = 2f * (z * v[0] - x * v[2])
        val tz = 2f * (x * v[1] - y * v[0])
        out[0] = v[0] + w * tx + (y * tz - z * ty)
        out[1] = v[1] + w * ty + (z * tx - x * tz)
        out[2] = v[2] + w * tz + (x * ty - y * tx)
        return out
    }

    /** Escreve matriz 4x4 de rotação em ordem de colunas (padrão OpenGL). */
    fun toMatrix(m: FloatArray) {
        val q = normalized()
        val xx = q.x * q.x; val yy = q.y * q.y; val zz = q.z * q.z
        val xy = q.x * q.y; val xz = q.x * q.z; val yz = q.y * q.z
        val wx = q.w * q.x; val wy = q.w * q.y; val wz = q.w * q.z
        m[0] = 1f - 2f * (yy + zz); m[1] = 2f * (xy + wz); m[2] = 2f * (xz - wy); m[3] = 0f
        m[4] = 2f * (xy - wz); m[5] = 1f - 2f * (xx + zz); m[6] = 2f * (yz + wx); m[7] = 0f
        m[8] = 2f * (xz + wy); m[9] = 2f * (yz - wx); m[10] = 1f - 2f * (xx + yy); m[11] = 0f
        m[12] = 0f; m[13] = 0f; m[14] = 0f; m[15] = 1f
    }

    /** Multiplica o ângulo da rotação por s (s=1 não altera). */
    fun scaleAngle(s: Float): Quat {
        val q = if (w < 0f) Quat(-w, -x, -y, -z) else this
        val sinHalf = sqrt(q.x * q.x + q.y * q.y + q.z * q.z)
        if (sinHalf < 1e-6f) return IDENTITY
        val angle = 2f * atan2(sinHalf, q.w) * s
        val k = sin(angle / 2f) / sinHalf
        return Quat(cos(angle / 2f), q.x * k, q.y * k, q.z * k)
    }

    companion object {
        val IDENTITY = Quat(1f, 0f, 0f, 0f)
        fun fromAxisAngle(ax: Float, ay: Float, az: Float, rad: Float): Quat {
            val h = rad / 2f
            val s = sin(h)
            return Quat(cos(h), ax * s, ay * s, az * s)
        }

        /** Quaternion da rotação cujas COLUNAS são os eixos x,y,z (imagens dos eixos locais no mundo). */
        fun fromAxes(x: FloatArray, y: FloatArray, z: FloatArray): Quat {
            val m00 = x[0]; val m10 = x[1]; val m20 = x[2]
            val m01 = y[0]; val m11 = y[1]; val m21 = y[2]
            val m02 = z[0]; val m12 = z[1]; val m22 = z[2]
            val tr = m00 + m11 + m22
            return when {
                tr > 0f -> { val s = sqrt(tr + 1f) * 2f; Quat(0.25f * s, (m21 - m12) / s, (m02 - m20) / s, (m10 - m01) / s) }
                m00 > m11 && m00 > m22 -> { val s = sqrt(1f + m00 - m11 - m22) * 2f; Quat((m21 - m12) / s, 0.25f * s, (m01 + m10) / s, (m02 + m20) / s) }
                m11 > m22 -> { val s = sqrt(1f + m11 - m00 - m22) * 2f; Quat((m02 - m20) / s, (m01 + m10) / s, 0.25f * s, (m12 + m21) / s) }
                else -> { val s = sqrt(1f + m22 - m00 - m11) * 2f; Quat((m10 - m01) / s, (m02 + m20) / s, (m12 + m21) / s, 0.25f * s) }
            }.normalized()
        }

        fun nlerp(a: Quat, b: Quat, t: Float): Quat {
            val bb = if (a.dot(b) < 0f) Quat(-b.w, -b.x, -b.y, -b.z) else b
            return Quat(
                a.w + (bb.w - a.w) * t, a.x + (bb.x - a.x) * t,
                a.y + (bb.y - a.y) * t, a.z + (bb.z - a.z) * t
            ).normalized()
        }
    }
}

/** Conversões do referencial do sensor (ENU) para o mundo GL (X=Leste, Y=cima, -Z=Norte). */
object HeadMath {
    private val ENU_TO_GL = Quat.fromAxisAngle(1f, 0f, 0f, (-PI / 2).toFloat())

    /**
     * Sinal padrão do remapeamento da tela, derivado da documentação do Android: ROTATION_90 = aparelho
     * girado 90° no sentido anti-horário (topo à ESQUERDA do usuário, X do aparelho = "para cima da tela",
     * Y do aparelho = esquerda). Logo a direita da tela = -Y do aparelho e a rotação tela->aparelho é Rz(-90°).
     * Um sinal trocado deixa a visão girada 180° em AMBAS as paisagens (era o bug "de cabeça para baixo").
     * Em runtime, [chooseRemapSign] confere isto com a gravidade e corrige sozinho.
     */
    const val DEFAULT_REMAP_SIGN = -1

    /** Rotação tela -> aparelho. displayRotation = Surface.ROTATION_* (0..3). */
    fun remap(displayRotation: Int, sign: Int = DEFAULT_REMAP_SIGN): Quat {
        val deg = (displayRotation and 3) * 90
        return Quat.fromAxisAngle(0f, 0f, 1f, (sign * deg * PI / 180.0).toFloat())
    }

    fun sensorToHead(qSensor: Quat, displayRotation: Int, sign: Int = DEFAULT_REMAP_SIGN): Quat =
        (ENU_TO_GL * qSensor * remap(displayRotation, sign)).normalized()

    /**
     * Fallback sem vetor de rotação: integra o giroscópio (rad/s, eixos do aparelho) por [dt] segundos.
     * NÃO há correção de deriva: a visão desliza com o tempo e precisa ser recentralizada.
     */
    fun integrateGyro(q: Quat, wx: Float, wy: Float, wz: Float, dt: Float, displayRotation: Int,
                      sign: Int = DEFAULT_REMAP_SIGN): Quat {
        val w = remap(displayRotation, sign).conjugate().rotate(floatArrayOf(wx, wy, wz))
        val mag = sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2])
        if (mag < 1e-6f || dt <= 0f) return q
        val dq = Quat.fromAxisAngle(w[0] / mag, w[1] / mag, w[2] / mag, mag * dt)
        return (q * dq).normalized()
    }

    /** Vetor "para cima" no referencial da tela, a partir da leitura de gravidade/acelerômetro do aparelho. */
    fun upInScreen(accDev: FloatArray, displayRotation: Int, sign: Int): FloatArray =
        remap(displayRotation, sign).conjugate().rotate(accDev)

    /**
     * Autoverificação por gravidade: com o aparelho em pé (como no VR Box), "para cima" tem de apontar
     * para o topo da tela (+Y). Retorna o sinal (+1/-1) que satisfaz isso, ou null se não der para decidir
     * (aparelho deitado, em retrato/180° onde os dois sinais coincidem, ou leitura fraca).
     * [accDev]: força específica em m/s² (em repouso aponta PARA CIMA).
     */
    fun chooseRemapSign(accDev: FloatArray, displayRotation: Int): Int? {
        if (displayRotation and 1 == 0) return null
        val n = sqrt(accDev[0] * accDev[0] + accDev[1] * accDev[1] + accDev[2] * accDev[2])
        if (n < 5f) return null
        var best: Int? = null
        for (s in intArrayOf(1, -1)) {
            if (upInScreen(accDev, displayRotation, s)[1] / n > 0.7f) best = s
        }
        return best
    }
}

/** Orientação da cabeça: apenas rotação (3DoF). Não há posição medida. */
class HeadPose {
    @Volatile var raw: Quat = Quat.IDENTITY
    @Volatile var yawFix: Quat = Quat.IDENTITY
    @Volatile var sensitivity: Float = 1f
    @Volatile var enabled: Boolean = true
    /**
     * Posição dos olhos no mundo de renderização, em metros. (0,0,0) enquanto só há rotação (giroscópio);
     * com o rastreamento espacial (ARCore) passa a refletir o deslocamento real do aparelho.
     * Substituir o array inteiro (nunca alterar no lugar) mantém a leitura consistente entre threads.
     */
    @Volatile var position: FloatArray = FloatArray(3)
    /** Orientação no mundo de renderização, SEM a escala de sensibilidade (usada para colocar painéis). */
    fun worldOrientation(): Quat = (yawFix * raw).normalized()
    /** Sinal do remapeamento de tela; ajustado pela autoverificação de gravidade se preciso. */
    @Volatile var remapSign: Int = HeadMath.DEFAULT_REMAP_SIGN
    /** Constante de tempo da suavização do sensor em ms (0 = sem suavização). */
    @Volatile var smoothingTauMs: Float = 20f

    fun orientation(): Quat {
        if (!enabled) return Quat.IDENTITY
        return (yawFix * raw).normalized().scaleAngle(sensitivity)
    }

    /** Faz a direção atual do olhar virar "frente" (-Z), mantendo o horizonte. */
    fun recenter() {
        val f = raw.rotate(floatArrayOf(0f, 0f, -1f))
        if (abs(f[0]) < 1e-4f && abs(f[2]) < 1e-4f) return
        val yaw0 = atan2(f[0], -f[2])
        yawFix = Quat.fromAxisAngle(0f, 1f, 0f, yaw0)
    }
}
