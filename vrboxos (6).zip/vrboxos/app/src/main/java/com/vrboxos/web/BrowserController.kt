package com.vrboxos.web

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import com.vrboxos.VrLog
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Navegador real baseado no Android WebView. O WebView fica ANEXADO à janela (atrás da superfície GL, sem
 * aparecer) e, ~8 vezes por segundo, é desenhado em um Bitmap que o renderizador usa como textura do painel
 * do navegador, nos dois olhos. Toques são reenviados ao WebView como MotionEvents.
 *
 * Limites honestos: a página é 2D (nada de web "espacial"); campos de texto DENTRO das páginas dependem do
 * teclado do Android e por isso só são digitáveis no modo plano; o desenho para Bitmap é mais lento que o
 * WebView normal (taxa baixa de quadros).
 */
class BrowserController(
    private val activity: ComponentActivity,
    private val rootProvider: () -> FrameLayout,
    private val notify: (String) -> Unit
) {
    companion object {
        const val W = 1280
        const val H = 720
        private const val PREFS = "vrboxos_browser"
        private const val KEY_HIST = "history"
        private const val MAX_HIST = 20
    }

    private val main = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private val bitmaps by lazy { Array(3) { Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888) } }
    private var bi = 0
    private var downTime = 0L
    @Volatile private var active = false

    val frame = AtomicReference<Bitmap?>(null)
    val frameSeq = AtomicInteger(0)
    @Volatile var url: String = UrlInput.HOME
    @Volatile var title: String = ""
    @Volatile var progress = 0
    @Volatile var loading = false
    @Volatile var canGoBack = false
    @Volatile var canGoForward = false
    @Volatile var error: String? = null
    @Volatile var ready = false
    private val history = ArrayList<String>()

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            capture()
            main.postDelayed(this, 120)
        }
    }

    /** Liga/desliga a captura (só enquanto a tela do navegador está visível). Cria o WebView na 1ª vez. */
    fun setActive(on: Boolean) {
        main.post {
            active = on
            main.removeCallbacks(ticker)
            if (on) {
                ensureView()
                web?.onResume()
                main.post(ticker)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureView() {
        if (web != null) return
        try {
            val w = WebView(activity)
            w.setBackgroundColor(Color.WHITE)
            w.settings.apply {
                javaScriptEnabled = true            // necessário para a maioria dos sites
                domStorageEnabled = true
                allowFileAccess = false             // sem acesso a arquivos locais
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setSupportMultipleWindows(false)    // target=_blank abre na mesma aba
                javaScriptCanOpenWindowsAutomatically = false
                useWideViewPort = true
                loadWithOverviewMode = true
                setGeolocationEnabled(false)
                if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            }
            w.webViewClient = client
            w.webChromeClient = chrome
            w.setDownloadListener { dl, ua, cd, mime, _ -> download(dl, ua, cd, mime) }
            // Atrás da superfície GL (adicionado antes dela): renderiza, mas não aparece.
            rootProvider().addView(w, 0, FrameLayout.LayoutParams(W, H))
            web = w
            loadHistory()
            ready = true
            VrLog.i("web", "WebView criado ${W}x$H")
            w.loadUrl(UrlInput.HOME)
        } catch (t: Throwable) {
            VrLog.e("web", "não foi possível criar o WebView", t)
            error = "WebView indisponível neste aparelho (${t.javaClass.simpleName})"
            notify(error!!)
        }
    }

    private val client = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url
            return when (u.scheme?.lowercase()) {
                "https" -> false
                "http" -> { view.loadUrl(u.buildUpon().scheme("https").build().toString()); true }   // só HTTPS
                else -> { notify("Link externo bloqueado (${u.scheme}:)"); VrLog.w("web", "bloqueado: ${u.scheme}"); true }
            }
        }

        override fun onPageStarted(view: WebView, u: String, favicon: Bitmap?) {
            url = u; loading = true; error = null; nav(view)
        }

        override fun onPageFinished(view: WebView, u: String) {
            url = u; loading = false; title = view.title ?: ""; nav(view)
            addHistory(u)
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, err: WebResourceError) {
            if (request.isForMainFrame) {
                error = friendly(err.errorCode) + " (${err.description})"
                loading = false
                VrLog.w("web", "erro ${err.errorCode}: ${err.description} em ${request.url}")
            }
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, resp: WebResourceResponse) {
            if (request.isForMainFrame && resp.statusCode >= 400) error = "Erro HTTP ${resp.statusCode}"
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, e: SslError) {
            handler.cancel()   // nunca prosseguir com certificado inválido
            error = "Conexão bloqueada: certificado de segurança inválido"
            loading = false
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) { progress = newProgress }
        override fun onReceivedTitle(view: WebView, t: String?) { title = t ?: "" }
        // Páginas não podem usar câmera/microfone/localização do aparelho.
        override fun onPermissionRequest(request: PermissionRequest) { request.deny() }
        override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) { cb.invoke(origin, false, false) }
    }

    private fun friendly(code: Int) = when (code) {
        WebViewClient.ERROR_HOST_LOOKUP -> "Site não encontrado ou sem internet"
        WebViewClient.ERROR_CONNECT -> "Não foi possível conectar ao servidor"
        WebViewClient.ERROR_TIMEOUT -> "Tempo esgotado"
        WebViewClient.ERROR_FAILED_SSL_HANDSHAKE -> "Falha na conexão segura (HTTPS)"
        WebViewClient.ERROR_BAD_URL -> "Endereço inválido"
        WebViewClient.ERROR_UNSUPPORTED_SCHEME -> "Tipo de link não suportado"
        else -> "Erro ao carregar a página"
    }

    private fun nav(v: WebView) { canGoBack = v.canGoBack(); canGoForward = v.canGoForward() }

    private fun download(u: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(u, cd, mime)
            val req = DownloadManager.Request(Uri.parse(u))
                .setMimeType(mime)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, name)  // sem permissão de armazenamento
            if (ua != null) req.addRequestHeader("User-Agent", ua)
            (activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            notify("Download iniciado: $name")
        } catch (t: Throwable) {
            VrLog.e("web", "download falhou", t)
            notify("Não foi possível baixar o arquivo")
        }
    }

    private fun capture() {
        val w = web ?: return
        try {
            val b = bitmaps[bi]; bi = (bi + 1) % bitmaps.size
            val c = Canvas(b)
            c.drawColor(Color.WHITE)
            w.draw(c)
            frame.set(b)
            frameSeq.incrementAndGet()
        } catch (t: Throwable) {
            VrLog.e("web", "captura do WebView falhou", t)
        }
    }

    // ------------------------------------------------------------------ comandos (qualquer thread)

    fun load(input: String) {
        val target = UrlInput.normalize(input)
        main.post { ensureView(); error = null; web?.loadUrl(target); VrLog.i("web", "carregando $target") }
    }

    fun home() = load(UrlInput.HOME)
    fun reload() { main.post { if (loading) web?.stopLoading() else web?.reload(); } }
    fun goForward() { if (canGoForward) main.post { web?.goForward() } }

    /** true se havia página para voltar (então o Voltar foi consumido). */
    fun goBack(): Boolean {
        if (!canGoBack) return false
        main.post { web?.goBack() }
        return true
    }

    fun scrollBy(dy: Int) { main.post { web?.scrollBy(0, dy) } }

    /** Toque na página (coordenadas em pixels do WebView). */
    fun touch(action: Int, x: Float, y: Float) {
        main.post {
            val w = web ?: return@post
            val now = SystemClock.uptimeMillis()
            if (action == MotionEvent.ACTION_DOWN) downTime = now
            val ev = MotionEvent.obtain(downTime, now, action, x.coerceIn(0f, W - 1f), y.coerceIn(0f, H - 1f), 0)
            w.dispatchTouchEvent(ev)
            ev.recycle()
        }
    }

    // ------------------------------------------------------------------ histórico

    @Synchronized private fun addHistory(u: String) {
        if (history.firstOrNull() == u) return
        history.remove(u)
        history.add(0, u)
        while (history.size > MAX_HIST) history.removeAt(history.size - 1)
        activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_HIST, history.joinToString("\n")).apply()
    }

    @Synchronized private fun loadHistory() {
        history.clear()
        activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_HIST, "")
            ?.split("\n")?.filter { it.startsWith("https://") }?.let { history.addAll(it) }
    }

    @Synchronized fun historyList(): List<String> = history.toList()

    // ------------------------------------------------------------------ ciclo de vida

    fun onPause() { main.post { web?.onPause() } }
    fun onResume() { main.post { if (active) web?.onResume() } }
    fun destroy() {
        main.removeCallbacks(ticker)
        main.post {
            web?.let { (it.parent as? FrameLayout)?.removeView(it); it.destroy() }
            web = null
        }
    }
}
