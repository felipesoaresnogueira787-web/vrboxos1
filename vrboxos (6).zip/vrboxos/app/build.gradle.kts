import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vrboxos"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vrboxos"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug { isDebuggable = true }
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // O modelo do MediaPipe (.task) não pode ser comprimido no APK.
    androidResources { noCompress.add("task") }

    testOptions { unitTests.isReturnDefaultValues = true }
}

// O modelo de mãos é baixado pelo PRÓPRIO build (funciona em qualquer workflow do GitHub Actions ou local).
val handModel = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile
val downloadHandModel by tasks.registering {
    description = "Baixa hand_landmarker.task (MediaPipe, Apache 2.0) para os assets, se ainda não existir"
    outputs.file(handModel)
    doLast {
        if (!handModel.exists() || handModel.length() < 1_000_000L) {
            handModel.parentFile.mkdirs()
            val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
            logger.lifecycle("Baixando modelo de mãos: $url")
            URL(url).openStream().use { input -> handModel.outputStream().use { out -> input.copyTo(out) } }
            check(handModel.length() > 1_000_000L) { "Download do modelo de mãos falhou (arquivo pequeno demais)" }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadHandModel) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")

    // Hand tracking (modelo hand_landmarker.task é baixado por scripts/baixar_modelos.sh)
    implementation("com.google.mediapipe:tasks-vision:0.10.14")

    // Rastreamento espacial (posição + âncoras). OPCIONAL em tempo de execução: sem ARCore o app segue só com rotação.
    implementation("com.google.ar:core:1.42.0")

    // Fonte de vídeo: câmera (frontal, traseira, externa exposta via Camera2)
    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")

    // Cinema
    implementation("androidx.media3:media3-exoplayer:1.3.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test:runner:1.5.2")
}
