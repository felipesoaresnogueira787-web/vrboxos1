# Status real do projeto

Legenda: **E** escrito · **C** compilado · **T** testado (automático JVM) · **H** testado em aparelho real.

> Nenhum item está marcado **C** nem **H**: o ambiente onde o código foi escrito não tinha Gradle,
> Android SDK nem rede. A primeira compilação acontecerá no GitHub Actions.

| Requisito | E | C | T | H | Observações |
|---|:-:|:-:|:-:|:-:|---|
| Projeto Gradle/Manifesto/Workflow | ✔ | ✘ | – | ✘ | Gradle 8.7 via `setup-gradle`, AGP 8.5.2, Kotlin 1.9.24 |
| Render estéreo (2 olhos, IPD, FOV, FBO) | ✔ | ✘ | parcial | ✘ | testado só a geometria (viewports, sinal do IPD) |
| Correção de distorção da lente | ✔ | ✘ | ✘ | ✘ | passada de shader com k1 ajustável; **desligada por padrão (k1=0)**; sinal/valor ideal exigem calibração visual |
| Rastreio da cabeça (rotação 3DoF) | ✔ | ✘ | parcial | ✘ | matemática verificada numericamente; mapeamento real do sensor não testado |
| Recentralizar / sensibilidade / suavização | ✔ | ✘ | ✔ | ✘ | |
| Sem sensor / pausa-retomada | ✔ | ✘ | ✘ | ✘ | avisa e segue; sensores reiniciam em `onResume` |
| MediaPipe Hand Landmarker (21 pts, 2 mãos) | ✔ | ✘ | ✘ | ✘ | API usada: `detectForVideo(MPImage, long)` — conferir no primeiro build |
| Classificação de gestos (aberta, punho, apontar, pinça, agarrar, deslizar, 2 mãos, hold) | ✔ | ✘ | ✔ | ✘ | testado com mãos **sintéticas**, não com câmera real |
| Filtro de tremor, histerese, confirmação temporal, trava de clique | ✔ | ✘ | ✔ | ✘ | |
| Perda/recuperação de mão e de câmera | ✔ | ✘ | ✔ (mão) | ✘ | câmera: até 5 tentativas a cada 3 s |
| Mãos virtuais desenhadas dos pontos reais | ✔ | ✘ | ✘ | ✘ | 2D mapeado na cabeça; **z do MediaPipe é impreciso, não é posição 3D absoluta** |
| Abstração de fonte de vídeo | ✔ | ✘ | – | ✘ | `VideoSource`; só `CameraXSource` implementada |
| Câmera externa/USB | parcial | ✘ | ✘ | ✘ | só se o Android a expõe via Camera2 (`LENS_FACING_EXTERNAL`); **UVC genérica NÃO implementada** |
| Tela de calibração do campo de visão | ✔ | ✘ | ✘ | ✘ | no Diagnóstico (borda verde/amarela/cinza) |
| Diagnóstico (imagem, pontos, gestos, confiança, fps, latência) | ✔ | ✘ | ✘ | ✘ | latência = inferência, não "glass-to-glass" |
| Navegação por olhar (permanência) | ✔ | ✘ | ✔ | ✘ | |
| Controle Bluetooth | parcial | ✘ | ✘ | ✘ | só teclas/botões; analógicos não |
| Home, dock, status, notificações internas | ✔ | ✘ | ✘ | ✘ | |
| Config. persistentes | ✔ | ✘ | ✘ | ✘ | teste instrumentado escrito, não rodado |
| 3 ambientes 3D + persistência | ✔ | ✘ | ✘ | ✘ | geometria leve (linhas/caixas/pontos) |
| Cinema: vídeo local, play/pause, volume, ±10 s, barra, tamanho, tela plana | ✔ | ✘ | ✘ | ✘ | Media3 → textura externa |
| Cinema: 3D lado a lado (SBS) e cima/baixo (TB) | ✔ | ✘ | ✔ (UV) | ✘ | formato escolhido pelo usuário; cada olho recorta sua metade |
| Estados da câmera: Desligada / Aguardando permissão / Inicializando / Ativa / Indisponível | ✔ | ✘ | ✔ (rótulos, frescor) | ✘ | "Ativa" só após 3 quadros válidos; watchdog: 3 s sem quadros ou 10 s sem o primeiro => Indisponível |
| Câmera real dentro do ambiente 3D (painel) e como fundo da cena | ✔ | ✘ | ✘ | ✘ | prévia com os 21 pontos alinhados; fundo é mono e preso à cabeça (não registrado com o espaço real) |
| Alternar Ambiente 3D <-> câmera sem reiniciar | ✔ | ✘ | ✘ | ✘ | tela "Câmera", linha "Fundo da cena" e botão no painel da câmera |
| Indicador de mãos (status e ponto no campo de visão) | ✔ | ✘ | ✘ | ✘ | verde = mão vista; âmbar = câmera ativa sem mão; azul = iniciando; vermelho = indisponível |
| Partida idempotente da câmera (não reabre sem necessidade) | ✔ | ✘ | ✘ | ✘ | `restart()` só ao trocar a fonte |
| Sensores: fallback de giroscópio, taxa por modo (200/60 Hz), liga/desliga real | ✔ | ✘ | ✔ (integração) | ✘ | fallback **sem correção de deriva**; só rotação, nunca posição |
| Diagnóstico de orientação (rotação do display, inclinação, giro/roll) + marcadores nas guias | ✔ | ✘ | ✘ | ✘ | giro ~0 = em pé; ~180 = de cabeça para baixo |
| Teclas de mídia Bluetooth no cinema | ✔ | ✘ | ✘ | ✘ | play/pause, +/-10 s |
| **Orientação: sinal do remapeamento de paisagem corrigido** (causa da visão invertida) | ✔ | ✘ | ✔ (4 rotações, física) | ✘ | antes `Rz(+90)` para ROTATION_90; o correto pela documentação do Android é `Rz(-90)`; o teste de regressão mostra o antigo invertendo as duas paisagens |
| Autoverificação por gravidade (corrige sozinho se o sinal estiver errado no aparelho) | ✔ | ✘ | ✔ (decisão) | ✘ | exige ~1,6 s de leituras concordantes com o aparelho em pé |
| Log do app (buffer, tela de log, compartilhar) + rastro de orientação a cada 2 s | ✔ | ✘ | ✔ | ✘ | Diagnóstico > Ver log / Compartilhar log; tags `VRBOX-*` no logcat |
| Câmera: erros recuperáveis do CameraX não derrubam mais; fallback entre câmeras; erros com causa real | ✔ | ✘ | ✘ | ✘ | |
| Câmera independe do modelo de mãos (modelo ausente = só as mãos ficam indisponíveis) | ✔ | ✘ | ✘ | ✘ | |
| Modelo de mãos baixado pelo próprio Gradle (tarefa `downloadHandModel`) | ✔ | ✘ | – | ✘ | funciona em qualquer workflow |
| **Navegador** (WebView): endereço, pesquisa, HTTPS, voltar/avançar/atualizar, início, progresso, erros, histórico, rolagem | ✔ | ✘ | ✔ (URL) | ✘ | duas imagens lado a lado no VR; página é 2D |
| Navegador: teclado virtual (VR) e teclado do Android (modo plano), toque/pinça/olhar na página | ✔ | ✘ | ✘ | ✘ | campos de texto DENTRO das páginas só no modo plano |
| Navegador: downloads (pasta do app), links externos bloqueados, permissões da página negadas | ✔ | ✘ | ✘ | ✘ | |
| Menu do VR: 1,25 m de distância real, escala 1,3 (53° -> 66° de largura), centrado | ✔ | ✘ | ✔ (geometria) | ✘ | confirmar conforto/legibilidade no headset; ajustável em Configurações |
| Correção `Unresolved reference: ERROR_TYPE_CRITICAL` (classificação por código) | ✔ | ✘ | ✔ | – | só o build do Actions confirma |
| **Ambiente "Minha Casa"** (passthrough 2D da câmera traseira ao vivo, menu por cima, nos dois olhos) | ✔ | ✘ | ✔ (mapeamento) | ✘ | mono, sem profundidade nem mapeamento 3D; liga a câmera (pede permissão) e desliga ao sair se foi ele que a ligou |
| Mãos continuam funcionando em "Minha Casa" (mesmos quadros alimentam câmera e MediaPipe) | ✔ | ✘ | ✘ | ✘ | só enxerga as mãos que aparecem na câmera traseira |
| Pegar o menu com a pinça (segurar + mover), menu inteiro em grupo, suavização, contorno verde | ✔ | ✘ | ✔ (alcance) | ✘ | pinça rápida continua sendo clique; segurar >0,25 s com movimento (ou 0,7 s parado) agarra |
| Limite de alcance do menu (45° horiz., 35° vert.) e "Recentrar" que traz o menu de volta | ✔ | ✘ | ✔ | ✘ | também o comando de punho (Menu) |
| Ponto no indicador alinhado à posição aparente do dedo + seleção em 5 s com anel de progresso | ✔ | ✘ | ✔ (seletor, mapeamento) | ✘ | exige a pose "apontar" (indicador estendido, demais dedos dobrados) |
| Tolerância a tremor (área ampliada + 250 ms), reinício ao trocar de botão, sem repetição | ✔ | ✘ | ✔ | ✘ | |
| Menor atraso: prévia sem cópia antes da inferência, 30 fps no passthrough, miniatura só no Diagnóstico | ✔ | ✘ | ✘ | ✘ | latência real não medida |
| **Câmera fluida**: exibição desacoplada do reconhecimento (thread própria + caixa de correio de 1 quadro, sem fila) | ✔ | ✘ | ✘ | ✘ | antes a imagem esperava a inferência na mesma thread; agora só o reconhecimento pode ficar mais lento |
| Pool de bitmaps (1 conversão + 1 passada de rotação por quadro, sem alocar a cada quadro); prévia sem cópia para a GPU | ✔ | ✘ | ✘ | ✘ | |
| Métricas separadas: fps da câmera, fps exibido, atraso app→GPU, inferência, quadro→resultado, descartados (tela Desempenho) | ✔ | ✘ | ✘ | ✘ | indica automaticamente se o gargalo é câmera, GPU ou reconhecimento |
| Delegate de GPU do MediaPipe (opcional, desligado, com volta ao CPU) | ✔ | ✘ | ✘ | ✘ | reconhecimento padrão continua em CPU, como antes |
| **A tela virtual é um objeto no mundo** (pose 3D própria, independente do ambiente/cubo): andar aproxima, afastar mantém o lugar | ✔ | ✘ | ✔ (geometria) | ✘ | a visão agora inclui a posição da cabeça; sem ARCore a posição é (0,0,0) |
| Pegar e arrastar a tela em qualquer posição: frente, atrás, laterais, altura, chão, teto; solta e permanece; suavização | ✔ | ✘ | ✔ (pose/alcance do raio) | ✘ | gira para ficar voltada ao usuário; "Recentrar" traz de volta à frente |
| **Rastreamento espacial real (ARCore)**: posição, âncoras, superfícies e pontos de referência | ✔ | ✘ | ✔ (alinhamento, YUV) | ✘ | OPCIONAL e desligado; orientação segue do giroscópio; só com ARCore compatível; usa a câmera traseira |
| ARCore como fonte da câmera (mãos + passthrough) enquanto o espacial está ligado | ✔ | ✘ | ✔ (conversão) | ✘ | rotação da imagem derivada do sensor; há ajuste manual em Configurações |
| Âncora da tela ao soltar + correção de deriva pela âncora | ✔ | ✘ | ✘ | ✘ | |
| Cinema: 360° e 360° cima/baixo (esfera equiretangular) | ✔ | ✘ | ✔ (malha) | ✘ | só rotação; 180° e outras projeções **não** implementadas |
| Calibração: alinhamento, escala, centralizar, restaurar (salvos) | ✔ | ✘ | ✔ (viewport) | ✘ | guias por olho; recorte impede invadir o outro olho |
| Orientação automática/manual; FOV por proporção de tela | ✔ | ✘ | ✔ (FOV) | ✘ | `requestedOrientation` e rotação do ImageAnalysis por display |
| Permissão de câmera negada: explicação, nova tentativa, abrir configurações | ✔ | ✘ | ✘ | ✘ | |
| Detecção de câmera escura/bloqueada + volta aos sensores | ✔ | ✘ | ✘ | ✘ | heurística de brilho; escuro também ocorre em ambiente sem luz |
| Mudo, foco de áudio, pausa ao desconectar fones | ✔ | ✘ | ✘ | ✘ | Media3 |
| Toque como clique no VR | ✔ | ✘ | ✘ | ✘ | 
| Galeria / visualizador 360° / imagens estéreo | ✘ | – | – | – | **não implementado** (tiles marcados) |
| Mover/redimensionar painéis | ✔ | ✘ | ✘ | ✘ | mãos e toque; por olhar só restaurar posições |
| Minimizar/restaurar painéis | ✘ | – | – | – | não implementado |
| Confirmação em ações importantes | ✔ | ✘ | ✘ | ✘ | "Padrões…" exige 2 cliques em 3 s |
| Controle térmico | ✔ | ✘ | ✘ | ✘ | `PowerManager` ≥ SEVERE reduz o rastreio a 10 fps |
| Delegate GPU do MediaPipe | ✘ | – | – | – | só CPU |
| Testes: renderização, mídia, recuperação de interrupção | ✘ | – | – | – | pendentes (exigem aparelho/emulador) |

## Critérios de conclusão (seção 17 do pedido)

1. Compila sem erros — **não verificado**.
2. Estéreo funciona num VR Box — **não verificado**.
3. Cabeça controla a visão — **não verificado**.
4. Menu navegável sem tocar — implementado (olhar/mãos); **não verificado**.
5. Hand tracking processa imagens reais — implementado; **não verificado**.
6. Gestos geram comandos verificáveis — lógica testada com dados sintéticos; **não verificado em câmera real**.
7. Perda de câmera/mãos tratada — implementado; mão testada sinteticamente.
8. Ambientes e cinema — implementados; **não verificados**.
9. Configurações persistidas — implementado; teste não rodado.
10. Actions produz APK — workflow escrito; **não executado**.

**Conclusão: o projeto NÃO pode ser considerado concluído.**
